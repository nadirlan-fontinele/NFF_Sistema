# NFF Gestão

ERP para gestão de empresa de terceirização de mão de obra: contratos e postos, operação
(escalas, frequência, substituições), RH e recrutamento, comercial (CRM e propostas),
financeiro, marketing com IA, portal do cliente e inteligência gerencial.

- Arquitetura e roadmap: [docs/01-arquitetura.md](docs/01-arquitetura.md)
- Regras de negócio e decisões: [docs/02-regras-e-decisoes.md](docs/02-regras-e-decisoes.md)
- Situação das etapas: [docs/03-status.md](docs/03-status.md)

## Stack

Next.js 15 (App Router) · React 19 · TypeScript · Tailwind CSS 4 · componentes padrão shadcn/ui (Radix) ·
Supabase (PostgreSQL, Auth, RLS) · Zod · Recharts · Vitest.

## Rodando localmente

```bash
cp .env.example .env.local   # preencha com a URL e a chave pública do Supabase
npm install
npm run dev                  # http://localhost:3000
```

| Variável | Onde é usada |
| --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Navegador e servidor (chave pública; a segurança é feita pelo RLS) |
| `SUPABASE_SERVICE_ROLE_KEY` | **Somente servidor.** Necessária para convidar usuários. Nunca use prefixo `NEXT_PUBLIC`. |
| `NEXT_PUBLIC_APP_URL` | URL pública do app (links de convite e de recuperação de senha) |

## Banco de dados

As migrações ficam em `supabase/migrations` e são aplicadas em ordem. Dados fictícios de
demonstração ficam em `supabase/seed/demo.sql`, numa organização separada marcada como
`demonstracao = true`.

## Testes

```bash
npm test          # regras de validação e formatação (Vitest)
npm run typecheck
npm run test:db   # aplica as migrações num PostgreSQL local descartável e roda os testes de RLS e regras
                  # (variáveis PGHOST/PGPORT/PGUSER apontando para um Postgres de teste)
```

## Estrutura

```
src/app/(auth)        login, recuperação de senha
src/app/(app)         área interna (layout com menu lateral)
src/app/portal        portal do cliente
src/modules/<modulo>  schemas Zod, Server Actions, consultas e componentes de cada módulo
src/lib               Supabase, sessão/permissões, formatação brasileira
supabase/migrations   esquema, RLS, auditoria, regras de negócio
supabase/tests        testes SQL de segurança e regras
```
