#!/usr/bin/env bash
# Aplica todas as migrações num PostgreSQL local descartável e roda os testes SQL.
# Uso: PGHOST=/tmp PGPORT=54329 PGUSER=postgres npm run test:db
set -euo pipefail
DB=${TEST_DB:-nff_teste}
psql -v ON_ERROR_STOP=1 -q -c "drop database if exists $DB" -c "create database $DB"
for f in supabase/tests/00_stub_supabase_local.sql supabase/migrations/*.sql; do
  psql -d "$DB" -v ON_ERROR_STOP=1 -q -f "$f" > /dev/null
done
for t in supabase/tests/0[1-9]_*.sql; do
  echo "== $t"
  psql -d "$DB" -q -t -f "$t" 2>&1 | grep -E "ok:|FALHA|ERROR|PASSARAM" | sed 's/.*NOTICE: *//'
done
