import { describe, expect, it } from "vitest";
import { cnpjValido, cpfValido, formatarData, formatarDocumento, formatarMoeda } from "@/lib/format";

describe("formatação brasileira", () => {
  it("formata moeda em reais", () => {
    expect(formatarMoeda(1234.5).replace(/\s/g, " ")).toBe("R$ 1.234,50");
    expect(formatarMoeda(null)).toBe("—");
  });
  it("formata data do Postgres sem erro de fuso", () => {
    expect(formatarData("2026-01-01")).toBe("01/01/2026");
  });
  it("formata CNPJ e CPF", () => {
    expect(formatarDocumento("11222333000181")).toBe("11.222.333/0001-81");
    expect(formatarDocumento("52998224725")).toBe("529.982.247-25");
  });
});

describe("validação de documentos", () => {
  it("valida CNPJ", () => {
    expect(cnpjValido("11.222.333/0001-81")).toBe(true);
    expect(cnpjValido("11.222.333/0001-82")).toBe(false);
    expect(cnpjValido("11111111111111")).toBe(false);
  });
  it("valida CPF", () => {
    expect(cpfValido("529.982.247-25")).toBe(true);
    expect(cpfValido("529.982.247-24")).toBe(false);
    expect(cpfValido("00000000000")).toBe(false);
  });
});
