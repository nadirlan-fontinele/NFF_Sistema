import { describe, expect, it } from "vitest";
import { clienteSchema } from "@/modules/clientes/schema";
import { aditivoSchema, contratoSchema, postoSchema, valorMonetario } from "@/modules/contratos/schema";

const uuid = "8c8c6b3e-5d7a-4c1e-9b2f-1a2b3c4d5e6f";

describe("valores monetários", () => {
  it("aceita formatos brasileiros", () => {
    expect(valorMonetario.parse("1.234,56")).toBe(1234.56);
    expect(valorMonetario.parse("R$ 3500,00")).toBe(3500);
    expect(valorMonetario.parse("3500.5")).toBe(3500.5);
    expect(valorMonetario.parse("")).toBeNull();
    expect(valorMonetario.safeParse("-1").success).toBe(false);
  });
});

describe("cliente", () => {
  const base = { tipo_pessoa: "PJ", razao_social: "Empresa Teste Ltda", documento: "11.222.333/0001-81", status: "ativo" };
  it("aceita CNPJ válido e normaliza dígitos", () => {
    const r = clienteSchema.parse({ ...base, email: "" });
    expect(r.documento).toBe("11222333000181");
    expect(r.email).toBeNull();
  });
  it("recusa CNPJ inválido", () => {
    const r = clienteSchema.safeParse({ ...base, documento: "11.222.333/0001-00" });
    expect(r.success).toBe(false);
  });
  it("recusa CPF inválido para pessoa física", () => {
    expect(clienteSchema.safeParse({ ...base, tipo_pessoa: "PF", documento: "123.456.789-00" }).success).toBe(false);
  });
});

describe("contrato", () => {
  const base = { cliente_id: uuid, numero: "NFF-2026-001", data_inicio: "2026-01-01", valor_mensal: "10.000,00" };
  it("converte valor e campos vazios", () => {
    const r = contratoSchema.parse({ ...base, data_fim: "", supervisor_id: "" });
    expect(r.valor_mensal).toBe(10000);
    expect(r.data_fim).toBeNull();
    expect(r.supervisor_id).toBeNull();
  });
  it("recusa término antes do início", () => {
    expect(contratoSchema.safeParse({ ...base, data_fim: "2025-12-31" }).success).toBe(false);
  });
});

describe("posto", () => {
  it("exige quantidade positiva", () => {
    const base = { unidade_id: uuid, funcao_id: uuid, escala_modelo_id: uuid, horario_entrada: "07:00", horario_saida: "16:48", intervalo_minutos: "60", valor_unitario: "3.500,00" };
    expect(postoSchema.parse({ ...base, quantidade: "2" }).quantidade).toBe(2);
    expect(postoSchema.safeParse({ ...base, quantidade: "0" }).success).toBe(false);
  });
});

describe("aditivo", () => {
  it("reajuste exige novo valor; prazo exige nova data", () => {
    expect(aditivoSchema.safeParse({ numero: "1", tipo: "reajuste", vigencia_inicio: "2026-01-01" }).success).toBe(false);
    expect(aditivoSchema.safeParse({ numero: "1", tipo: "prazo", vigencia_inicio: "2026-01-01" }).success).toBe(false);
    expect(aditivoSchema.safeParse({ numero: "1", tipo: "reajuste", vigencia_inicio: "2026-01-01", valor_mensal_novo: "11.000,00" }).success).toBe(true);
  });
});
