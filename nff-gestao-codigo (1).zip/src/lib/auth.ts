import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type Permissao = `${string}.${string}`;

export type Sessao = {
  userId: string;
  email: string;
  nome: string;
  tipo: "interno" | "cliente" | "colaborador";
  organizacaoId: string;
  organizacaoNome: string;
  demonstracao: boolean;
  clienteId: string | null;
  perfis: string[];
  permissoes: Set<string>;
  pode: (p: Permissao) => boolean;
};

/** Carrega a sessão do usuário (uma vez por requisição). */
export const getSessao = cache(async (): Promise<Sessao | null> => {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const [{ data: usuario }, { data: perms }, { data: perfis }] = await Promise.all([
    supabase
      .from("usuarios")
      .select("id, nome, email, tipo, cliente_id, ativo, organizacao_id, organizacoes(nome, demonstracao)")
      .eq("id", user.id)
      .maybeSingle(),
    supabase.rpc("minhas_permissoes"),
    supabase.from("usuario_perfis").select("perfis(nome)").eq("usuario_id", user.id),
  ]);

  if (!usuario || !usuario.ativo) return null;

  const org = usuario.organizacoes as unknown as { nome: string; demonstracao: boolean } | null;
  const permissoes = new Set<string>((perms ?? []).map((p: { modulo: string; acao: string }) => `${p.modulo}.${p.acao}`));

  return {
    userId: user.id,
    email: usuario.email,
    nome: usuario.nome,
    tipo: usuario.tipo,
    organizacaoId: usuario.organizacao_id,
    organizacaoNome: org?.nome ?? "",
    demonstracao: org?.demonstracao ?? false,
    clienteId: usuario.cliente_id,
    perfis: (perfis ?? []).map((p) => (p.perfis as unknown as { nome: string } | null)?.nome ?? "").filter(Boolean),
    permissoes,
    pode: (p: Permissao) => permissoes.has(p),
  };
});

/** Exige sessão válida; caso contrário, manda para o login. */
export async function exigirSessao(): Promise<Sessao> {
  const sessao = await getSessao();
  if (!sessao) redirect("/login?erro=sem-acesso");
  return sessao;
}

/** Exige uma permissão (para páginas). Sem permissão → página de acesso negado. */
export async function exigirPermissao(p: Permissao): Promise<Sessao> {
  const sessao = await exigirSessao();
  if (!sessao.pode(p)) redirect("/acesso-negado");
  return sessao;
}
