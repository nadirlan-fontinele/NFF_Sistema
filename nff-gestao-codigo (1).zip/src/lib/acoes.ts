import type { PostgrestError } from "@supabase/supabase-js";
import type { ZodError } from "zod";

/** Estado padrão devolvido pelas Server Actions de formulário. */
export type EstadoForm = {
  erro?: string;
  campos?: Record<string, string>;
  valores?: Record<string, string>;
} | undefined;

export function errosDoZod(e: ZodError, formData?: FormData): EstadoForm {
  const campos: Record<string, string> = {};
  for (const issue of e.issues) {
    const k = String(issue.path[0] ?? "_");
    if (!campos[k]) campos[k] = issue.message;
  }
  return {
    erro: "Verifique os campos destacados.",
    campos,
    valores: formData ? (Object.fromEntries([...formData.entries()].filter(([, v]) => typeof v === "string")) as Record<string, string>) : undefined,
  };
}

/** Traduz erros do Postgres/Supabase para mensagens claras em português. */
export function mensagemErroBanco(error: PostgrestError | null | undefined, contexto?: string): string {
  if (!error) return "Erro desconhecido.";
  switch (error.code) {
    case "23505":
      return contexto ? `Já existe ${contexto} com esses dados.` : "Registro duplicado.";
    case "23503":
      return "Este registro está vinculado a outros e não pode ser removido ou alterado assim.";
    case "23514":
      return error.message.includes("unidade informada")
        ? "A unidade informada não pertence ao cliente do contrato."
        : "Algum valor não atende às regras de validação.";
    case "42501":
      return "Você não tem permissão para esta operação.";
    case "PGRST116":
      return "Registro não encontrado ou sem permissão de acesso.";
    default:
      console.error("[banco]", error);
      return "Não foi possível salvar. Tente novamente ou contate o administrador.";
  }
}

/** Converte string vazia em null (campos opcionais). */
export const vazioParaNull = (v: unknown) => (typeof v === "string" && v.trim() === "" ? null : v);

/** Remove caracteres que quebram filtros do PostgREST (.or / ilike). */
export function termoBusca(q: string | undefined | null): string {
  return (q ?? "").replace(/[,()*%\\:"']/g, " ").trim().slice(0, 80);
}
