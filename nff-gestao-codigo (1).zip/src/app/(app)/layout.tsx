import { redirect } from "next/navigation";
import { exigirSessao } from "@/lib/auth";
import { NAVEGACAO } from "@/components/layout/nav";
import { SidebarConteudo } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const sessao = await exigirSessao();
  if (sessao.tipo === "cliente") redirect("/portal");
  if (sessao.tipo !== "interno") redirect("/acesso-negado");

  // Menu filtrado pelas permissões (a segurança real está no banco e no servidor)
  const secoes = NAVEGACAO.map((s) => ({
    ...s,
    itens: s.itens.filter((i) => !i.permissao || sessao.pode(i.permissao)),
  })).filter((s) => s.itens.length > 0);

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[256px_1fr]">
      <aside className="sticky top-0 hidden h-dvh lg:block">
        <SidebarConteudo secoes={secoes} />
      </aside>
      <div className="flex min-w-0 flex-col">
        <Topbar
          secoes={secoes}
          nome={sessao.nome}
          email={sessao.email}
          perfis={sessao.perfis}
          organizacao={sessao.organizacaoNome}
          demonstracao={sessao.demonstracao}
        />
        <main className="mx-auto w-full max-w-7xl flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}
