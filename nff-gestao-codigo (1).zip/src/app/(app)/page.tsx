import Link from "next/link";
import { Building2, FileText, MapPin, Users, Wallet, CalendarClock } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatarData, formatarMoeda, formatarNumero } from "@/lib/format";
import { GraficoReceitaPorCliente, GraficoStatus } from "@/modules/dashboard/graficos";

export const metadata = { title: "Dashboard" };

const ROTULO_STATUS: Record<string, string> = { ativo: "Ativo", rascunho: "Rascunho", suspenso: "Suspenso", encerrado: "Encerrado" };

export default async function DashboardPage() {
  const sessao = await exigirSessao();
  const supabase = await createClient();
  const [{ count: clientesAtivos }, { data: contratos }] = await Promise.all([
    sessao.pode("clientes.ver")
      ? supabase.from("clientes").select("id", { count: "exact", head: true }).eq("status", "ativo")
      : Promise.resolve({ count: null }),
    sessao.pode("contratos.ver") ? supabase.from("vw_contratos_resumo").select("*") : Promise.resolve({ data: null }),
  ]);

  const lista = contratos ?? [];
  const ativos = lista.filter((c) => c.status === "ativo");
  const postos = ativos.reduce((s, c) => s + c.postos_contratados, 0);
  const receita = ativos.reduce((s, c) => s + Number(c.valor_mensal), 0);
  const unidades = ativos.reduce((s, c) => s + c.unidades, 0);
  const verValores = sessao.pode("contratos.ver_valores");

  const hoje = new Date();
  const limite = new Date(hoje.getTime() + 90 * 86400000).toISOString().slice(0, 10);
  const vencendo = ativos
    .filter((c) => c.data_fim && c.data_fim <= limite)
    .sort((a, b) => (a.data_fim! < b.data_fim! ? -1 : 1))
    .slice(0, 6);

  const porCliente = Object.values(
    ativos.reduce<Record<string, { cliente: string; valor: number }>>((acc, c) => {
      acc[c.cliente_id] ??= { cliente: c.cliente_nome, valor: 0 };
      acc[c.cliente_id].valor += Number(c.valor_mensal);
      return acc;
    }, {}),
  ).sort((a, b) => b.valor - a.valor).slice(0, 8);

  const porStatus = Object.entries(
    lista.reduce<Record<string, number>>((acc, c) => ((acc[c.status] = (acc[c.status] ?? 0) + 1), acc), {}),
  ).map(([s, total]) => ({ status: ROTULO_STATUS[s] ?? s, total }));

  const primeiroNome = sessao.nome.split(" ")[0];

  return (
    <>
      <PageHeader titulo={`Olá, ${primeiroNome}`} descricao="Visão consolidada da operação. Os números consideram apenas os dados que seu perfil pode ver." />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Indicador icone={FileText} titulo="Contratos ativos" valor={formatarNumero(ativos.length)} href="/contratos?status=ativo" />
        <Indicador icone={Users} titulo="Postos contratados" valor={formatarNumero(postos)} detalhe="em contratos ativos" />
        {clientesAtivos !== null && <Indicador icone={Building2} titulo="Clientes ativos" valor={formatarNumero(clientesAtivos ?? 0)} href="/clientes?status=ativo" />}
        {verValores ? (
          <Indicador icone={Wallet} titulo="Receita mensal contratada" valor={formatarMoeda(receita)} detalhe="soma dos contratos ativos" />
        ) : (
          <Indicador icone={MapPin} titulo="Unidades atendidas" valor={formatarNumero(unidades)} />
        )}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        {verValores && (
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">Receita mensal por cliente</CardTitle>
              <CardDescription>Contratos ativos, maiores clientes</CardDescription>
            </CardHeader>
            <CardContent>
              {porCliente.length ? <GraficoReceitaPorCliente dados={porCliente} /> : <p className="py-10 text-center text-sm text-muted-foreground">Sem contratos ativos.</p>}
            </CardContent>
          </Card>
        )}
        <Card className={verValores ? "" : "lg:col-span-1"}>
          <CardHeader><CardTitle className="text-base">Contratos por situação</CardTitle></CardHeader>
          <CardContent>
            {porStatus.length ? <GraficoStatus dados={porStatus} /> : <p className="py-10 text-center text-sm text-muted-foreground">Nenhum contrato.</p>}
          </CardContent>
        </Card>
        <Card className={verValores ? "lg:col-span-3" : "lg:col-span-2"}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base"><CalendarClock className="size-4" /> Contratos vencendo em 90 dias</CardTitle>
          </CardHeader>
          <CardContent>
            {vencendo.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum contrato ativo vence nos próximos 90 dias.</p>
            ) : (
              <ul className="divide-y">
                {vencendo.map((c) => (
                  <li key={c.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                    <Link href={`/contratos/${c.id}`} className="font-medium text-primary hover:underline">{c.numero}</Link>
                    <span className="flex-1 truncate text-muted-foreground">{c.cliente_nome}</span>
                    <span className="whitespace-nowrap">{formatarData(c.data_fim)}</span>
                    <StatusBadge status={c.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4 border-dashed bg-muted/30">
        <CardContent className="py-4 text-sm text-muted-foreground">
          Presença do dia, postos descobertos e substituições entram no dashboard na <strong>Etapa 3</strong>;
          indicadores de RH, comercial, financeiro e marketing chegam com os respectivos módulos.
        </CardContent>
      </Card>
    </>
  );
}

function Indicador({
  icone: Icone, titulo, valor, detalhe, href,
}: { icone: React.ComponentType<{ className?: string }>; titulo: string; valor: string; detalhe?: string; href?: string }) {
  const conteudo = (
    <Card className="h-full p-4 transition-colors hover:border-primary/40">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        {titulo}
        <Icone className="size-4" />
      </div>
      <div className="mt-2 truncate text-2xl font-semibold tracking-tight">{valor}</div>
      {detalhe && <div className="mt-0.5 text-xs text-muted-foreground">{detalhe}</div>}
    </Card>
  );
  return href ? <Link href={href}>{conteudo}</Link> : conteudo;
}
