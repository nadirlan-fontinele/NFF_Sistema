import Link from "next/link";
import { Plus } from "lucide-react";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { BarraFiltros } from "@/components/shared/busca";
import { EmptyState } from "@/components/shared/empty-state";
import { StatusBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatarData, formatarMoeda } from "@/lib/format";
import { termoBusca } from "@/lib/acoes";

export const metadata = { title: "Contratos" };

export default async function ContratosPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  const sessao = await exigirPermissao("contratos.ver");
  const { q, status } = await searchParams;
  const supabase = await createClient();
  let query = supabase.from("vw_contratos_resumo").select("*").order("numero", { ascending: false }).limit(300);
  const termo = termoBusca(q);
  if (termo) query = query.or(`numero.ilike.%${termo}%,cliente_nome.ilike.%${termo}%,cliente_razao_social.ilike.%${termo}%`);
  if (status) query = query.eq("status", status);
  const { data: contratos, error } = await query;
  const verValores = sessao.pode("contratos.ver_valores");
  const total = (contratos ?? []).filter((c) => c.status === "ativo").reduce((s, c) => s + Number(c.valor_mensal), 0);

  return (
    <>
      <PageHeader
        titulo="Contratos"
        descricao={
          sessao.pode("contratos.ver_todos")
            ? "Contratos de prestação de serviço, postos e aditivos."
            : "Contratos sob sua supervisão."
        }
        acoes={sessao.pode("contratos.criar") && <Button asChild><Link href="/contratos/novo"><Plus /> Novo contrato</Link></Button>}
      />
      <Card>
        <BarraFiltros
          placeholder="Buscar por número ou cliente"
          filtros={[{ nome: "status", label: "Situação", opcoes: [
            { valor: "ativo", label: "Ativo" }, { valor: "rascunho", label: "Rascunho" },
            { valor: "suspenso", label: "Suspenso" }, { valor: "encerrado", label: "Encerrado" },
          ] }]}
        />
        {error && <p className="p-4 text-sm text-destructive">Erro ao carregar contratos.</p>}
        {contratos && contratos.length === 0 ? (
          <EmptyState titulo="Nenhum contrato encontrado" descricao={termo || status ? "Ajuste os filtros." : "Cadastre um cliente e crie o primeiro contrato."} />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Contrato</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead className="hidden md:table-cell">Vigência</TableHead>
                <TableHead className="text-center">Postos</TableHead>
                <TableHead className="hidden lg:table-cell">Supervisor</TableHead>
                {verValores && <TableHead className="text-right">Valor mensal</TableHead>}
                <TableHead>Situação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contratos?.map((c) => (
                <TableRow key={c.id}>
                  <TableCell><Link href={`/contratos/${c.id}`} className="font-medium text-primary hover:underline">{c.numero}</Link></TableCell>
                  <TableCell className="max-w-56 truncate">{c.cliente_nome}</TableCell>
                  <TableCell className="hidden whitespace-nowrap md:table-cell">
                    {formatarData(c.data_inicio)} a {c.data_fim ? formatarData(c.data_fim) : "indeterm."}
                  </TableCell>
                  <TableCell className="text-center">{c.postos_contratados}</TableCell>
                  <TableCell className="hidden lg:table-cell">{c.supervisor_nome ?? "—"}</TableCell>
                  {verValores && <TableCell className="text-right whitespace-nowrap">{formatarMoeda(c.valor_mensal)}</TableCell>}
                  <TableCell><StatusBadge status={c.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        {verValores && contratos && contratos.length > 0 && (
          <div className="border-t px-4 py-3 text-right text-sm text-muted-foreground">
            Receita mensal dos contratos ativos listados: <span className="font-semibold text-foreground">{formatarMoeda(total)}</span>
          </div>
        )}
      </Card>
    </>
  );
}
