import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormPosto } from "@/modules/contratos/components/form-posto";
import { opcoesPosto } from "@/modules/contratos/dados";

export const metadata = { title: "Novo posto" };

export default async function NovoPostoPage({ params }: { params: Promise<{ id: string }> }) {
  const sessao = await exigirPermissao("contratos.editar");
  const { id } = await params;
  const supabase = await createClient();
  const { data: contrato } = await supabase.from("contratos").select("id, numero, cliente_id").eq("id", id).maybeSingle();
  if (!contrato) notFound();
  const opcoes = await opcoesPosto(contrato.cliente_id);
  return (
    <>
      <PageHeader titulo="Novo posto" descricao={`Contrato ${contrato.numero}`} voltar={{ href: `/contratos/${id}`, label: contrato.numero }} />
      <FormPosto contratoId={id} {...opcoes} verValores={sessao.pode("contratos.ver_valores")}
        inicial={{ horario_entrada: "08:00", horario_saida: "17:48", intervalo_minutos: 60, quantidade: 1 }} />
    </>
  );
}
