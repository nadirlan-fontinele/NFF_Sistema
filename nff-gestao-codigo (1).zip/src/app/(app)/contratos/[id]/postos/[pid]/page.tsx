import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { BotaoExcluir } from "@/components/shared/botao-excluir";
import { FormPosto } from "@/modules/contratos/components/form-posto";
import { opcoesPosto } from "@/modules/contratos/dados";
import { excluirPosto } from "@/modules/contratos/actions";

export const metadata = { title: "Editar posto" };

export default async function EditarPostoPage({ params }: { params: Promise<{ id: string; pid: string }> }) {
  const sessao = await exigirPermissao("contratos.editar");
  const { id, pid } = await params;
  const supabase = await createClient();
  const [{ data: contrato }, { data: posto }] = await Promise.all([
    supabase.from("contratos").select("id, numero, cliente_id").eq("id", id).maybeSingle(),
    supabase.from("contrato_postos").select("*").eq("id", pid).eq("contrato_id", id).maybeSingle(),
  ]);
  if (!contrato || !posto) notFound();
  const opcoes = await opcoesPosto(contrato.cliente_id);
  return (
    <>
      <PageHeader
        titulo="Editar posto"
        descricao={`Contrato ${contrato.numero}`}
        voltar={{ href: `/contratos/${id}`, label: contrato.numero }}
        acoes={
          <BotaoExcluir
            acao={excluirPosto.bind(null, id, pid)}
            titulo="Excluir posto?"
            descricao="Use a exclusão apenas para corrigir cadastros. Para encerrar um posto com histórico, desmarque 'Posto ativo'."
          />
        }
      />
      <FormPosto contratoId={id} id={pid} inicial={posto} {...opcoes} verValores={sessao.pode("contratos.ver_valores")} />
    </>
  );
}
