import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormContrato } from "@/modules/contratos/components/form-contrato";
import { opcoesContrato } from "@/modules/contratos/dados";

export const metadata = { title: "Editar contrato" };

export default async function EditarContratoPage({ params }: { params: Promise<{ id: string }> }) {
  const sessao = await exigirPermissao("contratos.editar");
  const { id } = await params;
  const supabase = await createClient();
  const [{ data: contrato }, opcoes] = await Promise.all([
    supabase.from("contratos").select("*").eq("id", id).maybeSingle(),
    opcoesContrato(),
  ]);
  if (!contrato) notFound();
  return (
    <>
      <PageHeader titulo={`Editar contrato ${contrato.numero}`} voltar={{ href: `/contratos/${id}`, label: contrato.numero }} />
      <FormContrato id={id} inicial={contrato} {...opcoes} verValores={sessao.pode("contratos.ver_valores")} />
    </>
  );
}
