import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormAditivo } from "@/modules/contratos/components/form-aditivo";

export const metadata = { title: "Novo aditivo" };

export default async function NovoAditivoPage({ params }: { params: Promise<{ id: string }> }) {
  await exigirPermissao("contratos.editar");
  await exigirPermissao("contratos.ver_valores");
  const { id } = await params;
  const supabase = await createClient();
  const [{ data: contrato }, { count }] = await Promise.all([
    supabase.from("contratos").select("id, numero").eq("id", id).maybeSingle(),
    supabase.from("contrato_aditivos").select("id", { count: "exact", head: true }).eq("contrato_id", id),
  ]);
  if (!contrato) notFound();
  return (
    <>
      <PageHeader titulo="Novo aditivo" descricao={`Contrato ${contrato.numero}`} voltar={{ href: `/contratos/${id}`, label: contrato.numero }} />
      <FormAditivo contratoId={id} proximoNumero={String((count ?? 0) + 1)} />
    </>
  );
}
