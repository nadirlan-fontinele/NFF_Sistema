import Link from "next/link";
import { notFound } from "next/navigation";
import { AlertTriangle, Pencil, Plus } from "lucide-react";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/empty-state";
import { BotaoExcluir } from "@/components/shared/botao-excluir";
import { Info } from "@/components/shared/info";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatarData, formatarDataHora, formatarHora, formatarMoeda, formatarNumero } from "@/lib/format";
import { AcoesStatus } from "@/modules/contratos/components/acoes-status";
import { excluirContrato } from "@/modules/contratos/actions";
import { TIPOS_ADITIVO, type StatusContrato } from "@/modules/contratos/schema";

type PostoLinha = {
  id: string; quantidade: number; descricao: string | null; horario_entrada: string; horario_saida: string;
  intervalo_minutos: number; valor_unitario: number; valor_total: number; ativo: boolean;
  cliente_unidades: { nome: string } | null; funcoes: { nome: string } | null; escalas_modelo: { nome: string } | null;
};

export default async function ContratoPage({ params }: { params: Promise<{ id: string }> }) {
  const sessao = await exigirPermissao("contratos.ver");
  const { id } = await params;
  const supabase = await createClient();
  const [{ data: c }, { data: postosRaw }, { data: aditivos }, { data: historico }] = await Promise.all([
    supabase.from("contratos").select("*, clientes(id, razao_social, nome_fantasia), supervisor:usuarios!contratos_supervisor_id_fkey(nome)").eq("id", id).maybeSingle(),
    supabase.from("contrato_postos").select("*, cliente_unidades(nome), funcoes(nome), escalas_modelo(nome)").eq("contrato_id", id).order("created_at"),
    supabase.from("contrato_aditivos").select("*").eq("contrato_id", id).order("vigencia_inicio", { ascending: false }),
    sessao.pode("admin.auditoria")
      ? supabase.from("auditoria_log").select("id, tabela, acao, campos_alterados, created_at, usuario_id").eq("registro_id", id).order("created_at", { ascending: false }).limit(10)
      : Promise.resolve({ data: null }),
  ]);
  if (!c) notFound();

  const postos = (postosRaw ?? []) as unknown as PostoLinha[];
  const ativos = postos.filter((p) => p.ativo);
  const qtdPostos = ativos.reduce((s, p) => s + p.quantidade, 0);
  const somaPostos = ativos.reduce((s, p) => s + Number(p.valor_total), 0);
  const unidades = new Set(ativos.map((p) => p.cliente_unidades?.nome)).size;
  const verValores = sessao.pode("contratos.ver_valores");
  const podeEditar = sessao.pode("contratos.editar") && c.status !== "encerrado";
  const cliente = c.clientes as unknown as { id: string; razao_social: string; nome_fantasia: string | null };
  const supervisor = c.supervisor as unknown as { nome: string } | null;
  const diferenca = Math.abs(Number(c.valor_mensal) - somaPostos) > 0.009;
  const diasRestantes = c.data_fim ? Math.ceil((new Date(c.data_fim + "T23:59:59-03:00").getTime() - Date.now()) / 86400000) : null;

  return (
    <>
      <PageHeader
        titulo={`Contrato ${c.numero}`}
        voltar={{ href: "/contratos", label: "Contratos" }}
        descricao={
          <span className="flex flex-wrap items-center gap-2">
            <StatusBadge status={c.status} />
            <Link href={`/clientes/${cliente.id}`} className="text-primary hover:underline">{cliente.nome_fantasia || cliente.razao_social}</Link>
          </span>
        }
        acoes={
          <>
            {c.status === "rascunho" && sessao.pode("contratos.excluir") && (
              <BotaoExcluir acao={excluirContrato.bind(null, c.id)} titulo="Excluir contrato em rascunho?" descricao="O contrato e seus postos serão excluídos definitivamente." />
            )}
            {podeEditar && <Button variant="outline" asChild><Link href={`/contratos/${c.id}/editar`}><Pencil /> Editar</Link></Button>}
            {sessao.pode("contratos.editar") && <AcoesStatus id={c.id} status={c.status as StatusContrato} />}
          </>
        }
      />

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi titulo="Postos contratados" valor={formatarNumero(qtdPostos)} detalhe={`${ativos.length} tipo(s) de posto`} />
        <Kpi titulo="Unidades atendidas" valor={formatarNumero(unidades)} />
        {verValores ? (
          <Kpi titulo="Valor mensal" valor={formatarMoeda(c.valor_mensal)} detalhe={`Soma dos postos: ${formatarMoeda(somaPostos)}`} alerta={diferenca && postos.length > 0} />
        ) : (
          <Kpi titulo="Supervisor" valor={supervisor?.nome ?? "—"} />
        )}
        <Kpi
          titulo="Vigência"
          valor={c.data_fim ? `${formatarData(c.data_inicio)} a ${formatarData(c.data_fim)}` : `Desde ${formatarData(c.data_inicio)}`}
          detalhe={diasRestantes !== null ? (diasRestantes >= 0 ? `${diasRestantes} dias restantes` : "Vencido") : "Prazo indeterminado"}
          alerta={diasRestantes !== null && diasRestantes <= 60}
        />
      </div>

      {c.status === "rascunho" && (
        <div className="mb-4 flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          <span>Contrato em rascunho. Cadastre os postos e clique em <strong>Ativar contrato</strong> para liberá-lo para a operação.</span>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-base">Postos</CardTitle>
              {podeEditar && <Button size="sm" variant="outline" asChild><Link href={`/contratos/${c.id}/postos/novo`}><Plus /> Posto</Link></Button>}
            </CardHeader>
            {postos.length === 0 ? (
              <EmptyState titulo="Nenhum posto cadastrado" descricao="Informe função, unidade, escala, horário e quantidade de cada posto." />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Função</TableHead>
                    <TableHead>Unidade</TableHead>
                    <TableHead className="hidden md:table-cell">Escala e horário</TableHead>
                    <TableHead className="text-center">Qtd.</TableHead>
                    {verValores && <TableHead className="text-right">Valor/posto</TableHead>}
                    {verValores && <TableHead className="hidden text-right sm:table-cell">Total</TableHead>}
                    <TableHead />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {postos.map((p) => (
                    <TableRow key={p.id} className={p.ativo ? "" : "opacity-60"}>
                      <TableCell>
                        <div className="font-medium">{p.funcoes?.nome}</div>
                        {p.descricao && <div className="text-xs text-muted-foreground">{p.descricao}</div>}
                        {!p.ativo && <Badge variant="secondary">Inativo</Badge>}
                      </TableCell>
                      <TableCell>{p.cliente_unidades?.nome}</TableCell>
                      <TableCell className="hidden md:table-cell">
                        <div>{p.escalas_modelo?.nome}</div>
                        <div className="text-xs text-muted-foreground">{formatarHora(p.horario_entrada)} às {formatarHora(p.horario_saida)} · intervalo {p.intervalo_minutos} min</div>
                      </TableCell>
                      <TableCell className="text-center">{p.quantidade}</TableCell>
                      {verValores && <TableCell className="text-right whitespace-nowrap">{formatarMoeda(p.valor_unitario)}</TableCell>}
                      {verValores && <TableCell className="hidden text-right whitespace-nowrap sm:table-cell">{formatarMoeda(p.valor_total)}</TableCell>}
                      <TableCell className="text-right">
                        {podeEditar && <Button size="sm" variant="ghost" asChild><Link href={`/contratos/${c.id}/postos/${p.id}`}>Editar</Link></Button>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Card>

          {verValores && (
            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="text-base">Aditivos e reajustes</CardTitle>
                {podeEditar && <Button size="sm" variant="outline" asChild><Link href={`/contratos/${c.id}/aditivos/novo`}><Plus /> Aditivo</Link></Button>}
              </CardHeader>
              {aditivos && aditivos.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow><TableHead>Nº</TableHead><TableHead>Tipo</TableHead><TableHead>Vigência</TableHead><TableHead className="text-right">De</TableHead><TableHead className="text-right">Para</TableHead></TableRow>
                  </TableHeader>
                  <TableBody>
                    {aditivos.map((a) => (
                      <TableRow key={a.id}>
                        <TableCell>{a.numero}</TableCell>
                        <TableCell>{TIPOS_ADITIVO[a.tipo]}{a.percentual != null && ` (${Number(a.percentual).toLocaleString("pt-BR")}%)`}</TableCell>
                        <TableCell>{formatarData(a.vigencia_inicio)}</TableCell>
                        <TableCell className="text-right">{a.valor_mensal_novo != null ? formatarMoeda(a.valor_mensal_anterior) : "—"}</TableCell>
                        <TableCell className="text-right">{a.valor_mensal_novo != null ? formatarMoeda(a.valor_mensal_novo) : a.nova_data_fim ? `até ${formatarData(a.nova_data_fim)}` : "—"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <EmptyState titulo="Nenhum aditivo registrado" />
              )}
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Dados do contrato</CardTitle></CardHeader>
            <CardContent>
              <dl className="grid gap-3">
                <Info label="Objeto">{c.objeto}</Info>
                <Info label="Supervisor">{supervisor?.nome}</Info>
                <Info label="Reajuste">{c.indice_reajuste ? `${c.indice_reajuste}${c.data_base_reajuste ? `, data-base ${formatarData(c.data_base_reajuste)}` : ""}` : null}</Info>
                <Info label="Cobertura mínima">{c.sla_cobertura_pct != null ? `${Number(c.sla_cobertura_pct).toLocaleString("pt-BR")}%` : null}</Info>
                <Info label="Prazo de substituição">{c.prazo_substituicao_horas != null ? `${c.prazo_substituicao_horas} h` : null}</Info>
                <Info label="Regras de substituição"><span className="whitespace-pre-line">{c.regras_substituicao}</span></Info>
                <Info label="Obrigações"><span className="whitespace-pre-line">{c.obrigacoes}</span></Info>
                <Info label="Observações"><span className="whitespace-pre-line">{c.observacoes}</span></Info>
              </dl>
            </CardContent>
          </Card>
          {historico && (
            <Card>
              <CardHeader><CardTitle className="text-base">Histórico de alterações</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  {historico.length === 0 && <li className="text-muted-foreground">Sem registros.</li>}
                  {historico.map((h) => (
                    <li key={h.id} className="border-l-2 pl-3">
                      <div className="text-xs text-muted-foreground">{formatarDataHora(h.created_at)}</div>
                      <div>{h.acao === "INSERT" ? "Criado" : h.acao === "DELETE" ? "Excluído" : `Alterado: ${(h.campos_alterados ?? []).join(", ")}`}</div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

function Kpi({ titulo, valor, detalhe, alerta }: { titulo: string; valor: string; detalhe?: string; alerta?: boolean }) {
  return (
    <Card className="p-4">
      <div className="text-xs text-muted-foreground">{titulo}</div>
      <div className="mt-1 truncate text-lg font-semibold">{valor}</div>
      {detalhe && <div className={`mt-0.5 text-xs ${alerta ? "font-medium text-destructive" : "text-muted-foreground"}`}>{detalhe}</div>}
    </Card>
  );
}
