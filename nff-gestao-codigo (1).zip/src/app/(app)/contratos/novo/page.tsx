import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormContrato } from "@/modules/contratos/components/form-contrato";
import { opcoesContrato } from "@/modules/contratos/dados";

export const metadata = { title: "Novo contrato" };

export default async function NovoContratoPage({ searchParams }: { searchParams: Promise<{ cliente?: string }> }) {
  const sessao = await exigirPermissao("contratos.criar");
  const { cliente } = await searchParams;
  const supabase = await createClient();
  const [{ clientes, supervisores }, { data: numero }] = await Promise.all([
    opcoesContrato(),
    supabase.rpc("proximo_numero_contrato"),
  ]);
  return (
    <>
      <PageHeader
        titulo="Novo contrato"
        descricao="O contrato nasce como rascunho. Depois de cadastrar os postos, ative-o."
        voltar={{ href: "/contratos", label: "Contratos" }}
      />
      <FormContrato
        clientes={clientes}
        supervisores={supervisores}
        verValores={sessao.pode("contratos.ver_valores")}
        inicial={{ cliente_id: cliente ?? "", numero: (numero as string | null) ?? "", sla_cobertura_pct: 98, prazo_substituicao_horas: 2 }}
      />
    </>
  );
}
