import Link from "next/link";
import { UserPlus } from "lucide-react";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const metadata = { title: "Usuários" };

export default async function UsuariosPage() {
  await exigirPermissao("admin.usuarios");
  const supabase = await createClient();
  const { data: usuarios } = await supabase
    .from("usuarios")
    .select("id, nome, email, tipo, ativo, clientes(razao_social), usuario_perfis(perfis(nome))")
    .order("nome");
  return (
    <>
      <PageHeader
        titulo="Usuários"
        descricao="Equipe interna e acessos de clientes ao portal."
        acoes={<Button asChild><Link href="/admin/usuarios/novo"><UserPlus /> Convidar usuário</Link></Button>}
      />
      <Card>
        <Table>
          <TableHeader>
            <TableRow><TableHead>Nome</TableHead><TableHead className="hidden md:table-cell">E-mail</TableHead><TableHead>Tipo</TableHead><TableHead>Perfis</TableHead><TableHead>Situação</TableHead></TableRow>
          </TableHeader>
          <TableBody>
            {usuarios?.map((u) => {
              const perfis = (u.usuario_perfis as unknown as { perfis: { nome: string } }[]).map((p) => p.perfis.nome);
              const cliente = u.clientes as unknown as { razao_social: string } | null;
              return (
                <TableRow key={u.id}>
                  <TableCell><Link href={`/admin/usuarios/${u.id}`} className="font-medium text-primary hover:underline">{u.nome}</Link></TableCell>
                  <TableCell className="hidden md:table-cell">{u.email}</TableCell>
                  <TableCell>{u.tipo === "cliente" ? `Cliente: ${cliente?.razao_social ?? ""}` : u.tipo === "interno" ? "Interno" : "Colaborador"}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {perfis.length ? perfis.map((p) => <Badge key={p} variant="secondary">{p}</Badge>) : <span className="text-xs text-destructive">Sem perfil</span>}
                    </div>
                  </TableCell>
                  <TableCell>{u.ativo ? <Badge variant="success">Ativo</Badge> : <Badge variant="secondary">Bloqueado</Badge>}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </>
  );
}
