import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";
import { PageHeader } from "@/components/shared/page-header";
import { FormConvite } from "@/modules/admin/form-convite";

export const metadata = { title: "Convidar usuário" };

export default async function NovoUsuarioPage() {
  await exigirPermissao("admin.usuarios");
  const supabase = await createClient();
  const [{ data: perfis }, { data: clientes }] = await Promise.all([
    supabase.from("perfis").select("id, nome, codigo").order("nome"),
    supabase.from("clientes").select("id, razao_social").eq("status", "ativo").order("razao_social"),
  ]);
  return (
    <>
      <PageHeader titulo="Convidar usuário" voltar={{ href: "/admin/usuarios", label: "Usuários" }} />
      <FormConvite perfis={perfis ?? []} clientes={(clientes ?? []).map((c) => ({ id: c.id, nome: c.razao_social }))} habilitado={!!env.supabaseServiceRoleKey} />
    </>
  );
}
