import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormUsuario } from "@/modules/admin/form-usuario";

export const metadata = { title: "Usuário" };

export default async function UsuarioPage({ params }: { params: Promise<{ id: string }> }) {
  await exigirPermissao("admin.usuarios");
  const { id } = await params;
  const supabase = await createClient();
  const [{ data: u }, { data: perfis }, { data: atuais }] = await Promise.all([
    supabase.from("usuarios").select("*").eq("id", id).maybeSingle(),
    supabase.from("perfis").select("id, nome, descricao, codigo").order("nome"),
    supabase.from("usuario_perfis").select("perfil_id").eq("usuario_id", id),
  ]);
  if (!u) notFound();
  const disponiveis = (perfis ?? []).filter((p) => (u.tipo === "cliente" ? p.codigo === "cliente" : p.codigo !== "cliente"));
  return (
    <>
      <PageHeader titulo={u.nome} descricao={u.email} voltar={{ href: "/admin/usuarios", label: "Usuários" }} />
      <FormUsuario id={u.id} nome={u.nome} telefone={u.telefone} ativo={u.ativo} perfis={disponiveis} selecionados={(atuais ?? []).map((a) => a.perfil_id)} />
    </>
  );
}
