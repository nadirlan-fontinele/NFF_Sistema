import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { BarraFiltros } from "@/components/shared/busca";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatarDataHora } from "@/lib/format";

export const metadata = { title: "Auditoria" };

const TABELAS: Record<string, string> = {
  clientes: "Clientes", cliente_unidades: "Unidades", contratos: "Contratos", contrato_postos: "Postos",
  contrato_aditivos: "Aditivos", contrato_indicadores: "Indicadores", funcoes: "Funções", escalas_modelo: "Escalas",
  usuarios: "Usuários", perfis: "Perfis", perfil_permissoes: "Permissões de perfil", usuario_perfis: "Perfis de usuário",
};

export default async function AuditoriaPage({ searchParams }: { searchParams: Promise<{ tabela?: string; acao?: string }> }) {
  await exigirPermissao("admin.auditoria");
  const { tabela, acao } = await searchParams;
  const supabase = await createClient();
  let q = supabase.from("auditoria_log").select("*").order("created_at", { ascending: false }).limit(200);
  if (tabela) q = q.eq("tabela", tabela);
  if (acao) q = q.eq("acao", acao);
  const [{ data: logs }, { data: usuarios }] = await Promise.all([q, supabase.from("usuarios").select("id, nome")]);
  const nomes = new Map((usuarios ?? []).map((u) => [u.id, u.nome]));

  return (
    <>
      <PageHeader titulo="Auditoria" descricao="Registro automático de inclusões, alterações e exclusões (últimos 200 eventos)." />
      <Card>
        <BarraFiltros
          placeholder="(filtre pelos campos ao lado)"
          filtros={[
            { nome: "tabela", label: "Cadastro", opcoes: Object.entries(TABELAS).map(([valor, label]) => ({ valor, label })) },
            { nome: "acao", label: "Ação", opcoes: [{ valor: "INSERT", label: "Inclusão" }, { valor: "UPDATE", label: "Alteração" }, { valor: "DELETE", label: "Exclusão" }] },
          ]}
        />
        <Table>
          <TableHeader>
            <TableRow><TableHead>Data e hora</TableHead><TableHead>Usuário</TableHead><TableHead>Cadastro</TableHead><TableHead>Ação</TableHead><TableHead>Campos alterados</TableHead></TableRow>
          </TableHeader>
          <TableBody>
            {logs?.map((l) => {
              const reg = (l.dados_depois ?? l.dados_antes) as Record<string, unknown> | null;
              const rotulo = (reg?.numero ?? reg?.razao_social ?? reg?.nome ?? "") as string;
              return (
                <TableRow key={l.id}>
                  <TableCell className="whitespace-nowrap">{formatarDataHora(l.created_at)}</TableCell>
                  <TableCell>{l.usuario_id ? nomes.get(l.usuario_id) ?? "—" : "Sistema"}</TableCell>
                  <TableCell>{TABELAS[l.tabela] ?? l.tabela}{rotulo && <div className="text-xs text-muted-foreground">{rotulo}</div>}</TableCell>
                  <TableCell>
                    <Badge variant={l.acao === "DELETE" ? "destructive" : l.acao === "INSERT" ? "success" : "default"}>
                      {l.acao === "INSERT" ? "Inclusão" : l.acao === "UPDATE" ? "Alteração" : "Exclusão"}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-72 truncate text-xs text-muted-foreground">{(l.campos_alterados ?? []).join(", ") || "—"}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </>
  );
}
