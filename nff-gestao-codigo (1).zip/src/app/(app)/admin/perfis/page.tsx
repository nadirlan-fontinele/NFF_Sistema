import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { Card } from "@/components/ui/card";
import { MatrizPermissoes } from "@/modules/admin/matriz-permissoes";

export const metadata = { title: "Perfis e permissões" };

export default async function PerfisPage() {
  await exigirPermissao("admin.perfis");
  const supabase = await createClient();
  const [{ data: perfis }, { data: permissoes }, { data: vinculos }] = await Promise.all([
    supabase.from("perfis").select("id, nome, codigo").order("nome"),
    supabase.from("permissoes").select("id, modulo, acao, descricao").order("modulo").order("acao"),
    supabase.from("perfil_permissoes").select("perfil_id, permissao_id"),
  ]);
  return (
    <>
      <PageHeader
        titulo="Perfis e permissões"
        descricao="Marque o que cada perfil pode fazer. As mudanças valem imediatamente e são aplicadas também no banco de dados."
      />
      <Card className="p-2">
        <MatrizPermissoes
          perfis={perfis ?? []}
          permissoes={permissoes ?? []}
          ativos={(vinculos ?? []).map((v) => `${v.perfil_id}:${v.permissao_id}`)}
          editavel
        />
      </Card>
    </>
  );
}
