import { notFound } from "next/navigation";
import { Construction } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { ETAPAS_FUTURAS } from "@/components/layout/nav";

export default async function EmBreve({ params }: { params: Promise<{ modulo: string }> }) {
  const { modulo } = await params;
  const info = ETAPAS_FUTURAS[modulo];
  if (!info) notFound();
  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
        <Construction className="size-12 text-warning" />
        <h1 className="text-xl font-semibold">{info.titulo}</h1>
        <p className="text-sm font-medium text-primary">Previsto para a Etapa {info.etapa}</p>
        <p className="max-w-lg text-sm text-muted-foreground">{info.descricao}</p>
      </CardContent>
    </Card>
  );
}
