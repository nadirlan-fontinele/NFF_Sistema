import { exigirPermissao } from "@/lib/auth";
import { PageHeader } from "@/components/shared/page-header";
import { FormCliente } from "@/modules/clientes/components/form-cliente";

export const metadata = { title: "Novo cliente" };

export default async function NovoClientePage() {
  await exigirPermissao("clientes.criar");
  return (
    <>
      <PageHeader titulo="Novo cliente" voltar={{ href: "/clientes", label: "Clientes" }} />
      <FormCliente />
    </>
  );
}
