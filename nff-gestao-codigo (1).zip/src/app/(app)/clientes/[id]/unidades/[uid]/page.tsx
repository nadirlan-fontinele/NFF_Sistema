import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormUnidade } from "@/modules/clientes/components/form-unidade";

export const metadata = { title: "Editar unidade" };

export default async function EditarUnidadePage({ params }: { params: Promise<{ id: string; uid: string }> }) {
  await exigirPermissao("clientes.editar");
  const { id, uid } = await params;
  const supabase = await createClient();
  const { data } = await supabase.from("cliente_unidades").select("*, clientes(razao_social)").eq("id", uid).eq("cliente_id", id).maybeSingle();
  if (!data) notFound();
  const nomeCliente = (data.clientes as unknown as { razao_social: string }).razao_social;
  return (
    <>
      <PageHeader titulo={`Editar unidade: ${data.nome}`} voltar={{ href: `/clientes/${id}`, label: nomeCliente }} />
      <FormUnidade clienteId={id} id={uid} inicial={data} />
    </>
  );
}
