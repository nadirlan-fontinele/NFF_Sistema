import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormUnidade } from "@/modules/clientes/components/form-unidade";

export const metadata = { title: "Nova unidade" };

export default async function NovaUnidadePage({ params }: { params: Promise<{ id: string }> }) {
  await exigirPermissao("clientes.criar");
  const { id } = await params;
  const supabase = await createClient();
  const { data: cliente } = await supabase.from("clientes").select("id, razao_social").eq("id", id).maybeSingle();
  if (!cliente) notFound();
  return (
    <>
      <PageHeader titulo="Nova unidade" descricao={cliente.razao_social} voltar={{ href: `/clientes/${id}`, label: cliente.razao_social }} />
      <FormUnidade clienteId={id} />
    </>
  );
}
