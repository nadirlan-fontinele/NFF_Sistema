import { notFound } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { FormCliente } from "@/modules/clientes/components/form-cliente";

export const metadata = { title: "Editar cliente" };

export default async function EditarClientePage({ params }: { params: Promise<{ id: string }> }) {
  await exigirPermissao("clientes.editar");
  const { id } = await params;
  const supabase = await createClient();
  const { data } = await supabase.from("clientes").select("*").eq("id", id).maybeSingle();
  if (!data) notFound();
  return (
    <>
      <PageHeader titulo="Editar cliente" voltar={{ href: `/clientes/${id}`, label: data.razao_social }} />
      <FormCliente id={id} inicial={data} />
    </>
  );
}
