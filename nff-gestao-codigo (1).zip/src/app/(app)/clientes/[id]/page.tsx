import Link from "next/link";
import { notFound } from "next/navigation";
import { Pencil, Plus, MapPin } from "lucide-react";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/empty-state";
import { BotaoExcluir } from "@/components/shared/botao-excluir";
import { Info } from "@/components/shared/info";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatarCep, formatarData, formatarDocumento, formatarMoeda } from "@/lib/format";
import { excluirCliente } from "@/modules/clientes/actions";

export default async function ClientePage({ params }: { params: Promise<{ id: string }> }) {
  const sessao = await exigirPermissao("clientes.ver");
  const { id } = await params;
  const supabase = await createClient();
  const [{ data: c }, { data: unidades }, { data: contratos }] = await Promise.all([
    supabase.from("clientes").select("*").eq("id", id).maybeSingle(),
    supabase.from("cliente_unidades").select("*").eq("cliente_id", id).order("nome"),
    supabase.from("vw_contratos_resumo").select("*").eq("cliente_id", id).order("data_inicio", { ascending: false }),
  ]);
  if (!c) notFound();

  const endereco = [c.logradouro, c.numero, c.complemento, c.bairro].filter(Boolean).join(", ");
  const verValores = sessao.pode("contratos.ver_valores");

  return (
    <>
      <PageHeader
        titulo={c.nome_fantasia || c.razao_social}
        voltar={{ href: "/clientes", label: "Clientes" }}
        descricao={
          <span className="flex flex-wrap items-center gap-2">
            <StatusBadge status={c.status} />
            <span className="font-mono">{formatarDocumento(c.documento)}</span>
          </span>
        }
        acoes={
          <>
            {sessao.pode("clientes.excluir") && (
              <BotaoExcluir
                acao={excluirCliente.bind(null, c.id)}
                titulo="Excluir cliente?"
                descricao="As unidades também serão excluídas. Clientes com contratos não podem ser excluídos; nesse caso, altere a situação para Inativo."
              />
            )}
            {sessao.pode("clientes.editar") && (
              <Button variant="outline" asChild><Link href={`/clientes/${c.id}/editar`}><Pencil /> Editar</Link></Button>
            )}
            {sessao.pode("contratos.criar") && (
              <Button asChild><Link href={`/contratos/novo?cliente=${c.id}`}><Plus /> Novo contrato</Link></Button>
            )}
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle className="text-base">Dados do cliente</CardTitle></CardHeader>
          <CardContent>
            <dl className="grid gap-3">
              <Info label="Razão social">{c.razao_social}</Info>
              <Info label="Inscrição estadual/municipal">{c.inscricao_estadual}</Info>
              <Info label="Contato">{c.contato_nome}</Info>
              <Info label="Telefone">{c.telefone}</Info>
              <Info label="E-mail">{c.email}</Info>
              <Info label="Endereço">
                {endereco ? `${endereco} · ${c.cidade ?? ""}/${c.uf ?? ""} · ${formatarCep(c.cep)}` : null}
              </Info>
              <Info label="Observações">{c.observacoes}</Info>
            </dl>
          </CardContent>
        </Card>

        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-base">Unidades ({unidades?.length ?? 0})</CardTitle>
              {sessao.pode("clientes.criar") && (
                <Button size="sm" variant="outline" asChild><Link href={`/clientes/${c.id}/unidades/nova`}><Plus /> Unidade</Link></Button>
              )}
            </CardHeader>
            {unidades && unidades.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Unidade</TableHead><TableHead className="hidden sm:table-cell">Local</TableHead><TableHead className="hidden md:table-cell">Responsável</TableHead><TableHead /></TableRow>
                </TableHeader>
                <TableBody>
                  {unidades.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">
                        {u.nome} {!u.ativo && <Badge variant="secondary" className="ml-1">Inativa</Badge>}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <span className="inline-flex items-center gap-1 text-muted-foreground"><MapPin className="size-3.5" />{u.bairro ? `${u.bairro}, ` : ""}{u.cidade ?? "—"}{u.uf ? `/${u.uf}` : ""}</span>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{u.responsavel_nome ?? "—"}</TableCell>
                      <TableCell className="text-right">
                        {sessao.pode("clientes.editar") && (
                          <Button size="sm" variant="ghost" asChild><Link href={`/clientes/${c.id}/unidades/${u.id}`}>Editar</Link></Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <EmptyState titulo="Nenhuma unidade" descricao="Cadastre as unidades onde os postos serão atendidos." />
            )}
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Contratos ({contratos?.length ?? 0})</CardTitle></CardHeader>
            {contratos && contratos.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Número</TableHead><TableHead>Vigência</TableHead><TableHead className="text-center">Postos</TableHead>
                    {verValores && <TableHead className="text-right">Valor mensal</TableHead>}
                    <TableHead>Situação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contratos.map((k) => (
                    <TableRow key={k.id}>
                      <TableCell><Link className="font-medium text-primary hover:underline" href={`/contratos/${k.id}`}>{k.numero}</Link></TableCell>
                      <TableCell className="whitespace-nowrap">{formatarData(k.data_inicio)} a {k.data_fim ? formatarData(k.data_fim) : "indeterminado"}</TableCell>
                      <TableCell className="text-center">{k.postos_contratados}</TableCell>
                      {verValores && <TableCell className="text-right">{formatarMoeda(k.valor_mensal)}</TableCell>}
                      <TableCell><StatusBadge status={k.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <EmptyState titulo="Nenhum contrato visível" />
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
