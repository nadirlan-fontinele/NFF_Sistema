import Link from "next/link";
import { Plus } from "lucide-react";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { BarraFiltros } from "@/components/shared/busca";
import { EmptyState } from "@/components/shared/empty-state";
import { StatusBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatarDocumento, somenteDigitos } from "@/lib/format";
import { termoBusca } from "@/lib/acoes";

export const metadata = { title: "Clientes" };

export default async function ClientesPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  const sessao = await exigirPermissao("clientes.ver");
  const { q, status } = await searchParams;
  const supabase = await createClient();

  let query = supabase
    .from("clientes")
    .select("id, razao_social, nome_fantasia, documento, cidade, uf, status, cliente_unidades(count), contratos(count)")
    .order("razao_social")
    .limit(200);
  const termo = termoBusca(q);
  if (termo) {
    const dig = somenteDigitos(termo);
    query = query.or(
      [`razao_social.ilike.%${termo}%`, `nome_fantasia.ilike.%${termo}%`, dig.length >= 3 ? `documento.ilike.%${dig}%` : null]
        .filter(Boolean)
        .join(","),
    );
  }
  if (status) query = query.eq("status", status);
  const { data: clientes, error } = await query;

  return (
    <>
      <PageHeader
        titulo="Clientes"
        descricao="Empresas atendidas e suas unidades."
        acoes={
          sessao.pode("clientes.criar") && (
            <Button asChild><Link href="/clientes/novo"><Plus /> Novo cliente</Link></Button>
          )
        }
      />
      <Card>
        <BarraFiltros
          placeholder="Buscar por nome ou CNPJ/CPF"
          filtros={[{ nome: "status", label: "Situação", opcoes: [
            { valor: "ativo", label: "Ativo" }, { valor: "prospecto", label: "Prospecto" }, { valor: "inativo", label: "Inativo" },
          ] }]}
        />
        {error && <p className="p-4 text-sm text-destructive">Erro ao carregar clientes.</p>}
        {clientes && clientes.length === 0 ? (
          <EmptyState
            titulo={termo || status ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado"}
            descricao={termo || status ? "Ajuste os filtros da busca." : "Cadastre o primeiro cliente para criar contratos."}
          />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead className="hidden md:table-cell">CNPJ/CPF</TableHead>
                <TableHead className="hidden lg:table-cell">Cidade</TableHead>
                <TableHead className="text-center">Unidades</TableHead>
                <TableHead className="text-center">Contratos</TableHead>
                <TableHead>Situação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clientes?.map((c) => (
                <TableRow key={c.id}>
                  <TableCell>
                    <Link href={`/clientes/${c.id}`} className="font-medium text-primary hover:underline">
                      {c.nome_fantasia || c.razao_social}
                    </Link>
                    {c.nome_fantasia && <div className="text-xs text-muted-foreground">{c.razao_social}</div>}
                  </TableCell>
                  <TableCell className="hidden font-mono text-xs md:table-cell">{formatarDocumento(c.documento)}</TableCell>
                  <TableCell className="hidden lg:table-cell">{c.cidade ? `${c.cidade}/${c.uf ?? ""}` : "—"}</TableCell>
                  <TableCell className="text-center">{(c.cliente_unidades as unknown as { count: number }[])[0]?.count ?? 0}</TableCell>
                  <TableCell className="text-center">{(c.contratos as unknown as { count: number }[])[0]?.count ?? 0}</TableCell>
                  <TableCell><StatusBadge status={c.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </>
  );
}
