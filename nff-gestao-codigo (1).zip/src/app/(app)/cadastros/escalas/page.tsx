import Link from "next/link";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FormEscala } from "@/modules/cadastros/form-escala";

export const metadata = { title: "Escalas-modelo" };

export default async function EscalasPage({ searchParams }: { searchParams: Promise<{ editar?: string }> }) {
  const sessao = await exigirPermissao("cadastros.ver");
  const { editar } = await searchParams;
  const supabase = await createClient();
  const { data: escalas } = await supabase.from("escalas_modelo").select("*").order("nome");
  const emEdicao = editar ? escalas?.find((f) => f.id === editar) : undefined;
  const podeEditar = sessao.pode("cadastros.editar");

  return (
    <>
      <PageHeader titulo="Escalas-modelo" descricao="Modelos de escala usados nos postos. Na Etapa 3 eles geram as escalas diárias de cada colaborador." />
      {podeEditar && <div className="mb-4"><FormEscala id={emEdicao?.id} inicial={emEdicao} /></div>}
      <Card>
        <Table>
          <TableHeader>
            <TableRow><TableHead>Escala</TableHead><TableHead>Tipo</TableHead><TableHead>Ciclo</TableHead><TableHead>Jornada</TableHead><TableHead>Carga semanal</TableHead><TableHead>Situação</TableHead><TableHead /></TableRow>
          </TableHeader>
          <TableBody>
            {escalas?.map((s) => (
              <TableRow key={s.id}>
                <TableCell><div className="font-medium">{s.nome} {s.noturno && <Badge variant="secondary">Noturno</Badge>}</div>{s.descricao && <div className="text-xs text-muted-foreground">{s.descricao}</div>}</TableCell>
                <TableCell>{s.tipo}</TableCell>
                <TableCell>{s.dias_trabalho} trabalho / {s.dias_folga} folga</TableCell>
                <TableCell>{Number(s.horas_jornada).toLocaleString("pt-BR")} h</TableCell>
                <TableCell>{s.carga_semanal != null ? `${Number(s.carga_semanal).toLocaleString("pt-BR")} h` : "—"}</TableCell>
                <TableCell>{s.ativo ? <Badge variant="success">Ativa</Badge> : <Badge variant="secondary">Inativa</Badge>}</TableCell>
                <TableCell className="text-right">{podeEditar && <Link className="text-sm text-primary hover:underline" href={`?editar=${s.id}`}>Editar</Link>}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </>
  );
}
