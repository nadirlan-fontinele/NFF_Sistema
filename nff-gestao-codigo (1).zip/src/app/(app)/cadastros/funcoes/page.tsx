import Link from "next/link";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatarMoeda } from "@/lib/format";
import { FormFuncao } from "@/modules/cadastros/form-funcao";

export const metadata = { title: "Funções" };

export default async function FuncoesPage({ searchParams }: { searchParams: Promise<{ editar?: string }> }) {
  const sessao = await exigirPermissao("cadastros.ver");
  const { editar } = await searchParams;
  const supabase = await createClient();
  const { data: funcoes } = await supabase.from("funcoes").select("*").order("nome");
  const emEdicao = editar ? funcoes?.find((f) => f.id === editar) : undefined;
  const podeEditar = sessao.pode("cadastros.editar");
  const verSalario = sessao.pode("rh.ver_salario") || sessao.pode("contratos.ver_valores");

  return (
    <>
      <PageHeader titulo="Funções" descricao="Cargos oferecidos nos contratos (base para postos, vagas e formação de preço)." />
      {podeEditar && <div className="mb-4"><FormFuncao id={emEdicao?.id} inicial={emEdicao} /></div>}
      <Card>
        {!funcoes?.length ? (
          <EmptyState titulo="Nenhuma função cadastrada" descricao="Ex.: Auxiliar de limpeza, Recepcionista, Porteiro, Cozinheiro." />
        ) : (
          <Table>
            <TableHeader>
              <TableRow><TableHead>Função</TableHead><TableHead>CBO</TableHead>{verSalario && <TableHead className="text-right">Salário-base</TableHead>}<TableHead>Situação</TableHead><TableHead /></TableRow>
            </TableHeader>
            <TableBody>
              {funcoes.map((f) => (
                <TableRow key={f.id}>
                  <TableCell><div className="font-medium">{f.nome}</div>{f.descricao && <div className="text-xs text-muted-foreground">{f.descricao}</div>}</TableCell>
                  <TableCell>{f.cbo ?? "—"}</TableCell>
                  {verSalario && <TableCell className="text-right">{formatarMoeda(f.salario_base)}</TableCell>}
                  <TableCell>{f.ativo ? <Badge variant="success">Ativa</Badge> : <Badge variant="secondary">Inativa</Badge>}</TableCell>
                  <TableCell className="text-right">{podeEditar && <Link className="text-sm text-primary hover:underline" href={`?editar=${f.id}`}>Editar</Link>}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </>
  );
}
