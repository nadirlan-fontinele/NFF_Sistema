import { redirect } from "next/navigation";
import { exigirSessao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { sair } from "@/app/(auth)/actions";
import { StatusBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatarData } from "@/lib/format";

export const metadata = { title: "Portal do cliente" };

// Versão inicial do portal (Etapa 2). Indicadores, relatórios e chamados chegam na Etapa 8.
export default async function PortalPage() {
  const sessao = await exigirSessao();
  if (sessao.tipo !== "cliente") redirect("/");
  const supabase = await createClient();
  const [{ data: cliente }, { data: contratos }] = await Promise.all([
    supabase.from("clientes").select("razao_social, nome_fantasia").maybeSingle(),
    supabase.from("vw_contratos_resumo").select("id, numero, status, data_inicio, data_fim, postos_contratados, unidades"),
  ]);
  return (
    <div className="mx-auto max-w-4xl p-4 md:p-8">
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <div className="text-sm text-muted-foreground">Portal do cliente · NFF Gestão</div>
          <h1 className="text-2xl font-semibold">{cliente?.nome_fantasia || cliente?.razao_social}</h1>
        </div>
        <form action={sair}><Button variant="outline" type="submit">Sair</Button></form>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-base">Seus contratos</CardTitle></CardHeader>
        <CardContent>
          <ul className="divide-y">
            {(contratos ?? []).map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                <span className="font-medium">{c.numero}</span>
                <span className="text-muted-foreground">{formatarData(c.data_inicio)} a {c.data_fim ? formatarData(c.data_fim) : "indeterminado"}</span>
                <span>{c.postos_contratados} postos · {c.unidades} unidade(s)</span>
                <StatusBadge status={c.status} />
              </li>
            ))}
            {!contratos?.length && <li className="py-3 text-sm text-muted-foreground">Nenhum contrato disponível.</li>}
          </ul>
          <p className="mt-4 text-xs text-muted-foreground">Indicadores de presença, cobertura dos postos, relatórios e chamados estarão disponíveis em breve.</p>
        </CardContent>
      </Card>
    </div>
  );
}
