"use client";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { redefinirSenha } from "@/app/(auth)/actions";

export default function RedefinirSenhaPage() {
  const [estado, acao, pendente] = useActionState(redefinirSenha, undefined);
  return (
    <div className="flex min-h-dvh items-center justify-center p-6">
      <div className="w-full max-w-sm space-y-6">
        <div className="space-y-1">
          <h2 className="text-2xl font-semibold">Criar nova senha</h2>
          <p className="text-sm text-muted-foreground">Mínimo de 10 caracteres.</p>
        </div>
        <form action={acao} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="senha">Nova senha</Label>
            <Input id="senha" name="senha" type="password" autoComplete="new-password" required minLength={10} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirmacao">Confirme a senha</Label>
            <Input id="confirmacao" name="confirmacao" type="password" autoComplete="new-password" required />
          </div>
          {estado?.erro && <p className="text-sm text-destructive">{estado.erro}</p>}
          <Button type="submit" className="w-full" disabled={pendente}>{pendente ? "Salvando…" : "Salvar senha"}</Button>
        </form>
      </div>
    </div>
  );
}
