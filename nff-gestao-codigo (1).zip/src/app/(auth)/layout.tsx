export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between bg-sidebar p-10 text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-2.5">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">NFF</div>
          <span className="text-lg font-semibold">NFF Gestão</span>
        </div>
        <div className="max-w-md space-y-3">
          <h1 className="text-3xl font-semibold leading-tight text-white">
            Contratos, pessoas e resultados em um só lugar.
          </h1>
          <p className="text-sidebar-muted">
            Gestão integrada de terceirização de mão de obra: operação, RH, comercial, financeiro e marketing.
          </p>
        </div>
        <p className="text-xs text-sidebar-muted">Acesso restrito. Uso monitorado conforme a LGPD.</p>
      </div>
      <div className="flex items-center justify-center p-6">{children}</div>
    </div>
  );
}
