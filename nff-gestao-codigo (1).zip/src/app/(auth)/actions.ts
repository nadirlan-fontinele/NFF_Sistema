"use server";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";

export type EstadoAuth = { erro?: string; sucesso?: string } | undefined;

const loginSchema = z.object({
  email: z.string().trim().email("Informe um e-mail válido."),
  senha: z.string().min(1, "Informe a senha."),
  next: z.string().optional(),
});

export async function entrar(_: EstadoAuth, formData: FormData): Promise<EstadoAuth> {
  const dados = loginSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return { erro: dados.error.issues[0].message };

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: dados.data.email,
    password: dados.data.senha,
  });
  if (error) return { erro: "E-mail ou senha inválidos." };

  const destino = dados.data.next?.startsWith("/") && !dados.data.next.startsWith("//") ? dados.data.next : "/";
  redirect(destino);
}

export async function sair() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}

export async function recuperarSenha(_: EstadoAuth, formData: FormData): Promise<EstadoAuth> {
  const email = z.string().trim().email().safeParse(formData.get("email"));
  if (!email.success) return { erro: "Informe um e-mail válido." };
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email.data, {
    redirectTo: `${env.appUrl}/auth/confirm?next=/auth/redefinir-senha`,
  });
  // Mesma resposta exista ou não a conta (evita descobrir e-mails cadastrados)
  return { sucesso: "Se o e-mail estiver cadastrado, você receberá um link para criar uma nova senha." };
}

const senhaSchema = z
  .object({
    senha: z.string().min(10, "A senha deve ter pelo menos 10 caracteres."),
    confirmacao: z.string(),
  })
  .refine((d) => d.senha === d.confirmacao, { message: "As senhas não conferem.", path: ["confirmacao"] });

export async function redefinirSenha(_: EstadoAuth, formData: FormData): Promise<EstadoAuth> {
  const dados = senhaSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return { erro: dados.error.issues[0].message };
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: dados.data.senha });
  if (error) return { erro: "Não foi possível alterar a senha. Solicite um novo link." };
  redirect("/");
}
