import type { Metadata } from "next";
import { FormLogin } from "./form";

export const metadata: Metadata = { title: "Entrar" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; erro?: string }> }) {
  const { next, erro } = await searchParams;
  return (
    <div className="w-full max-w-sm space-y-6">
      <div className="space-y-1">
        <h2 className="text-2xl font-semibold">Entrar</h2>
        <p className="text-sm text-muted-foreground">Use o e-mail e a senha cadastrados pelo administrador.</p>
      </div>
      {erro === "sem-acesso" && (
        <p className="rounded-md bg-warning/15 p-3 text-sm">
          Sua conta ainda não está vinculada a uma empresa ou está inativa. Procure o administrador.
        </p>
      )}
      <FormLogin next={next} />
    </div>
  );
}
