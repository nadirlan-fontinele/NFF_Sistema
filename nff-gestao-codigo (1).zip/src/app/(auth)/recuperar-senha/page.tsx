"use client";
import Link from "next/link";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { recuperarSenha } from "../actions";

export default function RecuperarSenhaPage() {
  const [estado, acao, pendente] = useActionState(recuperarSenha, undefined);
  return (
    <div className="w-full max-w-sm space-y-6">
      <div className="space-y-1">
        <h2 className="text-2xl font-semibold">Recuperar senha</h2>
        <p className="text-sm text-muted-foreground">Enviaremos um link para você criar uma nova senha.</p>
      </div>
      <form action={acao} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">E-mail</Label>
          <Input id="email" name="email" type="email" required />
        </div>
        {estado?.erro && <p className="text-sm text-destructive">{estado.erro}</p>}
        {estado?.sucesso && <p className="rounded-md bg-success/10 p-3 text-sm">{estado.sucesso}</p>}
        <Button type="submit" className="w-full" disabled={pendente}>{pendente ? "Enviando…" : "Enviar link"}</Button>
      </form>
      <Link href="/login" className="block text-center text-sm text-primary hover:underline">Voltar ao login</Link>
    </div>
  );
}
