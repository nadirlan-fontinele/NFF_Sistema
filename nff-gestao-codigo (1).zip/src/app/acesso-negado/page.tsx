import Link from "next/link";
import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AcessoNegado() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-3 p-6 text-center">
      <ShieldAlert className="size-12 text-destructive" />
      <h1 className="text-xl font-semibold">Acesso negado</h1>
      <p className="max-w-sm text-sm text-muted-foreground">Seu perfil não tem permissão para acessar esta página.</p>
      <Button asChild variant="outline"><Link href="/">Voltar ao início</Link></Button>
    </div>
  );
}
