"use client";
import { useState } from "react";
import { Menu, LogOut, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SidebarConteudo } from "./sidebar";
import type { SecaoNav } from "./nav";
import { sair } from "@/app/(auth)/actions";

export function Topbar({
  secoes, nome, email, perfis, organizacao, demonstracao,
}: {
  secoes: SecaoNav[]; nome: string; email: string; perfis: string[]; organizacao: string; demonstracao: boolean;
}) {
  const [aberto, setAberto] = useState(false);
  const iniciais = nome.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("");

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-card/95 px-4 backdrop-blur md:px-6">
      <Sheet open={aberto} onOpenChange={setAberto}>
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setAberto(true)} aria-label="Abrir menu">
          <Menu />
        </Button>
        <SheetContent>
          <SheetTitle className="sr-only">Menu</SheetTitle>
          <SidebarConteudo secoes={secoes} aoNavegar={() => setAberto(false)} />
        </SheetContent>
      </Sheet>

      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium">{organizacao}</div>
        {demonstracao && (
          <div className="text-xs font-medium text-[oklch(0.5_0.13_70)]">Ambiente de demonstração · dados fictícios</div>
        )}
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2 rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <span className="hidden text-right text-sm leading-tight sm:block">
              <span className="block font-medium">{nome}</span>
              <span className="block text-xs text-muted-foreground">{perfis[0] ?? "Sem perfil"}</span>
            </span>
            <span className="flex size-9 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
              {iniciais || <User className="size-4" />}
            </span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuLabel>
            <div className="font-medium">{nome}</div>
            <div className="truncate text-xs font-normal text-muted-foreground">{email}</div>
          </DropdownMenuLabel>
          {perfis.length > 0 && (
            <div className="px-2 pb-1.5 text-xs text-muted-foreground">Perfis: {perfis.join(", ")}</div>
          )}
          <DropdownMenuSeparator />
          <form action={sair}>
            <DropdownMenuItem asChild>
              <button type="submit" className="w-full">
                <LogOut /> Sair
              </button>
            </DropdownMenuItem>
          </form>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
