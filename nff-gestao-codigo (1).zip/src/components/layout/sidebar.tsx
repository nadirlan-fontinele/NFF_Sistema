"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, FileText, Building2, CalendarClock, Users, UserSearch, Handshake, Wallet,
  Megaphone, BriefcaseBusiness, Repeat, UserCog, ShieldCheck, History, type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { SecaoNav } from "./nav";

const ICONES: Record<string, LucideIcon> = {
  LayoutDashboard, FileText, Building2, CalendarClock, Users, UserSearch, Handshake, Wallet,
  Megaphone, BriefcaseBusiness, Repeat, UserCog, ShieldCheck, History,
};

export function SidebarConteudo({ secoes, aoNavegar }: { secoes: SecaoNav[]; aoNavegar?: () => void }) {
  const pathname = usePathname();
  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-16 items-center gap-2.5 px-5">
        <div className="flex size-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">
          NFF
        </div>
        <div className="leading-tight">
          <div className="text-sm font-semibold">NFF Gestão</div>
          <div className="text-[11px] text-sidebar-muted">ERP de terceirização</div>
        </div>
      </div>
      <nav className="flex-1 space-y-5 overflow-y-auto px-3 pb-6">
        {secoes.map((secao) => (
          <div key={secao.titulo}>
            <div className="px-2 pb-1.5 text-[11px] font-medium uppercase tracking-wider text-sidebar-muted">
              {secao.titulo}
            </div>
            <ul className="space-y-0.5">
              {secao.itens.map((item) => {
                const Icone = ICONES[item.icone] ?? FileText;
                const ativo = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={aoNavegar}
                      className={cn(
                        "flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm transition-colors hover:bg-sidebar-accent",
                        ativo && "bg-sidebar-accent font-medium text-white",
                        item.etapa && "text-sidebar-muted",
                      )}
                    >
                      <Icone className="size-4 shrink-0" />
                      <span className="flex-1 truncate">{item.titulo}</span>
                      {item.etapa && (
                        <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-sidebar-muted">
                          Etapa {item.etapa}
                        </span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </div>
  );
}
