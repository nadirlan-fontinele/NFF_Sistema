import type { Permissao } from "@/lib/auth";

export type ItemNav = {
  titulo: string;
  href: string;
  icone: string; // nome do ícone lucide (mapeado em sidebar.tsx)
  permissao?: Permissao;
  etapa?: number; // módulo ainda não implementado: mostra "Em breve"
};

export type SecaoNav = { titulo: string; itens: ItemNav[] };

export const NAVEGACAO: SecaoNav[] = [
  {
    titulo: "Visão geral",
    itens: [{ titulo: "Dashboard", href: "/", icone: "LayoutDashboard" }],
  },
  {
    titulo: "Operacional",
    itens: [
      { titulo: "Contratos", href: "/contratos", icone: "FileText", permissao: "contratos.ver" },
      { titulo: "Clientes", href: "/clientes", icone: "Building2", permissao: "clientes.ver" },
      { titulo: "Escalas e frequência", href: "/em-breve/operacional", icone: "CalendarClock", permissao: "operacional.ver", etapa: 3 },
      { titulo: "Colaboradores", href: "/em-breve/colaboradores", icone: "Users", permissao: "rh.ver", etapa: 3 },
    ],
  },
  {
    titulo: "Recursos humanos",
    itens: [{ titulo: "Recrutamento", href: "/em-breve/recrutamento", icone: "UserSearch", permissao: "recrutamento.ver", etapa: 4 }],
  },
  {
    titulo: "Comercial",
    itens: [{ titulo: "CRM e propostas", href: "/em-breve/comercial", icone: "Handshake", permissao: "comercial.ver", etapa: 5 }],
  },
  {
    titulo: "Financeiro",
    itens: [{ titulo: "Financeiro", href: "/em-breve/financeiro", icone: "Wallet", permissao: "financeiro.ver", etapa: 6 }],
  },
  {
    titulo: "Marketing",
    itens: [{ titulo: "Marketing e IA", href: "/em-breve/marketing", icone: "Megaphone", permissao: "marketing.ver", etapa: 7 }],
  },
  {
    titulo: "Cadastros",
    itens: [
      { titulo: "Funções", href: "/cadastros/funcoes", icone: "BriefcaseBusiness", permissao: "cadastros.ver" },
      { titulo: "Escalas-modelo", href: "/cadastros/escalas", icone: "Repeat", permissao: "cadastros.ver" },
    ],
  },
  {
    titulo: "Administração",
    itens: [
      { titulo: "Usuários", href: "/admin/usuarios", icone: "UserCog", permissao: "admin.usuarios" },
      { titulo: "Perfis e permissões", href: "/admin/perfis", icone: "ShieldCheck", permissao: "admin.perfis" },
      { titulo: "Auditoria", href: "/admin/auditoria", icone: "History", permissao: "admin.auditoria" },
    ],
  },
];

export const ETAPAS_FUTURAS: Record<string, { titulo: string; etapa: number; descricao: string }> = {
  operacional: { titulo: "Escalas e frequência", etapa: 3, descricao: "Geração de escalas 5x2, 6x1 e 12x36, controle diário de presença, faltas, postos descobertos e substituições com indicadores." },
  colaboradores: { titulo: "Colaboradores", etapa: 3, descricao: "Cadastro de colaboradores, alocação em postos e histórico. Completado na Etapa 4 com admissão e documentos." },
  recrutamento: { titulo: "Recrutamento", etapa: 4, descricao: "Vagas, página pública de carreiras, banco de talentos, triagem por IA com revisão humana e Kanban do funil." },
  comercial: { titulo: "CRM e propostas", etapa: 5, descricao: "Leads, funil de vendas em Kanban, metas, formação de preço e conversão da venda em contrato." },
  financeiro: { titulo: "Financeiro", etapa: 6, descricao: "Contas a pagar e a receber, faturamento, fluxo de caixa e rentabilidade por contrato." },
  marketing: { titulo: "Marketing e IA", etapa: 7, descricao: "Integração oficial com Instagram, agente de marketing, calendário editorial e atendimento inteligente." },
};
