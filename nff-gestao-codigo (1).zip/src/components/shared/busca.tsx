"use client";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { useTransition } from "react";
import { Search } from "lucide-react";
import { Input, NativeSelect } from "@/components/ui/input";

/** Barra de filtros que atualiza a URL (a consulta é feita no servidor). */
export function BarraFiltros({
  placeholder, filtros = [],
}: {
  placeholder: string;
  filtros?: { nome: string; label: string; opcoes: { valor: string; label: string }[] }[];
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [, startTransition] = useTransition();

  function atualizar(nome: string, valor: string) {
    const p = new URLSearchParams(params.toString());
    if (valor) p.set(nome, valor);
    else p.delete(nome);
    p.delete("pagina");
    startTransition(() => router.replace(`${pathname}?${p.toString()}`));
  }

  return (
    <div className="flex flex-col gap-2 p-3 sm:flex-row">
      <div className="relative flex-1">
        <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          defaultValue={params.get("q") ?? ""}
          placeholder={placeholder}
          className="pl-9"
          onChange={(e) => atualizar("q", e.target.value)}
        />
      </div>
      {filtros.map((f) => (
        <NativeSelect
          key={f.nome}
          aria-label={f.label}
          className="sm:w-48"
          defaultValue={params.get(f.nome) ?? ""}
          onChange={(e) => atualizar(f.nome, e.target.value)}
        >
          <option value="">{f.label}: todos</option>
          {f.opcoes.map((o) => (
            <option key={o.valor} value={o.valor}>{o.label}</option>
          ))}
        </NativeSelect>
      ))}
    </div>
  );
}
