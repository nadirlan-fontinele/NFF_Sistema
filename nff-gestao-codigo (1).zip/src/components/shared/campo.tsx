import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

/** Campo de formulário com rótulo, ajuda e mensagem de erro. */
export function Campo({
  id, label, erro, ajuda, obrigatorio, className, children,
}: {
  id: string; label: string; erro?: string; ajuda?: string; obrigatorio?: boolean; className?: string; children: React.ReactNode;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <Label htmlFor={id}>
        {label}
        {obrigatorio && <span className="text-destructive">*</span>}
      </Label>
      {children}
      {erro ? (
        <p className="text-xs text-destructive" role="alert">{erro}</p>
      ) : ajuda ? (
        <p className="text-xs text-muted-foreground">{ajuda}</p>
      ) : null}
    </div>
  );
}

export function SecaoForm({ titulo, descricao, children }: { titulo: string; descricao?: string; children: React.ReactNode }) {
  return (
    <section className="grid gap-4 border-b py-6 first:pt-0 last:border-0 md:grid-cols-[220px_1fr]">
      <div>
        <h3 className="text-sm font-semibold">{titulo}</h3>
        {descricao && <p className="mt-1 text-xs text-muted-foreground">{descricao}</p>}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </section>
  );
}
