"use client";
import { useState, useTransition } from "react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import type { EstadoForm } from "@/lib/acoes";

/** Botão de exclusão com confirmação. A ação deve redirecionar em caso de sucesso. */
export function BotaoExcluir({
  acao, titulo, descricao, rotulo = "Excluir", size = "default",
}: {
  acao: () => Promise<EstadoForm>; titulo: string; descricao: string; rotulo?: string; size?: "default" | "sm";
}) {
  const [aberto, setAberto] = useState(false);
  const [pendente, startTransition] = useTransition();
  return (
    <Dialog open={aberto} onOpenChange={setAberto}>
      <DialogTrigger asChild>
        <Button variant="outline" size={size} className="text-destructive hover:text-destructive">
          <Trash2 /> {rotulo}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogTitle>{titulo}</DialogTitle>
        <DialogDescription>{descricao}</DialogDescription>
        <div className="flex justify-end gap-2">
          <DialogClose asChild><Button variant="outline">Cancelar</Button></DialogClose>
          <Button
            variant="destructive"
            disabled={pendente}
            onClick={() =>
              startTransition(async () => {
                const r = await acao();
                if (r?.erro) toast.error(r.erro);
                setAberto(false);
              })
            }
          >
            {pendente ? "Excluindo…" : "Confirmar exclusão"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
