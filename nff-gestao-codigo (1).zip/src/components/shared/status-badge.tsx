import { Badge } from "@/components/ui/badge";

const MAPA: Record<string, { label: string; variant: "success" | "warning" | "secondary" | "destructive" | "default" }> = {
  ativo: { label: "Ativo", variant: "success" },
  inativo: { label: "Inativo", variant: "secondary" },
  prospecto: { label: "Prospecto", variant: "default" },
  rascunho: { label: "Rascunho", variant: "warning" },
  suspenso: { label: "Suspenso", variant: "destructive" },
  encerrado: { label: "Encerrado", variant: "secondary" },
};

export function StatusBadge({ status }: { status: string }) {
  const s = MAPA[status] ?? { label: status, variant: "secondary" as const };
  return <Badge variant={s.variant}>{s.label}</Badge>;
}
