import Link from "next/link";
import { ChevronLeft } from "lucide-react";

export function PageHeader({
  titulo, descricao, acoes, voltar,
}: { titulo: string; descricao?: React.ReactNode; acoes?: React.ReactNode; voltar?: { href: string; label: string } }) {
  return (
    <div className="mb-6 space-y-2">
      {voltar && (
        <Link href={voltar.href} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ChevronLeft className="size-4" /> {voltar.label}
        </Link>
      )}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold tracking-tight">{titulo}</h1>
          {descricao && <div className="mt-1 text-sm text-muted-foreground">{descricao}</div>}
        </div>
        {acoes && <div className="flex flex-wrap gap-2">{acoes}</div>}
      </div>
    </div>
  );
}
