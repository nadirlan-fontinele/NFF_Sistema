"use client";
import { useActionState, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { convidarUsuario } from "./actions";

type Perfil = { id: string; nome: string; codigo: string };

export function FormConvite({ perfis, clientes, habilitado }: { perfis: Perfil[]; clientes: { id: string; nome: string }[]; habilitado: boolean }) {
  const [estado, acao, pendente] = useActionState(convidarUsuario, undefined);
  const [tipo, setTipo] = useState("interno");
  const e = (k: string) => estado?.campos?.[k];
  const perfisVisiveis = perfis.filter((p) => (tipo === "cliente" ? p.codigo === "cliente" : p.codigo !== "cliente" && p.codigo !== "colaborador"));
  return (
    <form action={acao}>
      {!habilitado && (
        <p className="mb-4 rounded-md bg-warning/15 p-3 text-sm">
          Convites ainda não estão habilitados: falta configurar a chave de serviço do Supabase no servidor.
        </p>
      )}
      <Card>
        <CardContent className="pt-6">
          <SecaoForm titulo="Usuário" descricao="O usuário recebe um e-mail para criar a própria senha.">
            <Campo id="nome" label="Nome completo" obrigatorio erro={e("nome")}><Input id="nome" name="nome" /></Campo>
            <Campo id="email" label="E-mail" obrigatorio erro={e("email")}><Input id="email" name="email" type="email" /></Campo>
            <Campo id="tipo" label="Tipo de acesso" obrigatorio>
              <NativeSelect id="tipo" name="tipo" value={tipo} onChange={(ev) => setTipo(ev.target.value)}>
                <option value="interno">Equipe interna</option>
                <option value="cliente">Cliente (portal)</option>
              </NativeSelect>
            </Campo>
            {tipo === "cliente" && (
              <Campo id="cliente_id" label="Cliente" obrigatorio erro={e("cliente_id")}>
                <NativeSelect id="cliente_id" name="cliente_id" defaultValue="">
                  <option value="">Selecione…</option>
                  {clientes.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
                </NativeSelect>
              </Campo>
            )}
          </SecaoForm>
          <SecaoForm titulo="Perfis">
            <div className="grid gap-2 sm:col-span-2 sm:grid-cols-2">
              {perfisVisiveis.map((p) => (
                <label key={p.id} className="flex items-center gap-2 rounded-md border p-2.5 text-sm">
                  <input type="checkbox" name="perfis" value={p.id} defaultChecked={p.codigo === "cliente"} className="size-4" /> {p.nome}
                </label>
              ))}
            </div>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive">{estado.erro}</p>}
        <Button variant="outline" asChild><Link href="/admin/usuarios">Cancelar</Link></Button>
        <Button type="submit" disabled={pendente || !habilitado}>{pendente ? "Enviando…" : "Enviar convite"}</Button>
      </div>
    </form>
  );
}
