"use client";
import { Fragment, useOptimistic, useTransition } from "react";
import { toast } from "sonner";
import { alternarPermissao } from "./actions";

type Perfil = { id: string; nome: string; codigo: string };
type Permissao = { id: string; modulo: string; acao: string; descricao: string };

const NOMES_MODULO: Record<string, string> = {
  admin: "Administração", dashboard: "Dashboard", clientes: "Clientes", cadastros: "Cadastros", contratos: "Contratos",
  operacional: "Operacional", rh: "RH", recrutamento: "Recrutamento", comercial: "Comercial", financeiro: "Financeiro",
  marketing: "Marketing", portal: "Portal do cliente", ia: "Inteligência artificial", colaborador: "Colaborador",
};

export function MatrizPermissoes({
  perfis, permissoes, ativos, editavel,
}: { perfis: Perfil[]; permissoes: Permissao[]; ativos: string[]; editavel: boolean }) {
  const [otimista, alternar] = useOptimistic(new Set(ativos), (atual: Set<string>, chave: string) => {
    const n = new Set(atual);
    if (n.has(chave)) n.delete(chave);
    else n.add(chave);
    return n;
  });
  const [, startTransition] = useTransition();
  const modulos = [...new Set(permissoes.map((p) => p.modulo))];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead className="sticky top-0 z-10 bg-card">
          <tr>
            <th className="sticky left-0 z-20 min-w-56 border-b bg-card p-2 text-left">Permissão</th>
            {perfis.map((p) => (
              <th key={p.id} className="border-b p-2 align-bottom">
                <div className="mx-auto w-6 [writing-mode:vertical-rl] rotate-180 text-xs font-medium whitespace-nowrap">{p.nome}</div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {modulos.map((m) => (
            <Fragment key={m}>
              <tr>
                <td colSpan={perfis.length + 1} className="sticky left-0 bg-muted/60 px-2 py-1.5 text-xs font-semibold uppercase tracking-wide">
                  {NOMES_MODULO[m] ?? m}
                </td>
              </tr>
              {permissoes.filter((p) => p.modulo === m).map((perm) => (
                <tr key={perm.id} className="hover:bg-muted/30">
                  <td className="sticky left-0 border-b bg-card p-2">{perm.descricao}</td>
                  {perfis.map((perfil) => {
                    const chave = `${perfil.id}:${perm.id}`;
                    const marcado = perfil.codigo === "admin" || otimista.has(chave);
                    return (
                      <td key={chave} className="border-b p-2 text-center">
                        <input
                          type="checkbox"
                          aria-label={`${perfil.nome}: ${perm.descricao}`}
                          className="size-4"
                          checked={marcado}
                          disabled={!editavel || perfil.codigo === "admin"}
                          onChange={() =>
                            startTransition(async () => {
                              alternar(chave);
                              const r = await alternarPermissao(perfil.id, perm.id, !marcado);
                              if (r?.erro) toast.error(r.erro);
                            })
                          }
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}
