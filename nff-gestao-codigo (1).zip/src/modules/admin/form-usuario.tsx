"use client";
import { useActionState, useEffect } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { salvarUsuario } from "./actions";

type Perfil = { id: string; nome: string; descricao: string | null };

export function FormUsuario({
  id, nome, telefone, ativo, perfis, selecionados,
}: { id: string; nome: string; telefone: string | null; ativo: boolean; perfis: Perfil[]; selecionados: string[] }) {
  const [estado, acao, pendente] = useActionState(salvarUsuario.bind(null, id), undefined);
  useEffect(() => {
    if (estado?.valores?.salvo) toast.success("Usuário atualizado.");
  }, [estado]);
  return (
    <form action={acao}>
      <Card>
        <CardContent className="pt-6">
          <SecaoForm titulo="Dados">
            <Campo id="nome" label="Nome" obrigatorio erro={estado?.campos?.nome}><Input id="nome" name="nome" defaultValue={nome} /></Campo>
            <Campo id="telefone" label="Telefone"><Input id="telefone" name="telefone" defaultValue={telefone ?? ""} /></Campo>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="ativo" defaultChecked={ativo} className="size-4" /> Usuário ativo (desmarque para bloquear o acesso)
            </label>
          </SecaoForm>
          <SecaoForm titulo="Perfis" descricao="As permissões do usuário são a soma dos perfis marcados.">
            <div className="grid gap-2 sm:col-span-2 sm:grid-cols-2">
              {perfis.map((p) => (
                <label key={p.id} className="flex cursor-pointer items-start gap-2 rounded-md border p-2.5 text-sm hover:bg-muted/40">
                  <input type="checkbox" name="perfis" value={p.id} defaultChecked={selecionados.includes(p.id)} className="mt-0.5 size-4" />
                  <span><span className="font-medium">{p.nome}</span>{p.descricao && <span className="block text-xs text-muted-foreground">{p.descricao}</span>}</span>
                </label>
              ))}
            </div>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive">{estado.erro}</p>}
        <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : "Salvar"}</Button>
      </div>
    </form>
  );
}
