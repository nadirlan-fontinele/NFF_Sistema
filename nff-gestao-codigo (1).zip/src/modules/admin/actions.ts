"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { exigirPermissao } from "@/lib/auth";
import { createAdminClient, createClient } from "@/lib/supabase/server";
import { errosDoZod, mensagemErroBanco, type EstadoForm } from "@/lib/acoes";
import { env } from "@/lib/env";

const conviteSchema = z
  .object({
    nome: z.string().trim().min(3, "Informe o nome completo."),
    email: z.string().trim().toLowerCase().email("E-mail inválido."),
    tipo: z.enum(["interno", "cliente"]),
    cliente_id: z.preprocess((v) => (v === "" ? null : v), z.string().uuid().nullable()),
  })
  .refine((d) => d.tipo !== "cliente" || !!d.cliente_id, { path: ["cliente_id"], message: "Selecione o cliente." });

/** Convida um usuário por e-mail (requer SUPABASE_SERVICE_ROLE_KEY no servidor). */
export async function convidarUsuario(_: EstadoForm, formData: FormData): Promise<EstadoForm> {
  const sessao = await exigirPermissao("admin.usuarios");
  const dados = conviteSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);
  const perfis = formData.getAll("perfis").map(String);

  if (!env.supabaseServiceRoleKey) {
    return { erro: "O convite de usuários exige a chave de serviço do Supabase configurada no servidor (SUPABASE_SERVICE_ROLE_KEY)." };
  }
  const admin = createAdminClient();
  const appMeta = {
    organizacao_id: sessao.organizacaoId,
    tipo: dados.data.tipo,
    cliente_id: dados.data.cliente_id,
    nome: dados.data.nome,
  };
  const { data: convite, error } = await admin.auth.admin.inviteUserByEmail(dados.data.email, {
    data: { nome: dados.data.nome },
    redirectTo: `${env.appUrl}/auth/confirm`,
  });
  if (error || !convite.user) {
    return { erro: error?.message.includes("already") ? "Já existe uma conta com este e-mail." : "Não foi possível enviar o convite." };
  }
  await admin.auth.admin.updateUserById(convite.user.id, { app_metadata: appMeta });
  const { error: errUsuario } = await admin.from("usuarios").upsert({
    id: convite.user.id,
    organizacao_id: sessao.organizacaoId,
    nome: dados.data.nome,
    email: dados.data.email,
    tipo: dados.data.tipo,
    cliente_id: dados.data.tipo === "cliente" ? dados.data.cliente_id : null,
  });
  if (errUsuario) return { erro: mensagemErroBanco(errUsuario) };

  // Perfis atribuídos com o cliente do próprio administrador (passa pelo RLS)
  if (perfis.length) {
    const supabase = await createClient();
    const { error: errPerfis } = await supabase.from("usuario_perfis").insert(perfis.map((p) => ({ usuario_id: convite.user!.id, perfil_id: p })));
    if (errPerfis) return { erro: mensagemErroBanco(errPerfis) };
  }
  revalidatePath("/admin/usuarios");
  redirect(`/admin/usuarios/${convite.user.id}`);
}

const usuarioSchema = z.object({
  nome: z.string().trim().min(3, "Informe o nome."),
  telefone: z.preprocess((v) => (v === "" ? null : v), z.string().nullable()),
  ativo: z.preprocess((v) => v === "on", z.boolean()),
});

export async function salvarUsuario(id: string, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  const sessao = await exigirPermissao("admin.usuarios");
  const dados = usuarioSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);
  if (id === sessao.userId && !dados.data.ativo) return { erro: "Você não pode desativar a própria conta." };

  const perfisNovos = new Set(formData.getAll("perfis").map(String));
  const supabase = await createClient();
  const { error } = await supabase.from("usuarios").update(dados.data).eq("id", id);
  if (error) return { erro: mensagemErroBanco(error) };

  const { data: atuais } = await supabase.from("usuario_perfis").select("perfil_id, perfis(codigo)").eq("usuario_id", id);
  const atuaisIds = new Set((atuais ?? []).map((p) => p.perfil_id));

  // Proteção: o administrador não pode remover o próprio perfil de administrador
  if (id === sessao.userId) {
    const adminAtual = (atuais ?? []).find((p) => (p.perfis as unknown as { codigo: string }).codigo === "admin");
    if (adminAtual && !perfisNovos.has(adminAtual.perfil_id)) {
      return { erro: "Você não pode remover o seu próprio perfil de Administrador." };
    }
  }

  const remover = [...atuaisIds].filter((p) => !perfisNovos.has(p));
  const adicionar = [...perfisNovos].filter((p) => !atuaisIds.has(p));
  if (remover.length) {
    const { error: e1 } = await supabase.from("usuario_perfis").delete().eq("usuario_id", id).in("perfil_id", remover);
    if (e1) return { erro: mensagemErroBanco(e1) };
  }
  if (adicionar.length) {
    const { error: e2 } = await supabase.from("usuario_perfis").insert(adicionar.map((p) => ({ usuario_id: id, perfil_id: p })));
    if (e2) return { erro: mensagemErroBanco(e2) };
  }
  revalidatePath("/admin/usuarios");
  revalidatePath(`/admin/usuarios/${id}`);
  return { erro: undefined, valores: { salvo: "1" } };
}

/** Liga/desliga uma permissão de um perfil (matriz de permissões). */
export async function alternarPermissao(perfilId: string, permissaoId: string, ligar: boolean): Promise<EstadoForm> {
  await exigirPermissao("admin.perfis");
  const supabase = await createClient();
  const { data: perfil } = await supabase.from("perfis").select("codigo").eq("id", perfilId).single();
  if (perfil?.codigo === "admin") return { erro: "O perfil Administrador geral sempre tem todas as permissões." };
  const { error } = ligar
    ? await supabase.from("perfil_permissoes").insert({ perfil_id: perfilId, permissao_id: permissaoId })
    : await supabase.from("perfil_permissoes").delete().eq("perfil_id", perfilId).eq("permissao_id", permissaoId);
  if (error && error.code !== "23505") return { erro: mensagemErroBanco(error) };
  revalidatePath("/admin/perfis");
  return undefined;
}
