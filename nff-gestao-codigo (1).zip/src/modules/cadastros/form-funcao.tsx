"use client";
import { useActionState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Campo } from "@/components/shared/campo";
import { salvarFuncao } from "./actions";

type Valores = Record<string, string | number | boolean | null | undefined>;

export function FormFuncao({ id, inicial }: { id?: string; inicial?: Valores }) {
  const [estado, acao, pendente] = useActionState(salvarFuncao.bind(null, id ?? null), undefined);
  const v = (k: string) => String(estado?.valores?.[k] ?? inicial?.[k] ?? "");
  const e = (k: string) => estado?.campos?.[k];
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">{id ? "Editar função" : "Nova função"}</CardTitle></CardHeader>
      <CardContent>
        <form action={acao} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" key={id ?? "nova"}>
          <Campo id="nome" label="Nome" obrigatorio erro={e("nome")} className="lg:col-span-2">
            <Input id="nome" name="nome" defaultValue={v("nome")} placeholder="Ex.: Auxiliar de serviços gerais" />
          </Campo>
          <Campo id="cbo" label="CBO" erro={e("cbo")}><Input id="cbo" name="cbo" defaultValue={v("cbo")} placeholder="5143-20" /></Campo>
          <Campo id="salario_base" label="Salário-base de referência (R$)" erro={e("salario_base")}>
            <Input id="salario_base" name="salario_base" inputMode="decimal" defaultValue={inicial?.salario_base != null && !estado ? Number(inicial.salario_base).toFixed(2).replace(".", ",") : v("salario_base")} />
          </Campo>
          <Campo id="descricao" label="Descrição" className="sm:col-span-2 lg:col-span-3">
            <Input id="descricao" name="descricao" defaultValue={v("descricao")} />
          </Campo>
          <label className="flex items-center gap-2 self-end pb-2 text-sm">
            <input type="checkbox" name="ativo" defaultChecked={inicial?.ativo !== false} className="size-4" /> Ativa
          </label>
          <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-4">
            {estado?.erro && <p className="mr-auto text-sm text-destructive">{estado.erro}</p>}
            <div className="ml-auto flex gap-2">
              {id && <Button variant="outline" asChild><Link href="/cadastros/funcoes">Cancelar</Link></Button>}
              <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : "Salvar"}</Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
