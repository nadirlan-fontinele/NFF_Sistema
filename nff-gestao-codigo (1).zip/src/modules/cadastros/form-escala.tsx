"use client";
import { useActionState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Campo } from "@/components/shared/campo";
import { salvarEscala } from "./actions";

type Valores = Record<string, string | number | boolean | null | undefined>;

export function FormEscala({ id, inicial }: { id?: string; inicial?: Valores }) {
  const [estado, acao, pendente] = useActionState(salvarEscala.bind(null, id ?? null), undefined);
  const v = (k: string) => String(estado?.valores?.[k] ?? inicial?.[k] ?? "");
  const e = (k: string) => estado?.campos?.[k];
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">{id ? "Editar escala" : "Nova escala"}</CardTitle></CardHeader>
      <CardContent>
        <form action={acao} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" key={id ?? "nova"}>
          <Campo id="nome" label="Nome" obrigatorio erro={e("nome")} className="lg:col-span-2">
            <Input id="nome" name="nome" defaultValue={v("nome")} placeholder="Ex.: 12x36 noturno" />
          </Campo>
          <Campo id="tipo" label="Tipo" obrigatorio>
            <NativeSelect id="tipo" name="tipo" defaultValue={v("tipo") || "personalizada"}>
              <option value="5x2">5x2</option><option value="6x1">6x1</option><option value="12x36">12x36</option><option value="personalizada">Personalizada</option>
            </NativeSelect>
          </Campo>
          <Campo id="horas_jornada" label="Horas por jornada" obrigatorio erro={e("horas_jornada")}>
            <Input id="horas_jornada" name="horas_jornada" inputMode="decimal" defaultValue={v("horas_jornada")} />
          </Campo>
          <Campo id="dias_trabalho" label="Dias de trabalho no ciclo" obrigatorio erro={e("dias_trabalho")}>
            <Input id="dias_trabalho" name="dias_trabalho" type="number" min={1} defaultValue={v("dias_trabalho")} />
          </Campo>
          <Campo id="dias_folga" label="Dias de folga no ciclo" obrigatorio erro={e("dias_folga")}>
            <Input id="dias_folga" name="dias_folga" type="number" min={0} defaultValue={v("dias_folga")} />
          </Campo>
          <Campo id="carga_semanal" label="Carga semanal (h)" erro={e("carga_semanal")}>
            <Input id="carga_semanal" name="carga_semanal" inputMode="decimal" defaultValue={v("carga_semanal")} />
          </Campo>
          <div className="flex flex-col justify-end gap-2 pb-1 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" name="noturno" defaultChecked={inicial?.noturno === true} className="size-4" /> Noturno</label>
            <label className="flex items-center gap-2"><input type="checkbox" name="ativo" defaultChecked={inicial?.ativo !== false} className="size-4" /> Ativa</label>
          </div>
          <Campo id="descricao" label="Descrição" className="sm:col-span-2 lg:col-span-4">
            <Input id="descricao" name="descricao" defaultValue={v("descricao")} />
          </Campo>
          <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-4">
            {estado?.erro && <p className="mr-auto text-sm text-destructive">{estado.erro}</p>}
            <div className="ml-auto flex gap-2">
              {id && <Button variant="outline" asChild><Link href="/cadastros/escalas">Cancelar</Link></Button>}
              <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : "Salvar"}</Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
