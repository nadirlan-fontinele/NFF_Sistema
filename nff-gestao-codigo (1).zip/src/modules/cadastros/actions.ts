"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { errosDoZod, mensagemErroBanco, type EstadoForm } from "@/lib/acoes";
import { valorMonetario } from "@/modules/contratos/schema";

const opcional = z.preprocess((v) => (typeof v === "string" && v.trim() === "" ? null : v), z.string().trim().nullable().optional());
const ativo = z.preprocess((v) => v === "on", z.boolean());

const funcaoSchema = z.object({
  nome: z.string().trim().min(2, "Informe o nome da função."),
  cbo: z.preprocess((v) => (v === "" ? null : v), z.string().regex(/^\d{4}-?\d{2}$/, "CBO no formato 0000-00").nullable().optional()),
  salario_base: valorMonetario.optional(),
  descricao: opcional,
  ativo,
});

export async function salvarFuncao(id: string | null, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  await exigirPermissao("cadastros.editar");
  const dados = funcaoSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);
  const supabase = await createClient();
  const { error } = id
    ? await supabase.from("funcoes").update(dados.data).eq("id", id)
    : await supabase.from("funcoes").insert(dados.data);
  if (error) return { erro: mensagemErroBanco(error, "uma função com este nome"), valores: Object.fromEntries(formData) as Record<string, string> };
  revalidatePath("/cadastros/funcoes");
  redirect("/cadastros/funcoes");
}

const escalaSchema = z.object({
  nome: z.string().trim().min(2, "Informe o nome da escala."),
  tipo: z.enum(["5x2", "6x1", "12x36", "personalizada"]),
  dias_trabalho: z.coerce.number().int().min(1, "Mínimo 1").max(31),
  dias_folga: z.coerce.number().int().min(0).max(31),
  horas_jornada: z.coerce.number().positive("Informe as horas").max(24),
  carga_semanal: z.preprocess((v) => (v === "" ? null : Number(String(v).replace(",", "."))), z.number().min(0).max(80).nullable()),
  noturno: z.preprocess((v) => v === "on", z.boolean()),
  descricao: opcional,
  ativo,
});

export async function salvarEscala(id: string | null, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  await exigirPermissao("cadastros.editar");
  const bruto = Object.fromEntries(formData);
  bruto.horas_jornada = String(bruto.horas_jornada ?? "").replace(",", ".");
  const dados = escalaSchema.safeParse(bruto);
  if (!dados.success) return errosDoZod(dados.error, formData);
  const supabase = await createClient();
  const { error } = id
    ? await supabase.from("escalas_modelo").update(dados.data).eq("id", id)
    : await supabase.from("escalas_modelo").insert(dados.data);
  if (error) return { erro: mensagemErroBanco(error, "uma escala com este nome"), valores: Object.fromEntries(formData) as Record<string, string> };
  revalidatePath("/cadastros/escalas");
  redirect("/cadastros/escalas");
}
