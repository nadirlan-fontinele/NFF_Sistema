import { z } from "zod";
import { cnpjValido, cpfValido, somenteDigitos } from "@/lib/format";

const opcional = z.preprocess((v) => (typeof v === "string" && v.trim() === "" ? null : v), z.string().trim().nullable().optional());
const uf = z.preprocess(
  (v) => (typeof v === "string" && v.trim() === "" ? null : typeof v === "string" ? v.trim().toUpperCase() : v),
  z.string().length(2, "UF com 2 letras").nullable().optional(),
);
const cep = z.preprocess(
  (v) => (typeof v === "string" ? (somenteDigitos(v) || null) : v),
  z.string().length(8, "CEP com 8 dígitos").nullable().optional(),
);
const email = z.preprocess(
  (v) => (typeof v === "string" && v.trim() === "" ? null : v),
  z.string().trim().email("E-mail inválido").nullable().optional(),
);

export const clienteSchema = z
  .object({
    tipo_pessoa: z.enum(["PJ", "PF"]),
    razao_social: z.string().trim().min(2, "Informe a razão social ou nome."),
    nome_fantasia: opcional,
    documento: z.string().transform(somenteDigitos),
    inscricao_estadual: opcional,
    email,
    telefone: opcional,
    contato_nome: opcional,
    cep,
    logradouro: opcional,
    numero: opcional,
    complemento: opcional,
    bairro: opcional,
    cidade: opcional,
    uf,
    status: z.enum(["ativo", "inativo", "prospecto"]),
    observacoes: opcional,
  })
  .superRefine((d, ctx) => {
    const ok = d.tipo_pessoa === "PJ" ? cnpjValido(d.documento) : cpfValido(d.documento);
    if (!ok) ctx.addIssue({ code: "custom", path: ["documento"], message: d.tipo_pessoa === "PJ" ? "CNPJ inválido." : "CPF inválido." });
  });

export const unidadeSchema = z.object({
  nome: z.string().trim().min(2, "Informe o nome da unidade."),
  cep,
  logradouro: opcional,
  numero: opcional,
  complemento: opcional,
  bairro: opcional,
  cidade: opcional,
  uf,
  responsavel_nome: opcional,
  responsavel_telefone: opcional,
  responsavel_email: email,
  ativo: z.preprocess((v) => v === "on" || v === "true" || v === true, z.boolean()),
});

export type Cliente = z.infer<typeof clienteSchema> & { id: string; created_at: string };
