"use client";
import { useActionState, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { salvarCliente } from "../actions";
import { formatarCep, formatarDocumento } from "@/lib/format";

type Valores = Record<string, string | null | undefined>;

export function FormCliente({ id, inicial }: { id?: string; inicial?: Valores }) {
  const [estado, acao, pendente] = useActionState(salvarCliente.bind(null, id ?? null), undefined);
  const v = (k: string) => estado?.valores?.[k] ?? inicial?.[k] ?? "";
  const e = (k: string) => estado?.campos?.[k];
  const [tipo, setTipo] = useState(v("tipo_pessoa") || "PJ");

  return (
    <form action={acao}>
      <Card>
        <CardContent className="pt-6">
          <SecaoForm titulo="Identificação" descricao="Dados cadastrais do cliente.">
            <Campo id="tipo_pessoa" label="Tipo" obrigatorio>
              <NativeSelect id="tipo_pessoa" name="tipo_pessoa" value={tipo} onChange={(ev) => setTipo(ev.target.value)}>
                <option value="PJ">Pessoa jurídica</option>
                <option value="PF">Pessoa física</option>
              </NativeSelect>
            </Campo>
            <Campo id="documento" label={tipo === "PJ" ? "CNPJ" : "CPF"} obrigatorio erro={e("documento")}>
              <Input id="documento" name="documento" defaultValue={formatarDocumento(v("documento")) === "—" ? "" : formatarDocumento(v("documento"))}
                inputMode="numeric" aria-invalid={!!e("documento")} placeholder={tipo === "PJ" ? "00.000.000/0000-00" : "000.000.000-00"} />
            </Campo>
            <Campo id="razao_social" label={tipo === "PJ" ? "Razão social" : "Nome completo"} obrigatorio erro={e("razao_social")} className="sm:col-span-2">
              <Input id="razao_social" name="razao_social" defaultValue={v("razao_social")} aria-invalid={!!e("razao_social")} />
            </Campo>
            <Campo id="nome_fantasia" label="Nome fantasia">
              <Input id="nome_fantasia" name="nome_fantasia" defaultValue={v("nome_fantasia")} />
            </Campo>
            <Campo id="inscricao_estadual" label="Inscrição estadual/municipal">
              <Input id="inscricao_estadual" name="inscricao_estadual" defaultValue={v("inscricao_estadual")} />
            </Campo>
            <Campo id="status" label="Situação" obrigatorio>
              <NativeSelect id="status" name="status" defaultValue={v("status") || "ativo"}>
                <option value="ativo">Ativo</option>
                <option value="prospecto">Prospecto</option>
                <option value="inativo">Inativo</option>
              </NativeSelect>
            </Campo>
          </SecaoForm>

          <SecaoForm titulo="Contato" descricao="Contato principal para assuntos do contrato.">
            <Campo id="contato_nome" label="Nome do contato">
              <Input id="contato_nome" name="contato_nome" defaultValue={v("contato_nome")} />
            </Campo>
            <Campo id="telefone" label="Telefone">
              <Input id="telefone" name="telefone" type="tel" defaultValue={v("telefone")} />
            </Campo>
            <Campo id="email" label="E-mail" erro={e("email")} className="sm:col-span-2">
              <Input id="email" name="email" type="email" defaultValue={v("email")} aria-invalid={!!e("email")} />
            </Campo>
          </SecaoForm>

          <SecaoForm titulo="Endereço" descricao="Endereço da sede ou de cobrança.">
            <Campo id="cep" label="CEP" erro={e("cep")}>
              <Input id="cep" name="cep" defaultValue={formatarCep(v("cep"))} inputMode="numeric" aria-invalid={!!e("cep")} />
            </Campo>
            <Campo id="logradouro" label="Logradouro">
              <Input id="logradouro" name="logradouro" defaultValue={v("logradouro")} />
            </Campo>
            <Campo id="numero" label="Número">
              <Input id="numero" name="numero" defaultValue={v("numero")} />
            </Campo>
            <Campo id="complemento" label="Complemento">
              <Input id="complemento" name="complemento" defaultValue={v("complemento")} />
            </Campo>
            <Campo id="bairro" label="Bairro">
              <Input id="bairro" name="bairro" defaultValue={v("bairro")} />
            </Campo>
            <div className="grid grid-cols-[1fr_80px] gap-4">
              <Campo id="cidade" label="Cidade">
                <Input id="cidade" name="cidade" defaultValue={v("cidade")} />
              </Campo>
              <Campo id="uf" label="UF" erro={e("uf")}>
                <Input id="uf" name="uf" maxLength={2} defaultValue={v("uf")} className="uppercase" />
              </Campo>
            </div>
          </SecaoForm>

          <SecaoForm titulo="Observações">
            <Campo id="observacoes" label="Observações internas" className="sm:col-span-2">
              <Textarea id="observacoes" name="observacoes" defaultValue={v("observacoes")} />
            </Campo>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive" role="alert">{estado.erro}</p>}
        <Button variant="outline" asChild><Link href={id ? `/clientes/${id}` : "/clientes"}>Cancelar</Link></Button>
        <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : "Salvar cliente"}</Button>
      </div>
    </form>
  );
}
