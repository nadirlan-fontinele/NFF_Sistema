"use client";
import { useActionState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { salvarUnidade } from "../actions";
import { formatarCep } from "@/lib/format";

type Valores = Record<string, string | boolean | null | undefined>;

export function FormUnidade({ clienteId, id, inicial }: { clienteId: string; id?: string; inicial?: Valores }) {
  const [estado, acao, pendente] = useActionState(salvarUnidade.bind(null, clienteId, id ?? null), undefined);
  const v = (k: string) => String(estado?.valores?.[k] ?? inicial?.[k] ?? "");
  const e = (k: string) => estado?.campos?.[k];
  const ativo = estado?.valores ? estado.valores.ativo === "on" : inicial?.ativo !== false;

  return (
    <form action={acao}>
      <Card>
        <CardContent className="pt-6">
          <SecaoForm titulo="Unidade" descricao="Local onde os postos são atendidos.">
            <Campo id="nome" label="Nome da unidade" obrigatorio erro={e("nome")} className="sm:col-span-2">
              <Input id="nome" name="nome" defaultValue={v("nome")} placeholder="Ex.: Sede administrativa, Loja Centro" aria-invalid={!!e("nome")} />
            </Campo>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="ativo" defaultChecked={ativo} className="size-4 accent-[var(--primary)]" /> Unidade ativa
            </label>
          </SecaoForm>
          <SecaoForm titulo="Endereço" descricao="Usado para sugerir substitutos próximos (Etapa 3).">
            <Campo id="cep" label="CEP" erro={e("cep")}>
              <Input id="cep" name="cep" defaultValue={formatarCep(v("cep"))} inputMode="numeric" />
            </Campo>
            <Campo id="logradouro" label="Logradouro"><Input id="logradouro" name="logradouro" defaultValue={v("logradouro")} /></Campo>
            <Campo id="numero" label="Número"><Input id="numero" name="numero" defaultValue={v("numero")} /></Campo>
            <Campo id="complemento" label="Complemento"><Input id="complemento" name="complemento" defaultValue={v("complemento")} /></Campo>
            <Campo id="bairro" label="Bairro"><Input id="bairro" name="bairro" defaultValue={v("bairro")} /></Campo>
            <div className="grid grid-cols-[1fr_80px] gap-4">
              <Campo id="cidade" label="Cidade"><Input id="cidade" name="cidade" defaultValue={v("cidade")} /></Campo>
              <Campo id="uf" label="UF" erro={e("uf")}><Input id="uf" name="uf" maxLength={2} defaultValue={v("uf")} className="uppercase" /></Campo>
            </div>
          </SecaoForm>
          <SecaoForm titulo="Responsável local" descricao="Contato do cliente na unidade.">
            <Campo id="responsavel_nome" label="Nome"><Input id="responsavel_nome" name="responsavel_nome" defaultValue={v("responsavel_nome")} /></Campo>
            <Campo id="responsavel_telefone" label="Telefone"><Input id="responsavel_telefone" name="responsavel_telefone" defaultValue={v("responsavel_telefone")} /></Campo>
            <Campo id="responsavel_email" label="E-mail" erro={e("responsavel_email")} className="sm:col-span-2">
              <Input id="responsavel_email" name="responsavel_email" type="email" defaultValue={v("responsavel_email")} />
            </Campo>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive" role="alert">{estado.erro}</p>}
        <Button variant="outline" asChild><Link href={`/clientes/${clienteId}`}>Cancelar</Link></Button>
        <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : "Salvar unidade"}</Button>
      </div>
    </form>
  );
}
