"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { errosDoZod, mensagemErroBanco, type EstadoForm } from "@/lib/acoes";
import { clienteSchema, unidadeSchema } from "./schema";

export async function salvarCliente(id: string | null, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  await exigirPermissao(id ? "clientes.editar" : "clientes.criar");
  const dados = clienteSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);

  const supabase = await createClient();
  const res = id
    ? await supabase.from("clientes").update(dados.data).eq("id", id).select("id").single()
    : await supabase.from("clientes").insert(dados.data).select("id").single();

  if (res.error) {
    const campos = res.error.code === "23505" ? { documento: "Já existe um cliente com este documento." } : undefined;
    return { erro: mensagemErroBanco(res.error, "um cliente"), campos, valores: Object.fromEntries(formData) as Record<string, string> };
  }
  revalidatePath("/clientes");
  redirect(`/clientes/${res.data.id}`);
}

export async function salvarUnidade(
  clienteId: string, id: string | null, _: EstadoForm, formData: FormData,
): Promise<EstadoForm> {
  await exigirPermissao(id ? "clientes.editar" : "clientes.criar");
  const dados = unidadeSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);

  const supabase = await createClient();
  const res = id
    ? await supabase.from("cliente_unidades").update(dados.data).eq("id", id).eq("cliente_id", clienteId)
    : await supabase.from("cliente_unidades").insert({ ...dados.data, cliente_id: clienteId });

  if (res.error) {
    return {
      erro: mensagemErroBanco(res.error, "uma unidade com este nome para o cliente"),
      valores: Object.fromEntries(formData) as Record<string, string>,
    };
  }
  revalidatePath(`/clientes/${clienteId}`);
  redirect(`/clientes/${clienteId}`);
}

export async function excluirCliente(id: string): Promise<EstadoForm> {
  await exigirPermissao("clientes.excluir");
  const supabase = await createClient();
  const { error, count } = await supabase.from("clientes").delete({ count: "exact" }).eq("id", id);
  if (error) {
    return { erro: error.code === "23503" ? "O cliente possui contratos ou usuários vinculados. Inative-o em vez de excluir." : mensagemErroBanco(error) };
  }
  if (!count) return { erro: "Cliente não encontrado ou sem permissão." };
  revalidatePath("/clientes");
  redirect("/clientes");
}
