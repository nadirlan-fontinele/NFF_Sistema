"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { exigirPermissao } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { errosDoZod, mensagemErroBanco, type EstadoForm } from "@/lib/acoes";
import { aditivoSchema, contratoSchema, postoSchema, STATUS_CONTRATO, TRANSICOES, type StatusContrato } from "./schema";

const valores = (fd: FormData) => Object.fromEntries(fd) as Record<string, string>;

export async function salvarContrato(id: string | null, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  const sessao = await exigirPermissao(id ? "contratos.editar" : "contratos.criar");
  const dados = contratoSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);

  // Quem não vê valores não pode alterá-los
  const payload: Record<string, unknown> = { ...dados.data };
  if (!sessao.pode("contratos.ver_valores")) delete payload.valor_mensal;

  const supabase = await createClient();
  const res = id
    ? await supabase.from("contratos").update(payload).eq("id", id).select("id").single()
    : await supabase.from("contratos").insert(payload).select("id").single();
  if (res.error) {
    const campos = res.error.code === "23505" ? { numero: "Já existe um contrato com este número." } : undefined;
    return { erro: mensagemErroBanco(res.error, "um contrato"), campos, valores: valores(formData) };
  }
  revalidatePath("/contratos");
  redirect(`/contratos/${res.data.id}`);
}

export async function alterarStatusContrato(id: string, novo: string): Promise<EstadoForm> {
  await exigirPermissao("contratos.editar");
  if (!STATUS_CONTRATO.includes(novo as StatusContrato)) return { erro: "Situação inválida." };
  const supabase = await createClient();
  const { data: atual } = await supabase.from("contratos").select("status").eq("id", id).single();
  if (!atual) return { erro: "Contrato não encontrado." };
  if (!TRANSICOES[atual.status as StatusContrato].some((t) => t.para === novo)) {
    return { erro: "Mudança de situação não permitida." };
  }
  const { error } = await supabase.from("contratos").update({ status: novo }).eq("id", id);
  if (error) {
    return { erro: error.code === "23514" || error.code === "P0001" ? error.message : mensagemErroBanco(error) };
  }
  revalidatePath(`/contratos/${id}`);
  revalidatePath("/contratos");
  return undefined;
}

export async function excluirContrato(id: string): Promise<EstadoForm> {
  await exigirPermissao("contratos.excluir");
  const supabase = await createClient();
  const { error, count } = await supabase.from("contratos").delete({ count: "exact" }).eq("id", id);
  if (error) return { erro: mensagemErroBanco(error) };
  if (!count) return { erro: "Somente contratos em rascunho podem ser excluídos." };
  revalidatePath("/contratos");
  redirect("/contratos");
}

export async function salvarPosto(contratoId: string, id: string | null, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  const sessao = await exigirPermissao("contratos.editar");
  const dados = postoSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);
  const payload: Record<string, unknown> = { ...dados.data };
  if (!sessao.pode("contratos.ver_valores")) delete payload.valor_unitario;

  const supabase = await createClient();
  const res = id
    ? await supabase.from("contrato_postos").update(payload).eq("id", id).eq("contrato_id", contratoId)
    : await supabase.from("contrato_postos").insert({ ...payload, contrato_id: contratoId });
  if (res.error) return { erro: mensagemErroBanco(res.error), valores: valores(formData) };
  revalidatePath(`/contratos/${contratoId}`);
  redirect(`/contratos/${contratoId}`);
}

export async function excluirPosto(contratoId: string, id: string): Promise<EstadoForm> {
  await exigirPermissao("contratos.editar");
  const supabase = await createClient();
  const { error } = await supabase.from("contrato_postos").delete().eq("id", id).eq("contrato_id", contratoId);
  if (error) return { erro: mensagemErroBanco(error) };
  revalidatePath(`/contratos/${contratoId}`);
  redirect(`/contratos/${contratoId}`);
}

export async function salvarAditivo(contratoId: string, _: EstadoForm, formData: FormData): Promise<EstadoForm> {
  await exigirPermissao("contratos.editar");
  const dados = aditivoSchema.safeParse(Object.fromEntries(formData));
  if (!dados.success) return errosDoZod(dados.error, formData);
  const supabase = await createClient();
  const { error } = await supabase.from("contrato_aditivos").insert({ ...dados.data, contrato_id: contratoId });
  if (error) return { erro: mensagemErroBanco(error, "um aditivo com este número"), valores: valores(formData) };
  revalidatePath(`/contratos/${contratoId}`);
  redirect(`/contratos/${contratoId}`);
}
