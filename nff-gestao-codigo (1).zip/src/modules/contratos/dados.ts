import "server-only";
import { createClient } from "@/lib/supabase/server";

/** Opções para os formulários de contrato. */
export async function opcoesContrato() {
  const supabase = await createClient();
  const [{ data: clientes }, { data: usuarios }] = await Promise.all([
    supabase.from("clientes").select("id, razao_social, nome_fantasia").neq("status", "inativo").order("razao_social"),
    supabase.from("usuarios").select("id, nome").eq("tipo", "interno").eq("ativo", true).order("nome"),
  ]);
  return {
    clientes: (clientes ?? []).map((c) => ({ id: c.id, nome: c.nome_fantasia ? `${c.nome_fantasia} (${c.razao_social})` : c.razao_social })),
    supervisores: (usuarios ?? []).map((u) => ({ id: u.id, nome: u.nome })),
  };
}

export async function opcoesPosto(clienteId: string) {
  const supabase = await createClient();
  const [{ data: unidades }, { data: funcoes }, { data: escalas }] = await Promise.all([
    supabase.from("cliente_unidades").select("id, nome").eq("cliente_id", clienteId).eq("ativo", true).order("nome"),
    supabase.from("funcoes").select("id, nome").eq("ativo", true).order("nome"),
    supabase.from("escalas_modelo").select("id, nome").eq("ativo", true).order("nome"),
  ]);
  return { unidades: unidades ?? [], funcoes: funcoes ?? [], escalas: escalas ?? [] };
}
