import { z } from "zod";

const opcional = z.preprocess((v) => (typeof v === "string" && v.trim() === "" ? null : v), z.string().trim().nullable().optional());
const dataOpcional = z.preprocess((v) => (v === "" ? null : v), z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data inválida").nullable().optional());
const uuidOpcional = z.preprocess((v) => (v === "" ? null : v), z.string().uuid().nullable().optional());

/** Aceita "1.234,56", "1234,56" ou "1234.56". */
export const valorMonetario = z.preprocess((v) => {
  if (typeof v !== "string") return v;
  const s = v.trim().replace(/[R$\s]/g, "");
  if (s === "") return null;
  const normalizado = s.includes(",") ? s.replace(/\./g, "").replace(",", ".") : s;
  return Number(normalizado);
}, z.number({ message: "Valor inválido" }).nonnegative("Valor não pode ser negativo").nullable());

const numeroOpcional = (min: number, max: number) =>
  z.preprocess((v) => (v === "" || v === null ? null : Number(String(v).replace(",", "."))), z.number().min(min).max(max).nullable().optional());

export const contratoSchema = z
  .object({
    cliente_id: z.string().uuid("Selecione o cliente."),
    numero: z.string().trim().min(1, "Informe o número do contrato."),
    objeto: opcional,
    data_inicio: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Informe a data de início."),
    data_fim: dataOpcional,
    valor_mensal: valorMonetario.transform((v) => v ?? 0),
    indice_reajuste: opcional,
    data_base_reajuste: dataOpcional,
    supervisor_id: uuidOpcional,
    sla_cobertura_pct: numeroOpcional(0, 100),
    prazo_substituicao_horas: numeroOpcional(0, 720),
    regras_substituicao: opcional,
    obrigacoes: opcional,
    observacoes: opcional,
  })
  .refine((d) => !d.data_fim || d.data_fim >= d.data_inicio, {
    path: ["data_fim"],
    message: "O término deve ser igual ou posterior ao início.",
  });

export const postoSchema = z.object({
  unidade_id: z.string().uuid("Selecione a unidade."),
  funcao_id: z.string().uuid("Selecione a função."),
  escala_modelo_id: z.string().uuid("Selecione a escala."),
  quantidade: z.coerce.number().int("Quantidade inteira").min(1, "Mínimo de 1 posto").max(999),
  horario_entrada: z.string().regex(/^\d{2}:\d{2}/, "Informe o horário de entrada."),
  horario_saida: z.string().regex(/^\d{2}:\d{2}/, "Informe o horário de saída."),
  intervalo_minutos: z.coerce.number().int().min(0).max(240),
  valor_unitario: valorMonetario.transform((v) => v ?? 0),
  descricao: opcional,
  ativo: z.preprocess((v) => v === "on" || v === true, z.boolean()),
});

export const aditivoSchema = z
  .object({
    numero: z.string().trim().min(1, "Informe o número do aditivo."),
    tipo: z.enum(["reajuste", "acrescimo", "supressao", "prazo", "repactuacao", "outro"]),
    data_assinatura: dataOpcional,
    vigencia_inicio: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Informe o início da vigência."),
    valor_mensal_novo: valorMonetario.optional(),
    percentual: numeroOpcional(-100, 1000),
    nova_data_fim: dataOpcional,
    descricao: opcional,
  })
  .refine((d) => d.tipo !== "prazo" || !!d.nova_data_fim, { path: ["nova_data_fim"], message: "Informe a nova data de término." })
  .refine((d) => !["reajuste", "acrescimo", "supressao", "repactuacao"].includes(d.tipo) || d.valor_mensal_novo != null, {
    path: ["valor_mensal_novo"],
    message: "Informe o novo valor mensal.",
  });

export const STATUS_CONTRATO = ["rascunho", "ativo", "suspenso", "encerrado"] as const;
export type StatusContrato = (typeof STATUS_CONTRATO)[number];

/** Transições de status permitidas na interface (o banco valida as regras críticas). */
export const TRANSICOES: Record<StatusContrato, { para: StatusContrato; rotulo: string }[]> = {
  rascunho: [{ para: "ativo", rotulo: "Ativar contrato" }],
  ativo: [{ para: "suspenso", rotulo: "Suspender" }, { para: "encerrado", rotulo: "Encerrar" }],
  suspenso: [{ para: "ativo", rotulo: "Reativar" }, { para: "encerrado", rotulo: "Encerrar" }],
  encerrado: [],
};

export const TIPOS_ADITIVO: Record<string, string> = {
  reajuste: "Reajuste",
  acrescimo: "Acréscimo",
  supressao: "Supressão",
  prazo: "Prorrogação de prazo",
  repactuacao: "Repactuação",
  outro: "Outro",
};
