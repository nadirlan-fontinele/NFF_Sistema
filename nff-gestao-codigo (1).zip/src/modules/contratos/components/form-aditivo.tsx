"use client";
import { useActionState, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { salvarAditivo } from "../actions";
import { TIPOS_ADITIVO } from "../schema";

export function FormAditivo({ contratoId, proximoNumero }: { contratoId: string; proximoNumero: string }) {
  const [estado, acao, pendente] = useActionState(salvarAditivo.bind(null, contratoId), undefined);
  const v = (k: string) => estado?.valores?.[k] ?? "";
  const e = (k: string) => estado?.campos?.[k];
  const [tipo, setTipo] = useState(v("tipo") || "reajuste");
  const alteraValor = ["reajuste", "acrescimo", "supressao", "repactuacao"].includes(tipo);

  return (
    <form action={acao}>
      <Card>
        <CardContent className="pt-6">
          <SecaoForm titulo="Aditivo" descricao="Ao salvar, o contrato é atualizado automaticamente e o valor anterior fica no histórico.">
            <Campo id="numero" label="Número" obrigatorio erro={e("numero")}>
              <Input id="numero" name="numero" defaultValue={v("numero") || proximoNumero} />
            </Campo>
            <Campo id="tipo" label="Tipo" obrigatorio>
              <NativeSelect id="tipo" name="tipo" value={tipo} onChange={(ev) => setTipo(ev.target.value)}>
                {Object.entries(TIPOS_ADITIVO).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </NativeSelect>
            </Campo>
            <Campo id="data_assinatura" label="Data de assinatura">
              <Input id="data_assinatura" name="data_assinatura" type="date" defaultValue={v("data_assinatura")} />
            </Campo>
            <Campo id="vigencia_inicio" label="Início da vigência" obrigatorio erro={e("vigencia_inicio")}
              ajuda="Valores com vigência futura serão aplicados na data (rotina da Etapa 6).">
              <Input id="vigencia_inicio" name="vigencia_inicio" type="date" defaultValue={v("vigencia_inicio")} />
            </Campo>
            {alteraValor && (
              <>
                <Campo id="valor_mensal_novo" label="Novo valor mensal (R$)" obrigatorio erro={e("valor_mensal_novo")}>
                  <Input id="valor_mensal_novo" name="valor_mensal_novo" inputMode="decimal" defaultValue={v("valor_mensal_novo")} placeholder="0,00" />
                </Campo>
                <Campo id="percentual" label="Percentual (%)" erro={e("percentual")}>
                  <Input id="percentual" name="percentual" inputMode="decimal" defaultValue={v("percentual")} />
                </Campo>
              </>
            )}
            {tipo === "prazo" && (
              <Campo id="nova_data_fim" label="Nova data de término" obrigatorio erro={e("nova_data_fim")}>
                <Input id="nova_data_fim" name="nova_data_fim" type="date" defaultValue={v("nova_data_fim")} />
              </Campo>
            )}
            <Campo id="descricao" label="Descrição" className="sm:col-span-2">
              <Textarea id="descricao" name="descricao" rows={3} defaultValue={v("descricao")} />
            </Campo>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive" role="alert">{estado.erro}</p>}
        <Button variant="outline" asChild><Link href={`/contratos/${contratoId}`}>Cancelar</Link></Button>
        <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : "Registrar aditivo"}</Button>
      </div>
    </form>
  );
}
