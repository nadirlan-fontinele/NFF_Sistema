"use client";
import { useActionState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { salvarContrato } from "../actions";

type Opcao = { id: string; nome: string };
type Valores = Record<string, string | number | null | undefined>;

const moedaInput = (v: unknown) =>
  v === null || v === undefined || v === "" ? "" : typeof v === "number" ? v.toFixed(2).replace(".", ",") : String(v);

export function FormContrato({
  id, inicial, clientes, supervisores, verValores,
}: { id?: string; inicial?: Valores; clientes: Opcao[]; supervisores: Opcao[]; verValores: boolean }) {
  const [estado, acao, pendente] = useActionState(salvarContrato.bind(null, id ?? null), undefined);
  const v = (k: string) => String(estado?.valores?.[k] ?? inicial?.[k] ?? "");
  const e = (k: string) => estado?.campos?.[k];

  return (
    <form action={acao}>
      <Card>
        <CardContent className="pt-6">
          <SecaoForm titulo="Identificação" descricao="Cliente, número e objeto do contrato.">
            <Campo id="cliente_id" label="Cliente" obrigatorio erro={e("cliente_id")} className="sm:col-span-2">
              <NativeSelect id="cliente_id" name="cliente_id" defaultValue={v("cliente_id")} disabled={!!id} aria-invalid={!!e("cliente_id")}>
                <option value="">Selecione…</option>
                {clientes.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
              </NativeSelect>
              {id && <input type="hidden" name="cliente_id" value={v("cliente_id")} />}
            </Campo>
            <Campo id="numero" label="Número do contrato" obrigatorio erro={e("numero")}>
              <Input id="numero" name="numero" defaultValue={v("numero")} aria-invalid={!!e("numero")} />
            </Campo>
            <Campo id="supervisor_id" label="Supervisor responsável" ajuda="O supervisor vê apenas os contratos sob sua responsabilidade.">
              <NativeSelect id="supervisor_id" name="supervisor_id" defaultValue={v("supervisor_id")}>
                <option value="">Sem supervisor</option>
                {supervisores.map((s) => <option key={s.id} value={s.id}>{s.nome}</option>)}
              </NativeSelect>
            </Campo>
            <Campo id="objeto" label="Objeto" className="sm:col-span-2">
              <Textarea id="objeto" name="objeto" rows={2} defaultValue={v("objeto")} placeholder="Ex.: Prestação de serviços de limpeza e conservação predial" />
            </Campo>
          </SecaoForm>

          <SecaoForm titulo="Vigência e valores" descricao="O valor mensal pode diferir da soma dos postos (ex.: materiais incluídos).">
            <Campo id="data_inicio" label="Início" obrigatorio erro={e("data_inicio")}>
              <Input id="data_inicio" name="data_inicio" type="date" defaultValue={v("data_inicio")} aria-invalid={!!e("data_inicio")} />
            </Campo>
            <Campo id="data_fim" label="Término" ajuda="Deixe em branco se for indeterminado." erro={e("data_fim")}>
              <Input id="data_fim" name="data_fim" type="date" defaultValue={v("data_fim")} aria-invalid={!!e("data_fim")} />
            </Campo>
            {verValores && (
              <Campo id="valor_mensal" label="Valor mensal (R$)" erro={e("valor_mensal")}>
                <Input id="valor_mensal" name="valor_mensal" inputMode="decimal" defaultValue={moedaInput(estado?.valores?.valor_mensal ?? inicial?.valor_mensal)} placeholder="0,00" />
              </Campo>
            )}
            <Campo id="indice_reajuste" label="Índice de reajuste">
              <Input id="indice_reajuste" name="indice_reajuste" defaultValue={v("indice_reajuste")} placeholder="Ex.: CCT, IPCA" list="indices" />
              <datalist id="indices"><option value="CCT" /><option value="IPCA" /><option value="INPC" /><option value="IGP-M" /></datalist>
            </Campo>
            <Campo id="data_base_reajuste" label="Data-base do reajuste">
              <Input id="data_base_reajuste" name="data_base_reajuste" type="date" defaultValue={v("data_base_reajuste")} />
            </Campo>
          </SecaoForm>

          <SecaoForm titulo="Níveis de serviço" descricao="Metas usadas nos indicadores e no portal do cliente.">
            <Campo id="sla_cobertura_pct" label="Cobertura mínima dos postos (%)" erro={e("sla_cobertura_pct")}>
              <Input id="sla_cobertura_pct" name="sla_cobertura_pct" inputMode="decimal" defaultValue={v("sla_cobertura_pct")} placeholder="Ex.: 98" />
            </Campo>
            <Campo id="prazo_substituicao_horas" label="Prazo para substituição (horas)" erro={e("prazo_substituicao_horas")}>
              <Input id="prazo_substituicao_horas" name="prazo_substituicao_horas" inputMode="numeric" defaultValue={v("prazo_substituicao_horas")} placeholder="Ex.: 2" />
            </Campo>
            <Campo id="regras_substituicao" label="Regras de substituição" className="sm:col-span-2">
              <Textarea id="regras_substituicao" name="regras_substituicao" rows={3} defaultValue={v("regras_substituicao")} />
            </Campo>
            <Campo id="obrigacoes" label="Obrigações contratuais" className="sm:col-span-2">
              <Textarea id="obrigacoes" name="obrigacoes" rows={3} defaultValue={v("obrigacoes")} />
            </Campo>
            <Campo id="observacoes" label="Observações internas" className="sm:col-span-2">
              <Textarea id="observacoes" name="observacoes" rows={2} defaultValue={v("observacoes")} />
            </Campo>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive" role="alert">{estado.erro}</p>}
        <Button variant="outline" asChild><Link href={id ? `/contratos/${id}` : "/contratos"}>Cancelar</Link></Button>
        <Button type="submit" disabled={pendente}>{pendente ? "Salvando…" : id ? "Salvar alterações" : "Criar contrato"}</Button>
      </div>
    </form>
  );
}
