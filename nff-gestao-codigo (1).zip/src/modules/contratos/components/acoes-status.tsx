"use client";
import { useTransition } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { alterarStatusContrato } from "../actions";
import { TRANSICOES, type StatusContrato } from "../schema";

export function AcoesStatus({ id, status }: { id: string; status: StatusContrato }) {
  const [pendente, startTransition] = useTransition();
  return (
    <>
      {TRANSICOES[status].map((t) => (
        <Button
          key={t.para}
          variant={t.para === "ativo" ? "default" : "outline"}
          disabled={pendente}
          onClick={() =>
            startTransition(async () => {
              const r = await alterarStatusContrato(id, t.para);
              if (r?.erro) toast.error(r.erro);
              else toast.success("Situação do contrato atualizada.");
            })
          }
        >
          {t.rotulo}
        </Button>
      ))}
    </>
  );
}
