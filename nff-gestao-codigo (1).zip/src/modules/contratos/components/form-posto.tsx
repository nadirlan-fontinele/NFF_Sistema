"use client";
import { useActionState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Campo, SecaoForm } from "@/components/shared/campo";
import { salvarPosto } from "../actions";

type Opcao = { id: string; nome: string };
type Valores = Record<string, string | number | boolean | null | undefined>;

export function FormPosto({
  contratoId, id, inicial, unidades, funcoes, escalas, verValores,
}: {
  contratoId: string; id?: string; inicial?: Valores; unidades: Opcao[]; funcoes: Opcao[]; escalas: Opcao[]; verValores: boolean;
}) {
  const [estado, acao, pendente] = useActionState(salvarPosto.bind(null, contratoId, id ?? null), undefined);
  const v = (k: string) => String(estado?.valores?.[k] ?? inicial?.[k] ?? "");
  const e = (k: string) => estado?.campos?.[k];
  const ativo = estado?.valores ? estado.valores.ativo === "on" : inicial?.ativo !== false;
  const valorInicial = inicial?.valor_unitario != null ? Number(inicial.valor_unitario).toFixed(2).replace(".", ",") : "";

  return (
    <form action={acao}>
      <Card>
        <CardContent className="pt-6">
          {unidades.length === 0 && (
            <p className="mb-4 rounded-md bg-warning/15 p-3 text-sm">O cliente ainda não tem unidades. Cadastre uma unidade antes de criar postos.</p>
          )}
          <SecaoForm titulo="Posto" descricao="Função, local e quantidade contratada.">
            <Campo id="unidade_id" label="Unidade" obrigatorio erro={e("unidade_id")}>
              <NativeSelect id="unidade_id" name="unidade_id" defaultValue={v("unidade_id")} aria-invalid={!!e("unidade_id")}>
                <option value="">Selecione…</option>
                {unidades.map((u) => <option key={u.id} value={u.id}>{u.nome}</option>)}
              </NativeSelect>
            </Campo>
            <Campo id="funcao_id" label="Função" obrigatorio erro={e("funcao_id")}>
              <NativeSelect id="funcao_id" name="funcao_id" defaultValue={v("funcao_id")} aria-invalid={!!e("funcao_id")}>
                <option value="">Selecione…</option>
                {funcoes.map((f) => <option key={f.id} value={f.id}>{f.nome}</option>)}
              </NativeSelect>
            </Campo>
            <Campo id="quantidade" label="Quantidade de postos" obrigatorio erro={e("quantidade")}>
              <Input id="quantidade" name="quantidade" type="number" min={1} defaultValue={v("quantidade") || "1"} />
            </Campo>
            {verValores && (
              <Campo id="valor_unitario" label="Valor mensal por posto (R$)" erro={e("valor_unitario")}>
                <Input id="valor_unitario" name="valor_unitario" inputMode="decimal" defaultValue={estado?.valores?.valor_unitario ?? valorInicial} placeholder="0,00" />
              </Campo>
            )}
            <Campo id="descricao" label="Descrição" className="sm:col-span-2" ajuda="Ex.: Recepção do térreo, limpeza das áreas comuns.">
              <Input id="descricao" name="descricao" defaultValue={v("descricao")} />
            </Campo>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="ativo" defaultChecked={ativo} className="size-4" /> Posto ativo
            </label>
          </SecaoForm>
          <SecaoForm titulo="Jornada" descricao="Escala e horário do posto.">
            <Campo id="escala_modelo_id" label="Escala" obrigatorio erro={e("escala_modelo_id")} className="sm:col-span-2">
              <NativeSelect id="escala_modelo_id" name="escala_modelo_id" defaultValue={v("escala_modelo_id")} aria-invalid={!!e("escala_modelo_id")}>
                <option value="">Selecione…</option>
                {escalas.map((s) => <option key={s.id} value={s.id}>{s.nome}</option>)}
              </NativeSelect>
            </Campo>
            <Campo id="horario_entrada" label="Entrada" obrigatorio erro={e("horario_entrada")}>
              <Input id="horario_entrada" name="horario_entrada" type="time" defaultValue={v("horario_entrada").slice(0, 5)} />
            </Campo>
            <Campo id="horario_saida" label="Saída" obrigatorio erro={e("horario_saida")}>
              <Input id="horario_saida" name="horario_saida" type="time" defaultValue={v("horario_saida").slice(0, 5)} />
            </Campo>
            <Campo id="intervalo_minutos" label="Intervalo (minutos)" erro={e("intervalo_minutos")}>
              <Input id="intervalo_minutos" name="intervalo_minutos" type="number" min={0} defaultValue={v("intervalo_minutos") || "60"} />
            </Campo>
          </SecaoForm>
        </CardContent>
      </Card>
      <div className="mt-4 flex items-center justify-end gap-3">
        {estado?.erro && <p className="mr-auto text-sm text-destructive" role="alert">{estado.erro}</p>}
        <Button variant="outline" asChild><Link href={`/contratos/${contratoId}`}>Cancelar</Link></Button>
        <Button type="submit" disabled={pendente || unidades.length === 0}>{pendente ? "Salvando…" : "Salvar posto"}</Button>
      </div>
    </form>
  );
}
