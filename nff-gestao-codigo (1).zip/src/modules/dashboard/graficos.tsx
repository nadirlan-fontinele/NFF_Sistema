"use client";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { formatarMoeda } from "@/lib/format";

const CORES_STATUS: Record<string, string> = {
  Ativo: "var(--chart-2)", Rascunho: "var(--chart-3)", Suspenso: "var(--chart-4)", Encerrado: "var(--muted-foreground)",
};

export function GraficoReceitaPorCliente({ dados }: { dados: { cliente: string; valor: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={Math.max(160, dados.length * 38)}>
      <BarChart data={dados} layout="vertical" margin={{ left: 8, right: 24, top: 4, bottom: 4 }}>
        <CartesianGrid horizontal={false} stroke="var(--border)" />
        <XAxis type="number" tickFormatter={(v) => `R$ ${(v / 1000).toLocaleString("pt-BR")} mil`} fontSize={11} stroke="var(--muted-foreground)" />
        <YAxis type="category" dataKey="cliente" width={130} fontSize={12} stroke="var(--muted-foreground)" tickLine={false} />
        <Tooltip formatter={(v) => [formatarMoeda(Number(v)), "Receita mensal"]} cursor={{ fill: "var(--muted)" }} />
        <Bar dataKey="valor" fill="var(--chart-1)" radius={[0, 4, 4, 0]} barSize={20} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function GraficoStatus({ dados }: { dados: { status: string; total: number }[] }) {
  return (
    <div className="flex items-center gap-4">
      <ResponsiveContainer width="50%" height={160}>
        <PieChart>
          <Pie data={dados} dataKey="total" nameKey="status" innerRadius={45} outerRadius={70} paddingAngle={2}>
            {dados.map((d) => <Cell key={d.status} fill={CORES_STATUS[d.status] ?? "var(--chart-5)"} />)}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
      <ul className="space-y-1.5 text-sm">
        {dados.map((d) => (
          <li key={d.status} className="flex items-center gap-2">
            <span className="size-2.5 rounded-full" style={{ background: CORES_STATUS[d.status] ?? "var(--chart-5)" }} />
            {d.status}: <strong>{d.total}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}
