-- =====================================================================
-- NFF Gestão · Migração 004 · Vínculo de novo usuário via app_metadata
-- ---------------------------------------------------------------------
-- user_metadata pode ser preenchido pelo próprio usuário no cadastro;
-- app_metadata só pode ser definido pelo servidor (chave service_role).
-- Assim, ninguém consegue se vincular a uma organização sozinho.
-- =====================================================================
create or replace function private.on_auth_user_created()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_meta jsonb := coalesce(new.raw_app_meta_data, '{}'::jsonb);
  v_org  uuid;
begin
  v_org := nullif(v_meta ->> 'organizacao_id', '')::uuid;
  if v_org is null then
    return new;  -- sem vínculo: o usuário não acessa nada
  end if;
  insert into public.usuarios (id, organizacao_id, nome, email, tipo, cliente_id)
  values (
    new.id, v_org,
    coalesce(v_meta ->> 'nome', new.raw_user_meta_data ->> 'nome', split_part(new.email, '@', 1)),
    new.email,
    coalesce((v_meta ->> 'tipo')::public.tipo_usuario, 'interno'),
    nullif(v_meta ->> 'cliente_id', '')::uuid
  )
  on conflict (id) do nothing;
  return new;
end $$;
