-- =====================================================================
-- NFF Gestão · Migração 006 · Regras de aditivos e transição de status
-- =====================================================================

-- Ao registrar um aditivo, o contrato é atualizado automaticamente:
--  * reajuste/acréscimo/supressão/repactuação com valor novo → valor_mensal
--  * prazo com nova data de término → data_fim
-- O valor anterior fica gravado no próprio aditivo (histórico).
create or replace function private.aplicar_aditivo()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_valor numeric(14,2);
begin
  select valor_mensal into v_valor from public.contratos where id = new.contrato_id for update;
  new.valor_mensal_anterior := v_valor;

  if new.valor_mensal_novo is not null and new.vigencia_inicio <= current_date then
    update public.contratos set valor_mensal = new.valor_mensal_novo where id = new.contrato_id;
  end if;
  if new.nova_data_fim is not null then
    update public.contratos set data_fim = new.nova_data_fim where id = new.contrato_id;
  end if;
  return new;
end $$;

create trigger trg_aditivo_aplicar before insert on public.contrato_aditivos
  for each row execute function private.aplicar_aditivo();

-- Regras de status do contrato:
--  * Só é possível ativar um contrato que tenha ao menos um posto ativo.
--  * Contrato encerrado não volta a ser ativo (crie um novo ou um aditivo).
create or replace function private.validar_status_contrato()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status = 'ativo' and old.status is distinct from 'ativo' then
    if not exists (select 1 from public.contrato_postos where contrato_id = new.id and ativo) then
      raise exception 'Cadastre ao menos um posto ativo antes de ativar o contrato.'
        using errcode = 'check_violation';
    end if;
  end if;
  if old.status = 'encerrado' and new.status <> 'encerrado' then
    raise exception 'Contrato encerrado não pode ser reaberto.' using errcode = 'check_violation';
  end if;
  return new;
end $$;

create trigger trg_contratos_status before update of status on public.contratos
  for each row execute function private.validar_status_contrato();

-- Sugestão do próximo número de contrato: NFF-AAAA-NNN
create or replace function public.proximo_numero_contrato()
returns text language sql stable security invoker set search_path = '' as $$
  select 'NFF-' || to_char(current_date, 'YYYY') || '-' ||
         lpad((coalesce(max(nullif(regexp_replace(numero, '^NFF-\d{4}-', ''), numero)::int), 0) + 1)::text, 3, '0')
  from public.contratos
  where numero ~ ('^NFF-' || to_char(current_date, 'YYYY') || '-\d+$')
$$;
revoke execute on function public.proximo_numero_contrato() from public, anon;
grant execute on function public.proximo_numero_contrato() to authenticated;
