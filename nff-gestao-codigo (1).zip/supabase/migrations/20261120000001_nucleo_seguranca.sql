-- =====================================================================
-- NFF Gestão · Migração 001 · Núcleo, perfis, permissões e auditoria
-- =====================================================================
-- Convenções:
--   * Toda tabela de negócio tem organizacao_id (multiempresa).
--   * RLS habilitado em todas as tabelas.
--   * Funções auxiliares de segurança ficam no schema "private", que não
--     é exposto pela API REST do Supabase.
-- =====================================================================

create extension if not exists pgcrypto;

create schema if not exists private;
grant usage on schema private to authenticated, service_role;

-- ---------------------------------------------------------------------
-- Utilitário: updated_at automático
-- ---------------------------------------------------------------------
create or replace function private.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------------
-- Organizações
-- ---------------------------------------------------------------------
create table public.organizacoes (
  id          uuid primary key default gen_random_uuid(),
  nome        text not null,
  cnpj        text unique,
  demonstracao boolean not null default false, -- true = ambiente de dados fictícios
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
comment on column public.organizacoes.demonstracao is
  'Organização de demonstração: contém apenas dados fictícios, separados dos reais.';
create trigger trg_organizacoes_updated before update on public.organizacoes
  for each row execute function private.set_updated_at();

-- ---------------------------------------------------------------------
-- Usuários (perfil de aplicação, 1:1 com auth.users)
-- ---------------------------------------------------------------------
create type public.tipo_usuario as enum ('interno', 'cliente', 'colaborador');

create table public.usuarios (
  id              uuid primary key references auth.users(id) on delete cascade,
  organizacao_id  uuid not null references public.organizacoes(id),
  nome            text not null,
  email           text not null,
  telefone        text,
  tipo            public.tipo_usuario not null default 'interno',
  cliente_id      uuid,           -- FK adicionada na migração de clientes
  ativo           boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint usuarios_cliente_obrigatorio
    check (tipo <> 'cliente' or cliente_id is not null)
);
create index on public.usuarios (organizacao_id);
create trigger trg_usuarios_updated before update on public.usuarios
  for each row execute function private.set_updated_at();

-- ---------------------------------------------------------------------
-- Catálogo de permissões (global) e perfis (por organização)
-- ---------------------------------------------------------------------
create table public.permissoes (
  id        uuid primary key default gen_random_uuid(),
  modulo    text not null,
  acao      text not null,
  descricao text not null,
  unique (modulo, acao)
);

create table public.perfis (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null references public.organizacoes(id) on delete cascade,
  codigo          text not null,
  nome            text not null,
  descricao       text,
  sistema         boolean not null default false, -- perfis padrão não podem ser excluídos
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organizacao_id, codigo)
);
create trigger trg_perfis_updated before update on public.perfis
  for each row execute function private.set_updated_at();

create table public.perfil_permissoes (
  perfil_id     uuid not null references public.perfis(id) on delete cascade,
  permissao_id  uuid not null references public.permissoes(id) on delete cascade,
  primary key (perfil_id, permissao_id)
);

create table public.usuario_perfis (
  usuario_id  uuid not null references public.usuarios(id) on delete cascade,
  perfil_id   uuid not null references public.perfis(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (usuario_id, perfil_id)
);
create index on public.usuario_perfis (perfil_id);

-- ---------------------------------------------------------------------
-- Funções de segurança (usadas nas políticas RLS e pelo servidor)
-- ---------------------------------------------------------------------
create or replace function private.org_atual()
returns uuid language sql stable security definer set search_path = '' as $$
  select u.organizacao_id from public.usuarios u
  where u.id = auth.uid() and u.ativo
$$;

create or replace function private.tipo_usuario_atual()
returns public.tipo_usuario language sql stable security definer set search_path = '' as $$
  select u.tipo from public.usuarios u where u.id = auth.uid() and u.ativo
$$;

create or replace function private.eh_interno()
returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce(private.tipo_usuario_atual() = 'interno', false)
$$;

create or replace function private.cliente_atual()
returns uuid language sql stable security definer set search_path = '' as $$
  select u.cliente_id from public.usuarios u
  where u.id = auth.uid() and u.ativo and u.tipo = 'cliente'
$$;

create or replace function private.tem_permissao(p_modulo text, p_acao text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1
    from public.usuarios u
    join public.usuario_perfis up on up.usuario_id = u.id
    join public.perfil_permissoes pp on pp.perfil_id = up.perfil_id
    join public.permissoes p on p.id = pp.permissao_id
    where u.id = auth.uid() and u.ativo
      and p.modulo = p_modulo and p.acao = p_acao
  )
$$;

grant execute on all functions in schema private to authenticated, service_role;

-- Versão pública (RPC) para o front consultar as próprias permissões
create or replace function public.minhas_permissoes()
returns table (modulo text, acao text)
language sql stable security definer set search_path = '' as $$
  select distinct p.modulo, p.acao
  from public.usuarios u
  join public.usuario_perfis up on up.usuario_id = u.id
  join public.perfil_permissoes pp on pp.perfil_id = up.perfil_id
  join public.permissoes p on p.id = pp.permissao_id
  where u.id = auth.uid() and u.ativo
$$;
revoke execute on function public.minhas_permissoes() from public, anon;
grant execute on function public.minhas_permissoes() to authenticated;

-- ---------------------------------------------------------------------
-- Auditoria
-- ---------------------------------------------------------------------
create table public.auditoria_log (
  id              bigint generated always as identity primary key,
  organizacao_id  uuid,
  tabela          text not null,
  registro_id     text,
  acao            text not null check (acao in ('INSERT','UPDATE','DELETE')),
  dados_antes     jsonb,
  dados_depois    jsonb,
  campos_alterados text[],
  usuario_id      uuid,
  created_at      timestamptz not null default now()
);
create index on public.auditoria_log (organizacao_id, created_at desc);
create index on public.auditoria_log (tabela, registro_id);

create or replace function private.registrar_auditoria()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_antes  jsonb;
  v_depois jsonb;
  v_reg    jsonb;
  v_campos text[];
begin
  if tg_op in ('UPDATE','DELETE') then v_antes := to_jsonb(old); end if;
  if tg_op in ('INSERT','UPDATE') then v_depois := to_jsonb(new); end if;
  v_reg := coalesce(v_depois, v_antes);

  if tg_op = 'UPDATE' then
    select array_agg(k) into v_campos
    from jsonb_object_keys(v_depois) k
    where k not in ('updated_at')
      and (v_antes -> k) is distinct from (v_depois -> k);
    if v_campos is null then return new; end if; -- nada mudou de fato
  end if;

  insert into public.auditoria_log
    (organizacao_id, tabela, registro_id, acao, dados_antes, dados_depois, campos_alterados, usuario_id)
  values (
    nullif(v_reg ->> 'organizacao_id', '')::uuid,
    tg_table_name,
    coalesce(v_reg ->> 'id', v_reg ->> 'usuario_id', v_reg ->> 'perfil_id'),
    tg_op, v_antes, v_depois, v_campos, auth.uid()
  );
  return coalesce(new, old);
end $$;

create or replace function private.auditar(p_tabela regclass)
returns void language plpgsql as $$
begin
  execute format(
    'create trigger trg_auditoria after insert or update or delete on %s
       for each row execute function private.registrar_auditoria()', p_tabela);
end $$;

select private.auditar('public.usuarios');
select private.auditar('public.perfis');
select private.auditar('public.perfil_permissoes');
select private.auditar('public.usuario_perfis');

-- ---------------------------------------------------------------------
-- Notificações e parâmetros
-- ---------------------------------------------------------------------
create table public.notificacoes (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null references public.organizacoes(id) on delete cascade,
  usuario_id      uuid not null references public.usuarios(id) on delete cascade,
  tipo            text not null,
  titulo          text not null,
  mensagem        text,
  link            text,
  lida            boolean not null default false,
  created_at      timestamptz not null default now()
);
create index on public.notificacoes (usuario_id, lida, created_at desc);

create table public.parametros (
  organizacao_id  uuid not null references public.organizacoes(id) on delete cascade,
  chave           text not null,
  valor           jsonb not null,
  descricao       text,
  updated_at      timestamptz not null default now(),
  primary key (organizacao_id, chave)
);

-- ---------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------
alter table public.organizacoes      enable row level security;
alter table public.usuarios          enable row level security;
alter table public.permissoes        enable row level security;
alter table public.perfis            enable row level security;
alter table public.perfil_permissoes enable row level security;
alter table public.usuario_perfis    enable row level security;
alter table public.auditoria_log     enable row level security;
alter table public.notificacoes      enable row level security;
alter table public.parametros        enable row level security;

-- Organizações: cada usuário vê a própria
create policy org_select on public.organizacoes for select to authenticated
  using (id = private.org_atual());
create policy org_update on public.organizacoes for update to authenticated
  using (id = private.org_atual() and private.tem_permissao('admin','parametros'))
  with check (id = private.org_atual());

-- Usuários: o próprio registro; internos veem colegas internos da mesma org;
-- administradores de usuários veem e gerenciam todos da org.
create policy usuarios_select on public.usuarios for select to authenticated
  using (
    id = auth.uid()
    or (organizacao_id = private.org_atual()
        and (private.tem_permissao('admin','usuarios')
             or (private.eh_interno() and tipo = 'interno')))
  );
create policy usuarios_insert on public.usuarios for insert to authenticated
  with check (organizacao_id = private.org_atual() and private.tem_permissao('admin','usuarios'));
create policy usuarios_update on public.usuarios for update to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('admin','usuarios'))
  with check (organizacao_id = private.org_atual());

-- Catálogo de permissões: leitura para autenticados
create policy permissoes_select on public.permissoes for select to authenticated using (true);

-- Perfis
create policy perfis_select on public.perfis for select to authenticated
  using (organizacao_id = private.org_atual());
create policy perfis_write on public.perfis for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('admin','perfis'))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('admin','perfis'));

create policy perfil_permissoes_select on public.perfil_permissoes for select to authenticated
  using (exists (select 1 from public.perfis p where p.id = perfil_id and p.organizacao_id = private.org_atual()));
create policy perfil_permissoes_write on public.perfil_permissoes for all to authenticated
  using (private.tem_permissao('admin','perfis')
         and exists (select 1 from public.perfis p where p.id = perfil_id and p.organizacao_id = private.org_atual()))
  with check (private.tem_permissao('admin','perfis')
         and exists (select 1 from public.perfis p where p.id = perfil_id and p.organizacao_id = private.org_atual()));

create policy usuario_perfis_select on public.usuario_perfis for select to authenticated
  using (usuario_id = auth.uid()
         or (private.tem_permissao('admin','usuarios')
             and exists (select 1 from public.usuarios u where u.id = usuario_id and u.organizacao_id = private.org_atual())));
create policy usuario_perfis_write on public.usuario_perfis for all to authenticated
  using (private.tem_permissao('admin','usuarios')
         and exists (select 1 from public.usuarios u where u.id = usuario_id and u.organizacao_id = private.org_atual()))
  with check (private.tem_permissao('admin','usuarios')
         and exists (select 1 from public.usuarios u where u.id = usuario_id and u.organizacao_id = private.org_atual())
         and exists (select 1 from public.perfis p where p.id = perfil_id and p.organizacao_id = private.org_atual()));

-- Auditoria: só leitura, com permissão
create policy auditoria_select on public.auditoria_log for select to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('admin','auditoria'));

-- Notificações: só as próprias
create policy notificacoes_select on public.notificacoes for select to authenticated
  using (usuario_id = auth.uid());
create policy notificacoes_update on public.notificacoes for update to authenticated
  using (usuario_id = auth.uid()) with check (usuario_id = auth.uid());

-- Parâmetros
create policy parametros_select on public.parametros for select to authenticated
  using (organizacao_id = private.org_atual() and private.eh_interno());
create policy parametros_write on public.parametros for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('admin','parametros'))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('admin','parametros'));

-- ---------------------------------------------------------------------
-- Novo usuário no Auth → cria registro em public.usuarios
-- (o cadastro público deve ficar DESLIGADO no Supabase; usuários são
--  convidados pelo administrador, que informa a organização nos metadados)
-- ---------------------------------------------------------------------
create or replace function private.on_auth_user_created()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_org uuid;
begin
  v_org := nullif(new.raw_user_meta_data ->> 'organizacao_id', '')::uuid;
  if v_org is null then
    return new; -- sem organização: o registro será criado pelo convite
  end if;
  insert into public.usuarios (id, organizacao_id, nome, email, tipo, cliente_id)
  values (
    new.id, v_org,
    coalesce(new.raw_user_meta_data ->> 'nome', split_part(new.email, '@', 1)),
    new.email,
    coalesce((new.raw_user_meta_data ->> 'tipo')::public.tipo_usuario, 'interno'),
    nullif(new.raw_user_meta_data ->> 'cliente_id', '')::uuid
  )
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function private.on_auth_user_created();
