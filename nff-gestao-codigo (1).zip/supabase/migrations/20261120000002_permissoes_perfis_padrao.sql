-- =====================================================================
-- NFF Gestão · Migração 002 · Catálogo de permissões e perfis padrão
-- =====================================================================

insert into public.permissoes (modulo, acao, descricao) values
  -- Administração
  ('admin','usuarios','Gerenciar usuários e atribuir perfis'),
  ('admin','perfis','Gerenciar perfis e matriz de permissões'),
  ('admin','auditoria','Consultar logs de auditoria'),
  ('admin','parametros','Editar parâmetros da organização'),
  ('dashboard','ver','Ver dashboard executivo'),
  -- Cadastros
  ('clientes','ver','Ver clientes e unidades'),
  ('clientes','criar','Cadastrar clientes e unidades'),
  ('clientes','editar','Editar clientes e unidades'),
  ('clientes','excluir','Excluir clientes e unidades'),
  ('cadastros','ver','Ver funções e escalas-modelo'),
  ('cadastros','editar','Editar funções e escalas-modelo'),
  -- Contratos
  ('contratos','ver','Ver contratos (supervisor: só os seus)'),
  ('contratos','ver_todos','Ver todos os contratos'),
  ('contratos','criar','Cadastrar contratos e postos'),
  ('contratos','editar','Editar contratos, postos e aditivos'),
  ('contratos','excluir','Excluir contratos em rascunho'),
  ('contratos','ver_valores','Ver valores financeiros dos contratos'),
  ('contratos','exportar','Exportar relatórios de contratos'),
  -- Operacional (Etapa 3)
  ('operacional','ver','Ver escalas, frequência e postos'),
  ('operacional','registrar','Registrar frequência e ocorrências'),
  ('operacional','gerenciar','Gerenciar escalas e alocações'),
  ('operacional','aprovar_substituicao','Aprovar substituições'),
  ('operacional','exportar','Exportar relatórios operacionais'),
  -- RH (Etapa 4)
  ('rh','ver','Ver colaboradores'),
  ('rh','editar','Cadastrar e editar colaboradores'),
  ('rh','ver_sensivel','Ver dados sensíveis (atestados, documentos, bancários)'),
  ('rh','ver_salario','Ver salários'),
  ('rh','admitir','Admitir e desligar colaboradores'),
  ('recrutamento','ver','Ver vagas e candidatos'),
  ('recrutamento','editar','Gerenciar vagas e candidaturas'),
  -- Comercial (Etapa 5)
  ('comercial','ver','Ver CRM (vendedor: só os seus)'),
  ('comercial','ver_todos','Ver CRM de todos os vendedores'),
  ('comercial','editar','Gerenciar leads, oportunidades e propostas'),
  ('comercial','aprovar_proposta','Aprovar propostas e preços'),
  ('comercial','converter','Converter venda em contrato'),
  -- Financeiro (Etapa 6)
  ('financeiro','ver','Ver financeiro'),
  ('financeiro','editar','Lançar e editar títulos'),
  ('financeiro','aprovar_pagamento','Aprovar pagamentos'),
  ('financeiro','exportar','Exportar relatórios financeiros'),
  -- Marketing (Etapa 7)
  ('marketing','ver','Ver marketing'),
  ('marketing','editar','Criar conteúdos e campanhas'),
  ('marketing','publicar','Aprovar e publicar conteúdos'),
  -- Portal e IA
  ('portal','ver','Acessar o portal do cliente'),
  ('portal','abrir_chamado','Abrir chamados no portal'),
  ('ia','assistente','Usar o assistente gerencial de IA'),
  ('colaborador','ver_proprio','Ver os próprios dados de colaborador');

-- Cria (ou atualiza) os perfis padrão de uma organização
create or replace function private.criar_perfis_padrao(p_org uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare
  r record;
begin
  for r in
    select * from (values
      ('admin','Administrador geral','Acesso total, inclusive usuários e perfis', array['*']),
      ('diretoria','Diretoria','Visão consolidada e aprovações',
        array['dashboard.ver','clientes.ver','cadastros.ver','contratos.ver','contratos.ver_todos','contratos.ver_valores','contratos.exportar',
              'operacional.ver','operacional.exportar','operacional.aprovar_substituicao','rh.ver','rh.ver_salario','recrutamento.ver',
              'comercial.ver','comercial.ver_todos','comercial.aprovar_proposta','financeiro.ver','financeiro.aprovar_pagamento','financeiro.exportar',
              'marketing.ver','admin.auditoria','ia.assistente']),
      ('gerente_financeiro','Gerente financeiro','Financeiro completo e aprovação de pagamentos',
        array['dashboard.ver','clientes.ver','cadastros.ver','contratos.ver','contratos.ver_todos','contratos.ver_valores','contratos.exportar',
              'rh.ver','rh.ver_salario','financeiro.ver','financeiro.editar','financeiro.aprovar_pagamento','financeiro.exportar','ia.assistente']),
      ('analista_financeiro','Analista financeiro','Lançamentos financeiros sem aprovação',
        array['clientes.ver','contratos.ver','contratos.ver_todos','contratos.ver_valores','financeiro.ver','financeiro.editar','financeiro.exportar']),
      ('gerente_rh','Gerente de RH','RH completo, inclusive dados sensíveis',
        array['dashboard.ver','clientes.ver','cadastros.ver','cadastros.editar','contratos.ver','contratos.ver_todos','operacional.ver',
              'operacional.gerenciar','rh.ver','rh.editar','rh.ver_sensivel','rh.ver_salario','rh.admitir','recrutamento.ver','recrutamento.editar','ia.assistente']),
      ('recrutador','Recrutador','Vagas e candidatos',
        array['clientes.ver','cadastros.ver','contratos.ver','contratos.ver_todos','rh.ver','recrutamento.ver','recrutamento.editar']),
      ('gerente_comercial','Gerente comercial','CRM de todos os vendedores e propostas',
        array['dashboard.ver','clientes.ver','clientes.criar','clientes.editar','cadastros.ver','contratos.ver','contratos.ver_todos','contratos.ver_valores',
              'contratos.criar','comercial.ver','comercial.ver_todos','comercial.editar','comercial.aprovar_proposta','comercial.converter','marketing.ver','ia.assistente']),
      ('vendedor','Vendedor','Somente as próprias oportunidades',
        array['clientes.ver','clientes.criar','cadastros.ver','comercial.ver','comercial.editar']),
      ('marketing','Marketing','Conteúdos, campanhas e leads gerados',
        array['marketing.ver','marketing.editar','marketing.publicar','comercial.ver','recrutamento.ver']),
      ('gerente_operacional','Gerente operacional','Todos os contratos, escalas e frequência',
        array['dashboard.ver','clientes.ver','clientes.criar','clientes.editar','cadastros.ver','cadastros.editar','contratos.ver','contratos.ver_todos',
              'contratos.criar','contratos.editar','contratos.exportar','operacional.ver','operacional.registrar','operacional.gerenciar',
              'operacional.aprovar_substituicao','operacional.exportar','rh.ver','recrutamento.ver','ia.assistente']),
      ('supervisor','Supervisor de contrato','Somente os contratos sob sua supervisão',
        array['clientes.ver','cadastros.ver','contratos.ver','operacional.ver','operacional.registrar','rh.ver']),
      ('cliente','Cliente','Portal do cliente: somente os próprios contratos',
        array['portal.ver','portal.abrir_chamado']),
      ('colaborador','Colaborador','Somente os próprios dados',
        array['colaborador.ver_proprio'])
    ) as t(codigo, nome, descricao, perms)
  loop
    insert into public.perfis (organizacao_id, codigo, nome, descricao, sistema)
    values (p_org, r.codigo, r.nome, r.descricao, true)
    on conflict (organizacao_id, codigo) do update
      set nome = excluded.nome, descricao = excluded.descricao;

    insert into public.perfil_permissoes (perfil_id, permissao_id)
    select pf.id, p.id
    from public.perfis pf
    cross join public.permissoes p
    where pf.organizacao_id = p_org and pf.codigo = r.codigo
      and ('*' = any(r.perms) or (p.modulo || '.' || p.acao) = any(r.perms))
    on conflict do nothing;
  end loop;
end $$;

-- Toda nova organização recebe os perfis padrão
create or replace function private.on_organizacao_criada()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform private.criar_perfis_padrao(new.id);
  return new;
end $$;
create trigger trg_organizacao_perfis after insert on public.organizacoes
  for each row execute function private.on_organizacao_criada();

-- Perfis de sistema não podem ser excluídos
create or replace function private.proteger_perfil_sistema()
returns trigger language plpgsql as $$
begin
  if old.sistema then
    raise exception 'Perfis padrão do sistema não podem ser excluídos.';
  end if;
  return old;
end $$;
create trigger trg_perfis_protecao before delete on public.perfis
  for each row execute function private.proteger_perfil_sistema();
