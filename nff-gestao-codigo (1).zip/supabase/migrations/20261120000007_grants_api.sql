-- =====================================================================
-- NFF Gestão · Migração 007 · Privilégios explícitos para a API
-- ---------------------------------------------------------------------
-- Projetos Supabase recentes não concedem SELECT/INSERT/UPDATE/DELETE
-- automaticamente às roles da API. Concedemos explicitamente ao papel
-- "authenticated"; quem decide QUAIS linhas cada usuário acessa são as
-- políticas RLS. O papel "anon" (visitante) não recebe nada.
-- =====================================================================
grant select, insert, update, delete on all tables in schema public to authenticated, service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;

-- Tabelas apenas de leitura pela aplicação (escrita só via triggers/servidor)
revoke insert, update, delete on public.auditoria_log from authenticated;
revoke insert, update, delete on public.permissoes from authenticated;
revoke insert, update, delete on public.vw_contratos_resumo from authenticated;

-- Novas tabelas criadas pelo dono das migrações seguem a mesma regra
alter default privileges in schema public grant select, insert, update, delete on tables to authenticated, service_role;
alter default privileges in schema public grant usage, select on sequences to authenticated, service_role;
