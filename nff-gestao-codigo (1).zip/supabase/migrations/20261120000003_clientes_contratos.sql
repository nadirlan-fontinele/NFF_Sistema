-- =====================================================================
-- NFF Gestão · Migração 003 · Clientes, unidades, funções, escalas,
-- contratos, postos, aditivos e indicadores contratuais
-- =====================================================================

-- ---------------------------------------------------------------------
-- Clientes
-- ---------------------------------------------------------------------
create type public.status_cliente as enum ('ativo', 'inativo', 'prospecto');

create table public.clientes (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  tipo_pessoa     text not null default 'PJ' check (tipo_pessoa in ('PJ','PF')),
  razao_social    text not null,
  nome_fantasia   text,
  documento       text not null,          -- CNPJ ou CPF, só dígitos
  inscricao_estadual text,
  email           text,
  telefone        text,
  contato_nome    text,
  cep text, logradouro text, numero text, complemento text, bairro text, cidade text, uf char(2),
  status          public.status_cliente not null default 'ativo',
  observacoes     text,
  created_by      uuid default auth.uid(),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organizacao_id, documento),
  constraint clientes_documento_digitos check (documento ~ '^[0-9]{11}$|^[0-9]{14}$')
);
create index on public.clientes (organizacao_id, status);
create trigger trg_clientes_updated before update on public.clientes
  for each row execute function private.set_updated_at();

alter table public.usuarios
  add constraint usuarios_cliente_fk foreign key (cliente_id) references public.clientes(id);

create table public.cliente_unidades (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  cliente_id      uuid not null references public.clientes(id) on delete cascade,
  nome            text not null,
  cep text, logradouro text, numero text, complemento text, bairro text, cidade text, uf char(2),
  latitude        numeric(9,6),
  longitude       numeric(9,6),
  responsavel_nome     text,
  responsavel_telefone text,
  responsavel_email    text,
  ativo           boolean not null default true,
  created_by      uuid default auth.uid(),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (cliente_id, nome)
);
create index on public.cliente_unidades (cliente_id);
create trigger trg_unidades_updated before update on public.cliente_unidades
  for each row execute function private.set_updated_at();

-- ---------------------------------------------------------------------
-- Funções (cargos) e escalas-modelo
-- ---------------------------------------------------------------------
create table public.funcoes (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  nome            text not null,
  cbo             text,
  descricao       text,
  salario_base    numeric(14,2),
  ativo           boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organizacao_id, nome)
);
create trigger trg_funcoes_updated before update on public.funcoes
  for each row execute function private.set_updated_at();

create type public.tipo_escala as enum ('5x2', '6x1', '12x36', 'personalizada');

create table public.escalas_modelo (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  nome            text not null,
  tipo            public.tipo_escala not null,
  dias_trabalho   smallint not null check (dias_trabalho between 1 and 31),
  dias_folga      smallint not null check (dias_folga between 0 and 31),
  horas_jornada   numeric(4,2) not null check (horas_jornada > 0 and horas_jornada <= 24),
  carga_semanal   numeric(5,2),
  noturno         boolean not null default false,
  descricao       text,
  ativo           boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organizacao_id, nome)
);
create trigger trg_escalas_modelo_updated before update on public.escalas_modelo
  for each row execute function private.set_updated_at();

-- ---------------------------------------------------------------------
-- Contratos
-- ---------------------------------------------------------------------
create type public.status_contrato as enum ('rascunho', 'ativo', 'suspenso', 'encerrado');

create table public.contratos (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  cliente_id      uuid not null references public.clientes(id),
  numero          text not null,
  objeto          text,
  data_inicio     date not null,
  data_fim        date,
  valor_mensal    numeric(14,2) not null default 0 check (valor_mensal >= 0),
  indice_reajuste text,                 -- ex.: CCT, IPCA, INPC
  data_base_reajuste date,
  supervisor_id   uuid references public.usuarios(id),
  regras_substituicao text,
  obrigacoes      text,
  sla_cobertura_pct numeric(5,2) check (sla_cobertura_pct between 0 and 100),
  prazo_substituicao_horas smallint check (prazo_substituicao_horas >= 0),
  status          public.status_contrato not null default 'rascunho',
  origem_tipo     text,                 -- ex.: 'proposta' (Etapa 5)
  origem_id       uuid,
  observacoes     text,
  created_by      uuid default auth.uid(),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organizacao_id, numero),
  constraint contratos_periodo check (data_fim is null or data_fim >= data_inicio)
);
create index on public.contratos (organizacao_id, status);
create index on public.contratos (cliente_id);
create index on public.contratos (supervisor_id);
create trigger trg_contratos_updated before update on public.contratos
  for each row execute function private.set_updated_at();

-- Postos contratados
create table public.contrato_postos (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  contrato_id     uuid not null references public.contratos(id) on delete cascade,
  unidade_id      uuid not null references public.cliente_unidades(id),
  funcao_id       uuid not null references public.funcoes(id),
  escala_modelo_id uuid not null references public.escalas_modelo(id),
  descricao       text,
  quantidade      smallint not null check (quantidade > 0),
  horario_entrada time not null,
  horario_saida   time not null,
  intervalo_minutos smallint not null default 60 check (intervalo_minutos >= 0),
  valor_unitario  numeric(14,2) not null default 0 check (valor_unitario >= 0),
  valor_total     numeric(14,2) generated always as (quantidade * valor_unitario) stored,
  ativo           boolean not null default true,
  created_by      uuid default auth.uid(),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index on public.contrato_postos (contrato_id);
create index on public.contrato_postos (unidade_id);
create trigger trg_postos_updated before update on public.contrato_postos
  for each row execute function private.set_updated_at();

-- Regra: a unidade do posto deve pertencer ao cliente do contrato
create or replace function private.validar_posto()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if not exists (
    select 1 from public.contratos c
    join public.cliente_unidades u on u.cliente_id = c.cliente_id
    where c.id = new.contrato_id and u.id = new.unidade_id
  ) then
    raise exception 'A unidade informada não pertence ao cliente do contrato.'
      using errcode = 'check_violation';
  end if;
  return new;
end $$;
create trigger trg_postos_validar before insert or update on public.contrato_postos
  for each row execute function private.validar_posto();

-- Aditivos
create type public.tipo_aditivo as enum ('reajuste', 'acrescimo', 'supressao', 'prazo', 'repactuacao', 'outro');

create table public.contrato_aditivos (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  contrato_id     uuid not null references public.contratos(id) on delete cascade,
  numero          text not null,
  tipo            public.tipo_aditivo not null,
  data_assinatura date,
  vigencia_inicio date not null,
  valor_mensal_anterior numeric(14,2),
  valor_mensal_novo     numeric(14,2),
  percentual      numeric(7,4),
  nova_data_fim   date,
  descricao       text,
  created_by      uuid default auth.uid(),
  created_at      timestamptz not null default now(),
  unique (contrato_id, numero)
);

-- Indicadores contratuais (KPIs e metas)
create table public.contrato_indicadores (
  id              uuid primary key default gen_random_uuid(),
  organizacao_id  uuid not null default private.org_atual() references public.organizacoes(id),
  contrato_id     uuid not null references public.contratos(id) on delete cascade,
  nome            text not null,
  meta            numeric(14,4),
  unidade_medida  text,                -- ex.: '%', 'horas'
  descricao       text,
  created_at      timestamptz not null default now()
);

-- Auditoria
select private.auditar('public.clientes');
select private.auditar('public.cliente_unidades');
select private.auditar('public.funcoes');
select private.auditar('public.escalas_modelo');
select private.auditar('public.contratos');
select private.auditar('public.contrato_postos');
select private.auditar('public.contrato_aditivos');
select private.auditar('public.contrato_indicadores');

-- ---------------------------------------------------------------------
-- Escopo de contratos visíveis ao usuário atual
-- ---------------------------------------------------------------------
create or replace function private.pode_ver_contrato(p_contrato uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.contratos c
    where c.id = p_contrato
      and (
        (c.organizacao_id = private.org_atual() and private.eh_interno()
          and private.tem_permissao('contratos','ver')
          and (private.tem_permissao('contratos','ver_todos') or c.supervisor_id = auth.uid()))
        or
        (c.cliente_id = private.cliente_atual() and c.status <> 'rascunho'
          and private.tem_permissao('portal','ver'))
      )
  )
$$;
grant execute on function private.pode_ver_contrato(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------
alter table public.clientes             enable row level security;
alter table public.cliente_unidades     enable row level security;
alter table public.funcoes              enable row level security;
alter table public.escalas_modelo       enable row level security;
alter table public.contratos            enable row level security;
alter table public.contrato_postos      enable row level security;
alter table public.contrato_aditivos    enable row level security;
alter table public.contrato_indicadores enable row level security;

-- Clientes: internos com permissão; usuário do cliente vê o próprio cadastro
create policy clientes_select on public.clientes for select to authenticated using (
  (organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','ver'))
  or id = private.cliente_atual()
);
create policy clientes_insert on public.clientes for insert to authenticated with check (
  organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','criar'));
create policy clientes_update on public.clientes for update to authenticated
  using (organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','editar'))
  with check (organizacao_id = private.org_atual());
create policy clientes_delete on public.clientes for delete to authenticated using (
  organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','excluir'));

-- Unidades
create policy unidades_select on public.cliente_unidades for select to authenticated using (
  (organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','ver'))
  or cliente_id = private.cliente_atual()
);
create policy unidades_insert on public.cliente_unidades for insert to authenticated with check (
  organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','criar')
  and exists (select 1 from public.clientes c where c.id = cliente_id and c.organizacao_id = private.org_atual()));
create policy unidades_update on public.cliente_unidades for update to authenticated
  using (organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','editar'))
  with check (organizacao_id = private.org_atual());
create policy unidades_delete on public.cliente_unidades for delete to authenticated using (
  organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('clientes','excluir'));

-- Funções e escalas-modelo
create policy funcoes_select on public.funcoes for select to authenticated using (
  organizacao_id = private.org_atual() and private.eh_interno());
create policy funcoes_write on public.funcoes for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('cadastros','editar'))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('cadastros','editar'));

create policy escalas_modelo_select on public.escalas_modelo for select to authenticated using (
  organizacao_id = private.org_atual());
create policy escalas_modelo_write on public.escalas_modelo for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('cadastros','editar'))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('cadastros','editar'));

-- Contratos
create policy contratos_select on public.contratos for select to authenticated
  using (private.pode_ver_contrato(id));
create policy contratos_insert on public.contratos for insert to authenticated with check (
  organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('contratos','criar')
  and exists (select 1 from public.clientes c where c.id = cliente_id and c.organizacao_id = private.org_atual()));
create policy contratos_update on public.contratos for update to authenticated
  using (organizacao_id = private.org_atual() and private.eh_interno() and private.tem_permissao('contratos','editar')
         and (private.tem_permissao('contratos','ver_todos') or supervisor_id = auth.uid()))
  with check (organizacao_id = private.org_atual());
create policy contratos_delete on public.contratos for delete to authenticated using (
  organizacao_id = private.org_atual() and private.tem_permissao('contratos','excluir') and status = 'rascunho');

-- Postos, aditivos e indicadores seguem a visibilidade do contrato
create policy postos_select on public.contrato_postos for select to authenticated
  using (private.pode_ver_contrato(contrato_id));
create policy postos_write on public.contrato_postos for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('contratos','editar') and private.pode_ver_contrato(contrato_id))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('contratos','editar') and private.pode_ver_contrato(contrato_id));

create policy aditivos_select on public.contrato_aditivos for select to authenticated
  using (private.eh_interno() and private.pode_ver_contrato(contrato_id));
create policy aditivos_write on public.contrato_aditivos for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('contratos','editar') and private.pode_ver_contrato(contrato_id))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('contratos','editar') and private.pode_ver_contrato(contrato_id));

create policy indicadores_select on public.contrato_indicadores for select to authenticated
  using (private.pode_ver_contrato(contrato_id));
create policy indicadores_write on public.contrato_indicadores for all to authenticated
  using (organizacao_id = private.org_atual() and private.tem_permissao('contratos','editar') and private.pode_ver_contrato(contrato_id))
  with check (organizacao_id = private.org_atual() and private.tem_permissao('contratos','editar') and private.pode_ver_contrato(contrato_id));

-- ---------------------------------------------------------------------
-- Visão resumida de contratos (usada em listas e no dashboard).
-- security_invoker = true: respeita as políticas RLS de quem consulta.
-- ---------------------------------------------------------------------
create view public.vw_contratos_resumo with (security_invoker = true) as
select
  c.id, c.organizacao_id, c.numero, c.status, c.data_inicio, c.data_fim,
  c.valor_mensal, c.cliente_id, c.supervisor_id,
  cl.razao_social  as cliente_razao_social,
  coalesce(cl.nome_fantasia, cl.razao_social) as cliente_nome,
  s.nome           as supervisor_nome,
  coalesce(p.postos_contratados, 0) as postos_contratados,
  coalesce(p.valor_postos, 0)       as valor_postos,
  coalesce(p.unidades, 0)           as unidades
from public.contratos c
join public.clientes cl on cl.id = c.cliente_id
left join public.usuarios s on s.id = c.supervisor_id
left join lateral (
  select sum(cp.quantidade)::int as postos_contratados,
         sum(cp.valor_total)     as valor_postos,
         count(distinct cp.unidade_id)::int as unidades
  from public.contrato_postos cp
  where cp.contrato_id = c.id and cp.ativo
) p on true;

-- Visitantes anônimos não acessam nada (a página pública de carreiras
-- ganhará permissões específicas na Etapa 4)
revoke all on all tables in schema public from anon;

-- ---------------------------------------------------------------------
-- Escalas-modelo padrão para toda organização
-- ---------------------------------------------------------------------
create or replace function private.criar_escalas_padrao(p_org uuid)
returns void language sql security definer set search_path = '' as $$
  insert into public.escalas_modelo
    (organizacao_id, nome, tipo, dias_trabalho, dias_folga, horas_jornada, carga_semanal, noturno, descricao)
  values
    (p_org, '5x2 (44h)',          '5x2',   5, 2,  8.80, 44, false, 'Segunda a sexta, 8h48 por dia'),
    (p_org, '6x1 (44h)',          '6x1',   6, 1,  7.33, 44, false, 'Seis dias de trabalho e um de folga, 7h20 por dia'),
    (p_org, '12x36 diurno',       '12x36', 1, 1, 12.00, 42, false, 'Plantões de 12h alternados com 36h de descanso'),
    (p_org, '12x36 noturno',      '12x36', 1, 1, 12.00, 42, true,  'Plantões noturnos de 12h alternados com 36h de descanso')
  on conflict (organizacao_id, nome) do nothing
$$;

create or replace function private.on_organizacao_cadastros()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform private.criar_escalas_padrao(new.id);
  return new;
end $$;
create trigger trg_organizacao_cadastros after insert on public.organizacoes
  for each row execute function private.on_organizacao_cadastros();

select private.criar_escalas_padrao(id) from public.organizacoes;
