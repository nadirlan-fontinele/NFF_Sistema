-- NFF Gestão · Migração 005 · search_path fixo nas funções auxiliares (lint de segurança)
alter function private.set_updated_at() set search_path = '';
alter function private.auditar(regclass) set search_path = '';
alter function private.proteger_perfil_sistema() set search_path = '';
