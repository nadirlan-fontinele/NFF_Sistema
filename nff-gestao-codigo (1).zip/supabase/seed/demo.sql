-- =====================================================================
-- DADOS DE DEMONSTRAÇÃO (fictícios) — organização separada, marcada
-- como demonstracao = true. NÃO usar em produção.
-- A senha dos usuários de demonstração é passada em :'senha_demo'
-- (ou substitua __SENHA_DEMO__ antes de executar).
-- =====================================================================
do $$
declare
  v_org uuid;
  v_senha text := '__SENHA_DEMO__';
  v_admin uuid := gen_random_uuid();
  v_sup uuid := gen_random_uuid();
  v_cli_user uuid := gen_random_uuid();
  c1 uuid; c2 uuid; c3 uuid; c4 uuid;
  u1 uuid; u2 uuid; u3 uuid; u4 uuid; u5 uuid; u6 uuid;
  f_asg uuid; f_rec uuid; f_coz uuid; f_aux_coz uuid; f_por uuid; f_jar uuid; f_man uuid; f_sup uuid;
  e52 uuid; e61 uuid; e1236d uuid; e1236n uuid;
  k1 uuid; k2 uuid; k3 uuid; k4 uuid; k5 uuid;
  r record;
begin
  if exists (select 1 from public.organizacoes where demonstracao) then
    raise notice 'Organização de demonstração já existe; nada a fazer.';
    return;
  end if;

  insert into public.organizacoes (nome, demonstracao) values ('NFF Gestão (Demonstração)', true) returning id into v_org;

  select id into e52 from public.escalas_modelo where organizacao_id = v_org and tipo = '5x2';
  select id into e61 from public.escalas_modelo where organizacao_id = v_org and tipo = '6x1';
  select id into e1236d from public.escalas_modelo where organizacao_id = v_org and nome = '12x36 diurno';
  select id into e1236n from public.escalas_modelo where organizacao_id = v_org and nome = '12x36 noturno';

  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Auxiliar de serviços gerais', '5143-20', 1650.00) returning id into f_asg;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Recepcionista', '4221-05', 1850.00) returning id into f_rec;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Cozinheiro', '5132-05', 2200.00) returning id into f_coz;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Auxiliar de cozinha', '5135-05', 1700.00) returning id into f_aux_coz;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Porteiro', '5174-10', 1900.00) returning id into f_por;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Jardineiro', '6220-10', 1800.00) returning id into f_jar;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Oficial de manutenção predial', '5143-10', 2400.00) returning id into f_man;
  insert into public.funcoes (organizacao_id, nome, cbo, salario_base) values
    (v_org, 'Supervisor de limpeza', '4101-05', 3200.00) returning id into f_sup;

  -- Usuários de demonstração (app_metadata vincula à organização)
  for r in select * from (values
      (v_admin, 'admin.demo@nffgestao.dev', 'Administrador Demonstração', 'interno', null::text),
      (v_sup, 'supervisor.demo@nffgestao.dev', 'Carla Supervisora (demo)', 'interno', null)
    ) t(id, email, nome, tipo, cliente)
  loop
    insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data, created_at, updated_at, confirmation_token, email_change, email_change_token_new, recovery_token)
    values ('00000000-0000-0000-0000-000000000000', r.id, 'authenticated', 'authenticated', r.email,
      extensions.crypt(v_senha, extensions.gen_salt('bf')), now(),
      jsonb_build_object('provider','email','providers',jsonb_build_array('email'),'organizacao_id',v_org,'tipo',r.tipo,'nome',r.nome),
      jsonb_build_object('nome', r.nome), now(), now(), '', '', '', '');
    insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
    values (gen_random_uuid(), r.id, r.id::text, jsonb_build_object('sub', r.id::text, 'email', r.email, 'email_verified', true), 'email', now(), now(), now());
  end loop;

  insert into public.usuario_perfis (usuario_id, perfil_id)
  select v_admin, id from public.perfis where organizacao_id = v_org and codigo = 'admin';
  insert into public.usuario_perfis (usuario_id, perfil_id)
  select v_sup, id from public.perfis where organizacao_id = v_org and codigo = 'supervisor';

  -- Clientes fictícios (CNPJs fictícios com dígitos válidos, faixa 90.000.00x)
  insert into public.clientes (organizacao_id, razao_social, nome_fantasia, documento, email, telefone, contato_nome, cidade, uf, bairro, status)
  values (v_org, 'Condomínio Empresarial Atlântico Ltda (DEMO)', 'Edifício Atlântico', '90000001000129', 'adm@atlantico.demo', '(85) 3000-0001', 'Marcos Lima', 'Fortaleza', 'CE', 'Aldeota', 'ativo')
  returning id into c1;
  insert into public.clientes (organizacao_id, razao_social, nome_fantasia, documento, email, telefone, contato_nome, cidade, uf, bairro, status)
  values (v_org, 'Hospital Vida Plena S.A. (DEMO)', 'Hospital Vida Plena', '90000002000173', 'compras@vidaplena.demo', '(85) 3000-0002', 'Dra. Renata Sousa', 'Fortaleza', 'CE', 'Meireles', 'ativo')
  returning id into c2;
  insert into public.clientes (organizacao_id, razao_social, nome_fantasia, documento, email, contato_nome, cidade, uf, bairro, status)
  values (v_org, 'Escola Saber Mais Ltda (DEMO)', 'Colégio Saber Mais', '90000003000118', 'diretoria@sabermais.demo', 'Paulo Andrade', 'Caucaia', 'CE', 'Centro', 'ativo')
  returning id into c3;
  insert into public.clientes (organizacao_id, razao_social, nome_fantasia, documento, contato_nome, cidade, uf, status)
  values (v_org, 'Indústria Nordeste Têxtil Ltda (DEMO)', 'Nordeste Têxtil', '90000004000162', 'Ana Beatriz', 'Maracanaú', 'CE', 'prospecto')
  returning id into c4;

  insert into public.cliente_unidades (organizacao_id, cliente_id, nome, bairro, cidade, uf, responsavel_nome) values
    (v_org, c1, 'Torre A', 'Aldeota', 'Fortaleza', 'CE', 'Marcos Lima') returning id into u1;
  insert into public.cliente_unidades (organizacao_id, cliente_id, nome, bairro, cidade, uf, responsavel_nome) values
    (v_org, c1, 'Torre B', 'Aldeota', 'Fortaleza', 'CE', 'Marcos Lima') returning id into u2;
  insert into public.cliente_unidades (organizacao_id, cliente_id, nome, bairro, cidade, uf, responsavel_nome) values
    (v_org, c2, 'Unidade Meireles', 'Meireles', 'Fortaleza', 'CE', 'Renata Sousa') returning id into u3;
  insert into public.cliente_unidades (organizacao_id, cliente_id, nome, bairro, cidade, uf, responsavel_nome) values
    (v_org, c2, 'Ambulatório Messejana', 'Messejana', 'Fortaleza', 'CE', 'João Pedro') returning id into u4;
  insert into public.cliente_unidades (organizacao_id, cliente_id, nome, bairro, cidade, uf, responsavel_nome) values
    (v_org, c3, 'Sede', 'Centro', 'Caucaia', 'CE', 'Paulo Andrade') returning id into u5;
  insert into public.cliente_unidades (organizacao_id, cliente_id, nome, bairro, cidade, uf) values
    (v_org, c4, 'Fábrica', 'Distrito Industrial', 'Maracanaú', 'CE') returning id into u6;

  -- Usuário do cliente (portal) — Edifício Atlântico
  insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at, confirmation_token, email_change, email_change_token_new, recovery_token)
  values ('00000000-0000-0000-0000-000000000000', v_cli_user, 'authenticated', 'authenticated', 'cliente.demo@nffgestao.dev',
    extensions.crypt(v_senha, extensions.gen_salt('bf')), now(),
    jsonb_build_object('provider','email','providers',jsonb_build_array('email'),'organizacao_id',v_org,'tipo','cliente','cliente_id',c1,'nome','Marcos (cliente demo)'),
    '{}'::jsonb, now(), now(), '', '', '', '');
  insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
  values (gen_random_uuid(), v_cli_user, v_cli_user::text, jsonb_build_object('sub', v_cli_user::text, 'email', 'cliente.demo@nffgestao.dev', 'email_verified', true), 'email', now(), now(), now());
  insert into public.usuario_perfis (usuario_id, perfil_id)
  select v_cli_user, id from public.perfis where organizacao_id = v_org and codigo = 'cliente';

  -- Contratos
  insert into public.contratos (organizacao_id, cliente_id, numero, objeto, data_inicio, data_fim, valor_mensal, indice_reajuste, data_base_reajuste,
    supervisor_id, sla_cobertura_pct, prazo_substituicao_horas, regras_substituicao)
  values (v_org, c1, 'NFF-2026-001', 'Limpeza, conservação e recepção das torres A e B', '2026-02-01', '2027-01-31', 0, 'CCT', '2027-01-01',
    v_sup, 98, 2, 'Substituição em até 2 horas para recepção; até o turno seguinte para limpeza.') returning id into k1;
  insert into public.contratos (organizacao_id, cliente_id, numero, objeto, data_inicio, data_fim, valor_mensal, indice_reajuste, supervisor_id, sla_cobertura_pct, prazo_substituicao_horas)
  values (v_org, c2, 'NFF-2026-002', 'Higienização hospitalar e serviços de cozinha', '2026-03-01', '2028-02-29', 0, 'CCT', null, 99, 1) returning id into k2;
  insert into public.contratos (organizacao_id, cliente_id, numero, objeto, data_inicio, data_fim, valor_mensal, indice_reajuste, supervisor_id, sla_cobertura_pct, prazo_substituicao_horas)
  values (v_org, c3, 'NFF-2026-003', 'Portaria, jardinagem e manutenção predial', '2025-12-15', '2026-12-14', 0, 'IPCA', v_sup, 97, 4) returning id into k3;
  insert into public.contratos (organizacao_id, cliente_id, numero, objeto, data_inicio, valor_mensal, sla_cobertura_pct)
  values (v_org, c2, 'NFF-2026-004', 'Recepção do ambulatório (em negociação)', '2027-01-01', 0, 98) returning id into k4;

  insert into public.contrato_postos (organizacao_id, contrato_id, unidade_id, funcao_id, escala_modelo_id, descricao, quantidade, horario_entrada, horario_saida, intervalo_minutos, valor_unitario) values
    (v_org, k1, u1, f_asg, e52, 'Limpeza de áreas comuns', 4, '06:00', '15:48', 60, 4380.00),
    (v_org, k1, u2, f_asg, e52, 'Limpeza de áreas comuns', 3, '06:00', '15:48', 60, 4380.00),
    (v_org, k1, u1, f_rec, e1236d, 'Recepção do térreo', 2, '07:00', '19:00', 60, 5650.00),
    (v_org, k1, u1, f_sup, e52, 'Supervisão local', 1, '08:00', '17:48', 60, 7900.00),
    (v_org, k2, u3, f_asg, e1236d, 'Higienização de enfermarias (dia)', 6, '07:00', '19:00', 60, 4920.00),
    (v_org, k2, u3, f_asg, e1236n, 'Higienização de enfermarias (noite)', 6, '19:00', '07:00', 60, 5480.00),
    (v_org, k2, u3, f_coz, e61, 'Cozinha do refeitório', 2, '05:00', '13:20', 60, 6350.00),
    (v_org, k2, u3, f_aux_coz, e61, 'Apoio à cozinha', 3, '05:00', '13:20', 60, 4560.00),
    (v_org, k2, u4, f_asg, e52, 'Limpeza do ambulatório', 2, '07:00', '16:48', 60, 4380.00),
    (v_org, k3, u5, f_por, e1236d, 'Portaria diurna', 2, '06:00', '18:00', 60, 5320.00),
    (v_org, k3, u5, f_por, e1236n, 'Portaria noturna', 2, '18:00', '06:00', 60, 5890.00),
    (v_org, k3, u5, f_jar, e52, 'Jardinagem', 1, '07:00', '16:48', 60, 4650.00),
    (v_org, k3, u5, f_man, e52, 'Manutenção predial', 1, '07:00', '16:48', 60, 6400.00),
    (v_org, k4, u4, f_rec, e52, 'Recepção do ambulatório', 2, '07:00', '16:48', 60, 4850.00);

  -- Valor mensal = soma dos postos; contratos 1 a 3 ativos, 4 em rascunho
  update public.contratos c set valor_mensal = s.total
  from (select contrato_id, sum(valor_total) total from public.contrato_postos group by contrato_id) s
  where s.contrato_id = c.id and c.organizacao_id = v_org;
  update public.contratos set status = 'ativo' where id in (k1, k2, k3);

  -- Exemplo de aditivo de reajuste no contrato 3
  insert into public.contrato_aditivos (organizacao_id, contrato_id, numero, tipo, data_assinatura, vigencia_inicio, valor_mensal_novo, percentual, descricao)
  select v_org, k3, '1', 'reajuste', '2026-06-10', '2026-06-15', round(valor_mensal * 1.045, 2), 4.5, 'Reajuste anual pelo IPCA (demonstração)'
  from public.contratos where id = k3;

  raise notice 'Demonstração criada: organização %', v_org;
end $$;
