-- Testes das regras de negócio de contratos (rodar após as migrações)
\set ON_ERROR_STOP 1
begin;
insert into public.organizacoes (id, nome) values ('00000000-0000-0000-0000-0000000000c1', 'Org R');
insert into public.clientes (id, organizacao_id, razao_social, documento) values
  ('c1000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000c1', 'Cliente R', '11222333000181');
insert into public.cliente_unidades (id, organizacao_id, cliente_id, nome) values
  ('d1000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000c1', 'c1000000-0000-0000-0000-000000000001', 'Sede');
insert into public.funcoes (id, organizacao_id, nome) values ('f1000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000c1', 'Recepcionista');
insert into public.contratos (id, organizacao_id, cliente_id, numero, data_inicio, valor_mensal) values
  ('e1000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000c1', 'c1000000-0000-0000-0000-000000000001', 'NFF-2026-007', '2026-01-01', 1000);

-- 1) Não ativa sem posto
do $$ begin
  begin
    update public.contratos set status = 'ativo' where id = 'e1000000-0000-0000-0000-000000000001';
    raise exception 'FALHA: ativou contrato sem posto';
  exception when check_violation then raise notice 'ok: não ativa sem posto';
  end;
end $$;

insert into public.contrato_postos (organizacao_id, contrato_id, unidade_id, funcao_id, escala_modelo_id, quantidade, horario_entrada, horario_saida, valor_unitario)
select '00000000-0000-0000-0000-0000000000c1', 'e1000000-0000-0000-0000-000000000001', 'd1000000-0000-0000-0000-000000000001',
       'f1000000-0000-0000-0000-000000000001', id, 2, '08:00', '17:48', 4000
from public.escalas_modelo where organizacao_id = '00000000-0000-0000-0000-0000000000c1' and tipo = '5x2';
update public.contratos set status = 'ativo' where id = 'e1000000-0000-0000-0000-000000000001';
do $$ begin
  if (select status from public.contratos where id = 'e1000000-0000-0000-0000-000000000001') <> 'ativo' then raise exception 'FALHA: não ativou'; end if;
  if (select valor_total from public.contrato_postos where contrato_id = 'e1000000-0000-0000-0000-000000000001') <> 8000 then raise exception 'FALHA: valor_total'; end if;
  raise notice 'ok: ativa com posto e calcula valor total do posto';
end $$;

-- 2) Aditivo de reajuste atualiza valor e guarda o anterior
insert into public.contrato_aditivos (organizacao_id, contrato_id, numero, tipo, vigencia_inicio, valor_mensal_novo, percentual)
values ('00000000-0000-0000-0000-0000000000c1', 'e1000000-0000-0000-0000-000000000001', '1', 'reajuste', current_date, 1100, 10);
do $$ begin
  if (select valor_mensal from public.contratos where id = 'e1000000-0000-0000-0000-000000000001') <> 1100 then raise exception 'FALHA: reajuste não aplicado'; end if;
  if (select valor_mensal_anterior from public.contrato_aditivos where numero = '1' and contrato_id = 'e1000000-0000-0000-0000-000000000001') <> 1000 then raise exception 'FALHA: valor anterior'; end if;
  raise notice 'ok: aditivo de reajuste aplicado com histórico';
end $$;

-- 3) Aditivo de prazo atualiza data_fim
insert into public.contrato_aditivos (organizacao_id, contrato_id, numero, tipo, vigencia_inicio, nova_data_fim)
values ('00000000-0000-0000-0000-0000000000c1', 'e1000000-0000-0000-0000-000000000001', '2', 'prazo', current_date, '2027-12-31');
do $$ begin
  if (select data_fim from public.contratos where id = 'e1000000-0000-0000-0000-000000000001') <> '2027-12-31' then raise exception 'FALHA: prazo'; end if;
  raise notice 'ok: aditivo de prazo aplicado';
end $$;

-- 4) Encerrado não reabre
update public.contratos set status = 'encerrado' where id = 'e1000000-0000-0000-0000-000000000001';
do $$ begin
  begin
    update public.contratos set status = 'ativo' where id = 'e1000000-0000-0000-0000-000000000001';
    raise exception 'FALHA: reabriu encerrado';
  exception when check_violation then raise notice 'ok: encerrado não reabre';
  end;
end $$;

-- 5) Período inválido é recusado
do $$ begin
  begin
    insert into public.contratos (organizacao_id, cliente_id, numero, data_inicio, data_fim)
    values ('00000000-0000-0000-0000-0000000000c1', 'c1000000-0000-0000-0000-000000000001', 'X', '2026-05-01', '2026-01-01');
    raise exception 'FALHA: período inválido aceito';
  exception when check_violation then raise notice 'ok: período inválido recusado';
  end;
end $$;
rollback;
\echo 'TODOS OS TESTES DE REGRAS PASSARAM'
