-- =====================================================================
-- Testes de segurança (RLS) — rodar num banco descartável.
-- Falha com exceção se alguma regra de acesso estiver errada.
-- =====================================================================
\set ON_ERROR_STOP 1
begin;

-- ---------- Preparação (como superusuário) ----------
insert into public.organizacoes (id, nome) values
  ('00000000-0000-0000-0000-00000000000a', 'Org A'),
  ('00000000-0000-0000-0000-00000000000b', 'Org B');

insert into public.clientes (id, organizacao_id, razao_social, documento) values
  ('c0000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-00000000000a', 'Cliente X', '11111111000111'),
  ('c0000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-00000000000a', 'Cliente Y', '22222222000122'),
  ('c0000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-00000000000b', 'Cliente Z', '33333333000133');

insert into auth.users (id, email, raw_app_meta_data) values
  ('a0000000-0000-0000-0000-000000000001', 'admin@a', '{"organizacao_id":"00000000-0000-0000-0000-00000000000a","nome":"Admin A"}'),
  ('a0000000-0000-0000-0000-000000000002', 'sup@a',   '{"organizacao_id":"00000000-0000-0000-0000-00000000000a","nome":"Supervisor A"}'),
  ('a0000000-0000-0000-0000-000000000003', 'vend@a',  '{"organizacao_id":"00000000-0000-0000-0000-00000000000a","nome":"Vendedor A"}'),
  ('a0000000-0000-0000-0000-000000000004', 'cli@x',   '{"organizacao_id":"00000000-0000-0000-0000-00000000000a","nome":"Cliente X User","tipo":"cliente","cliente_id":"c0000000-0000-0000-0000-000000000001"}'),
  ('b0000000-0000-0000-0000-000000000001', 'admin@b', '{"organizacao_id":"00000000-0000-0000-0000-00000000000b","nome":"Admin B"}'),
  ('a0000000-0000-0000-0000-000000000005', 'semperfil@a', '{"organizacao_id":"00000000-0000-0000-0000-00000000000a","nome":"Sem perfil"}');

insert into public.usuario_perfis (usuario_id, perfil_id)
select u, p.id from (values
  ('a0000000-0000-0000-0000-000000000001'::uuid, '00000000-0000-0000-0000-00000000000a'::uuid, 'admin'),
  ('a0000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-00000000000a', 'supervisor'),
  ('a0000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-00000000000a', 'vendedor'),
  ('a0000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-00000000000a', 'cliente'),
  ('b0000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-00000000000b', 'admin')
) v(u, o, c) join public.perfis p on p.organizacao_id = v.o and p.codigo = v.c;

insert into public.cliente_unidades (id, organizacao_id, cliente_id, nome) values
  ('d0000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-00000000000a', 'c0000000-0000-0000-0000-000000000001', 'Sede X'),
  ('d0000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-00000000000a', 'c0000000-0000-0000-0000-000000000002', 'Sede Y');

insert into public.funcoes (id, organizacao_id, nome) values
  ('f0000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-00000000000a', 'Auxiliar de limpeza');

insert into public.contratos (id, organizacao_id, cliente_id, numero, data_inicio, valor_mensal, supervisor_id, status) values
  ('e0000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-00000000000a', 'c0000000-0000-0000-0000-000000000001', 'A-001', '2026-01-01', 10000, 'a0000000-0000-0000-0000-000000000002', 'ativo'),
  ('e0000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-00000000000a', 'c0000000-0000-0000-0000-000000000002', 'A-002', '2026-01-01', 20000, null, 'ativo'),
  ('e0000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-00000000000a', 'c0000000-0000-0000-0000-000000000001', 'A-003', '2026-01-01', 5000, null, 'rascunho');

insert into public.contrato_postos (organizacao_id, contrato_id, unidade_id, funcao_id, escala_modelo_id, quantidade, horario_entrada, horario_saida, valor_unitario)
select '00000000-0000-0000-0000-00000000000a', 'e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001',
       'f0000000-0000-0000-0000-000000000001', id, 3, '07:00', '16:48', 3500
from public.escalas_modelo where organizacao_id = '00000000-0000-0000-0000-00000000000a' and tipo = '5x2';

-- Regra de negócio: unidade de outro cliente é recusada
do $$ begin
  begin
    insert into public.contrato_postos (organizacao_id, contrato_id, unidade_id, funcao_id, escala_modelo_id, quantidade, horario_entrada, horario_saida)
    select '00000000-0000-0000-0000-00000000000a', 'e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000002',
           'f0000000-0000-0000-0000-000000000001', id, 1, '07:00', '16:00'
    from public.escalas_modelo where organizacao_id = '00000000-0000-0000-0000-00000000000a' limit 1;
    raise exception 'FALHA: posto com unidade de outro cliente foi aceito';
  exception when check_violation then null;
  end;
end $$;

-- ---------- Helper de asserção ----------
create or replace function pg_temp.assert_eq(p_desc text, p_got bigint, p_exp bigint) returns void language plpgsql as $$
begin
  if p_got is distinct from p_exp then
    raise exception 'FALHA: % (obtido %, esperado %)', p_desc, p_got, p_exp;
  end if;
  raise notice 'ok: %', p_desc;
end $$;

set local role authenticated;

-- ---------- Admin da Org A ----------
set local request.jwt.claim.sub = 'a0000000-0000-0000-0000-000000000001';
select pg_temp.assert_eq('admin A vê 2 clientes da própria org', (select count(*) from public.clientes), 2);
select pg_temp.assert_eq('admin A vê 3 contratos', (select count(*) from public.contratos), 3);
select pg_temp.assert_eq('admin A vê 4 escalas-modelo da org', (select count(*) from public.escalas_modelo), 4);
select pg_temp.assert_eq('admin A vê 13 perfis', (select count(*) from public.perfis), 13);
select pg_temp.assert_eq('admin A vê o resumo com 3 postos no contrato A-001',
  (select postos_contratados from public.vw_contratos_resumo where numero = 'A-001'), 3);
insert into public.clientes (razao_social, documento) values ('Novo cliente', '44444444000144');
select pg_temp.assert_eq('cliente criado recebe a org do usuário',
  (select count(*) from public.clientes where documento = '44444444000144' and organizacao_id = '00000000-0000-0000-0000-00000000000a'), 1);
select pg_temp.assert_eq('auditoria registrou a criação',
  (select count(*) from public.auditoria_log where tabela = 'clientes' and acao = 'INSERT' and usuario_id = 'a0000000-0000-0000-0000-000000000001'), 1);

-- ---------- Admin da Org B não vê a Org A ----------
set local request.jwt.claim.sub = 'b0000000-0000-0000-0000-000000000001';
select pg_temp.assert_eq('admin B vê só 1 cliente', (select count(*) from public.clientes), 1);
select pg_temp.assert_eq('admin B não vê contratos da Org A', (select count(*) from public.contratos), 0);
select pg_temp.assert_eq('admin B não vê auditoria da Org A',
  (select count(*) from public.auditoria_log where organizacao_id = '00000000-0000-0000-0000-00000000000a'), 0);
do $$ begin
  begin
    insert into public.clientes (organizacao_id, razao_social, documento)
    values ('00000000-0000-0000-0000-00000000000a', 'Invasor', '55555555000155');
    raise exception 'FALHA: admin B inseriu cliente na Org A';
  exception when insufficient_privilege then null;
  end;
end $$;

-- ---------- Supervisor: só o contrato que supervisiona ----------
set local request.jwt.claim.sub = 'a0000000-0000-0000-0000-000000000002';
select pg_temp.assert_eq('supervisor vê só 1 contrato', (select count(*) from public.contratos), 1);
select pg_temp.assert_eq('supervisor vê os postos do seu contrato', (select count(*) from public.contrato_postos), 1);
do $$ declare n int; begin
  update public.contratos set objeto = 'x'; get diagnostics n = row_count;
  perform pg_temp.assert_eq('supervisor não consegue editar contrato', n, 0);
end $$;
select pg_temp.assert_eq('supervisor não vê auditoria', (select count(*) from public.auditoria_log), 0);

-- ---------- Vendedor: não vê contratos ----------
set local request.jwt.claim.sub = 'a0000000-0000-0000-0000-000000000003';
select pg_temp.assert_eq('vendedor não vê contratos', (select count(*) from public.contratos), 0);
select pg_temp.assert_eq('vendedor vê clientes', (select count(*) from public.clientes), 3);

-- ---------- Usuário do cliente X: portal ----------
set local request.jwt.claim.sub = 'a0000000-0000-0000-0000-000000000004';
select pg_temp.assert_eq('cliente X vê só o próprio cadastro', (select count(*) from public.clientes), 1);
select pg_temp.assert_eq('cliente X vê só contrato ativo próprio (não o rascunho)', (select count(*) from public.contratos), 1);
select pg_temp.assert_eq('cliente X vê só as próprias unidades', (select count(*) from public.cliente_unidades), 1);
select pg_temp.assert_eq('cliente X não vê aditivos', (select count(*) from public.contrato_aditivos), 0);
select pg_temp.assert_eq('cliente X não vê outros usuários', (select count(*) from public.usuarios), 1);
select pg_temp.assert_eq('cliente X não vê funções internas', (select count(*) from public.funcoes), 0);
do $$ begin
  begin
    insert into public.clientes (razao_social, documento) values ('Hack', '66666666000166');
    raise exception 'FALHA: cliente conseguiu criar cliente';
  exception when insufficient_privilege or not_null_violation then null;
  end;
end $$;

-- ---------- Usuário sem perfil: nada ----------
set local request.jwt.claim.sub = 'a0000000-0000-0000-0000-000000000005';
select pg_temp.assert_eq('sem perfil não vê clientes', (select count(*) from public.clientes), 0);
select pg_temp.assert_eq('sem perfil não vê contratos', (select count(*) from public.contratos), 0);
select pg_temp.assert_eq('sem perfil não ganha permissões', (select count(*) from public.minhas_permissoes()), 0);
do $$ begin
  begin
    insert into public.usuario_perfis (usuario_id, perfil_id)
    select 'a0000000-0000-0000-0000-000000000005', id from public.perfis where codigo = 'admin';
    raise exception 'FALHA: usuário sem perfil se promoveu a admin';
  exception when insufficient_privilege then null;
  end;
end $$;

-- ---------- Anônimo: nada ----------
reset request.jwt.claim.sub;
set local role anon;
do $$ begin
  begin
    perform count(*) from public.clientes;
    raise exception 'FALHA: anônimo leu clientes';
  exception when insufficient_privilege then null;
  end;
end $$;

rollback;
\echo 'TODOS OS TESTES DE RLS PASSARAM'
