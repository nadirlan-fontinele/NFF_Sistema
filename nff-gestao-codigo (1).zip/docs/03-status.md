# Situação das etapas

| Etapa | Situação |
|---|---|
| 1 · Arquitetura | Concluída (docs/01-arquitetura.md) |
| 2 · Fundação | Implementada; testes de banco e de validação passando; teste de ponta a ponta no navegador pendente (ver abaixo) |
| 3 a 10 | Não iniciadas |

## Etapa 2 — o que foi entregue

- Projeto Next.js 15 + TypeScript + Tailwind + componentes shadcn/ui; layout responsivo com menu lateral por módulo.
- Banco: 7 migrações (núcleo, permissões, clientes/contratos, vínculo seguro de usuário, search_path, regras de aditivo/status, privilégios da API).
- Autenticação: login, sair, recuperação e redefinição de senha, convite de usuários (requer chave de serviço).
- Perfis padrão (13) e matriz de permissões editável; usuários com atribuição de perfis.
- Cadastros: clientes, unidades, funções, escalas-modelo, contratos, postos, aditivos, mudança de situação.
- Dashboard inicial (contratos ativos, postos, clientes, receita mensal, receita por cliente, contratos por situação, vencimentos em 90 dias).
- Auditoria: tela de consulta e histórico no contrato.
- Portal do cliente: versão inicial (lista de contratos).

## Testado

- 25 testes de RLS + 6 de regras de contrato (PostgreSQL local, `npm run test:db`).
- Mesmas consultas da aplicação executadas no Supabase real, simulando admin, supervisor e cliente de demonstração.
- 13 testes de validação/formatação (Vitest), `tsc` e `next build` sem erros.

## Pendente

- Teste de ponta a ponta no navegador (o ambiente de nuvem atual não alcança *.supabase.co).
- Convite de usuários depende de `SUPABASE_SERVICE_ROLE_KEY` no servidor.
- Desligar o cadastro público (sign-up) no painel do Supabase (Authentication → Sign In / Providers).
