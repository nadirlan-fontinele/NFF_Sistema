# Regras de negócio e decisões de arquitetura

## Decisões (ADR resumido)

| # | Decisão | Motivo |
|---|---|---|
| 1 | Monólito modular em Next.js + Supabase | Integração entre módulos com chaves estrangeiras reais, sem custo de microserviços. |
| 2 | Segurança em duas camadas: RLS no banco + checagem de permissão nas Server Actions | Ocultar menu não é segurança; mesmo uma chamada direta à API respeita o perfil. |
| 3 | `organizacao_id` em toda tabela de negócio | Pronto para multiempresa e para isolar a organização de demonstração. |
| 4 | Vínculo de novo usuário via `app_metadata` (não `user_metadata`) | `user_metadata` pode ser escrito pelo próprio usuário no cadastro. |
| 5 | Privilégios de tabela concedidos explicitamente ao papel `authenticated` | Projetos Supabase recentes não concedem acesso automático às tabelas novas. |
| 6 | Auditoria por trigger genérico (`private.registrar_auditoria`) | Toda inclusão/alteração/exclusão nas tabelas de negócio é registrada sem depender do código da aplicação. |
| 7 | Funções de segurança no schema `private` | Não ficam expostas pela API REST. |
| 8 | Exclusão lógica (status/ativo) preferida à exclusão física | Preserva histórico; contratos só podem ser excluídos em rascunho. |
| 9 | Dados de demonstração em organização separada (`demonstracao = true`) | Separação clara entre dados fictícios e reais. |

## Perfis e escopo

- Permissões são pares `modulo.acao` (tabela `permissoes`) atribuídas a perfis (`perfil_permissoes`).
- O usuário recebe a soma das permissões de seus perfis (`usuario_perfis`).
- O perfil **Administrador geral** sempre tem todas as permissões e não pode ser editado na matriz.
- **Supervisor**: com `contratos.ver` mas sem `contratos.ver_todos`, vê apenas contratos em que é `supervisor_id`.
- **Cliente** (`tipo = 'cliente'`): vê apenas o próprio cadastro, unidades e contratos que não estão em rascunho; não vê aditivos, funções internas nem outros usuários.
- `contratos.ver_valores` controla a exibição e a edição de valores na interface. Limitação conhecida: o RLS libera a linha inteira do contrato; na Etapa 8 o portal passará a usar views sem colunas financeiras internas.

## Contratos

- Um contrato nasce em **rascunho**. Só pode ser **ativado** se tiver ao menos um posto ativo (trigger no banco).
- Transições: rascunho → ativo; ativo → suspenso/encerrado; suspenso → ativo/encerrado. Encerrado não reabre.
- A unidade de um posto precisa pertencer ao cliente do contrato (trigger no banco).
- `valor_total` do posto = quantidade × valor unitário (coluna calculada).
- O valor mensal do contrato é informado separadamente e pode diferir da soma dos postos (materiais, ajustes); a tela destaca a diferença.
- **Aditivos**: ao registrar reajuste, acréscimo, supressão ou repactuação com vigência até hoje, o valor mensal do contrato é atualizado e o valor anterior fica gravado no aditivo. Aditivo de prazo atualiza a data de término. Aditivos com vigência futura serão aplicados por rotina agendada (Etapa 6).
- Número sugerido automaticamente no formato `NFF-AAAA-NNN` (editável).

## Clientes

- CNPJ/CPF validados pelos dígitos verificadores e armazenados só com dígitos; únicos por organização.
- Cliente com contratos não pode ser excluído; deve ser inativado.

## Escalas-modelo padrão

| Escala | Ciclo | Jornada | Carga semanal |
|---|---|---|---|
| 5x2 (44h) | 5 trabalho / 2 folga | 8,8 h | 44 h |
| 6x1 (44h) | 6 trabalho / 1 folga | 7,33 h | 44 h |
| 12x36 diurno/noturno | 1 trabalho / 1 folga | 12 h | 42 h (média) |
