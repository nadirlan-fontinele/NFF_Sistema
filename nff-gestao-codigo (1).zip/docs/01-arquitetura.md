# NFF Gestão — Etapa 1: Arquitetura e Planejamento

Versão 1.0 · 20/11/2026

## 1. Resumo das decisões

| Tema | Decisão | Por quê |
|---|---|---|
| Aplicação | Next.js 15 (App Router) + React 19 + TypeScript | Front e back no mesmo projeto, Server Components e Server Actions reduzem API boilerplate; deploy simples na Vercel. |
| Interface | Tailwind CSS 4 + componentes no padrão shadcn/ui (Radix) + lucide-react | Componentes acessíveis e editáveis no próprio código, sem dependência de biblioteca fechada. |
| Banco | PostgreSQL no Supabase | Postgres completo (RLS, triggers, views, funções), Auth e Storage integrados. |
| Segurança de dados | Row Level Security (RLS) em todas as tabelas + checagem de permissão no servidor | Cumpre o requisito de "controle no back-end e no banco, não só ocultar menus". |
| Autenticação | Supabase Auth (e-mail/senha; magic link para clientes; MFA para perfis administrativos) | Nativo, integra com RLS via `auth.uid()`. |
| Arquivos | Supabase Storage, buckets privados, URLs assinadas de curta duração | Documentos pessoais e atestados nunca ficam públicos. |
| Validação | Zod (mesmo schema no formulário e no servidor) | Validação única e tipada. |
| Gráficos | Recharts | Pedido do escopo; leve e suficiente para dashboards. |
| Relatórios | PDF com `@react-pdf/renderer`, Excel com `exceljs` | Gerados no servidor, sem serviço pago. |
| E-mail | Resend (ou SMTP próprio) | Relatórios automáticos e notificações. Requer credencial. |
| Jobs e automações | `pg_cron` + Supabase Edge Functions para rotinas internas; n8n opcional para integrações externas | Rotinas críticas (alertas de posto descoberto, relatórios agendados) ficam dentro do sistema, versionadas e testáveis. O n8n entra onde há muita integração de terceiros. |
| IA | API do Claude (Anthropic), chamada só no servidor | Chaves nunca vão ao navegador. O assistente gerencial usa *ferramentas* (consultas pré-definidas e com permissão), não SQL livre, para não inventar números. |
| Hospedagem | Vercel (app) + Supabase (dados) | Escala automática; produção em região São Paulo (sa-east-1). |
| Testes | Vitest (regras de negócio), testes SQL de RLS, Playwright (fluxos E2E) | Permissões e regras de cálculo precisam de teste automatizado. |

**Estilo arquitetural:** monólito modular. Um único app Next.js, dividido em módulos de domínio (`src/modules/<modulo>`), cada um com seus schemas, serviços, ações de servidor e componentes. O banco é único, organizado por prefixos/esquemas, com chaves estrangeiras reais entre módulos. Isso entrega a integração que o escopo exige (lead → contrato → faturamento) sem a complexidade de microserviços. Se um módulo crescer muito (ex.: integração Meta), ele pode virar um serviço separado depois.

## 2. Visão de camadas

```
Navegador (desktop / tablet / celular)
   │  HTTPS
   ▼
Next.js na Vercel
   ├─ Páginas (Server Components)  ── leem dados já filtrados por RLS
   ├─ Server Actions / Route Handlers ── validação Zod + checagem de permissão
   ├─ Webhooks (Meta, e-mail, ponto) ── assinatura verificada, fila de eventos
   └─ Serviços de IA (Claude) ── só no servidor, com ferramentas restritas
   │
   ▼
Supabase
   ├─ Auth (usuários internos, clientes, colaboradores, candidatos)
   ├─ Postgres: tabelas + RLS + triggers de auditoria + views de indicadores
   ├─ Storage: buckets privados (documentos, currículos, atestados)
   ├─ pg_cron + Edge Functions: alertas, relatórios agendados, vencimentos
   └─ Vault: segredos de integração
   │
   ▼
Integrações externas (dependem de credencial/aprovação)
   Meta Graph API (Instagram) · WhatsApp Cloud API · Resend · NFS-e · relógios de ponto
```

## 3. Multiempresa e segregação

- Toda tabela de negócio tem `organizacao_id`. Hoje existirá só a NFF Gestão, mas o sistema nasce pronto para atender mais de uma empresa (SaaS) sem refazer o banco.
- **Usuários internos** pertencem a uma organização e têm um ou mais perfis.
- **Usuários de cliente** são vinculados a um `cliente_id`. As políticas RLS só liberam contratos, unidades e indicadores daquele cliente, e o portal consome *views* que não contêm CPF, endereço, salário, dados médicos ou contato pessoal dos colaboradores.
- **Colaboradores** (futuro app) só veem os próprios dados.
- **Candidatos** usam a página pública de carreiras; só veem a própria candidatura.

## 4. Perfis e permissões

Modelo RBAC configurável: `permissoes (modulo, acao)` → `perfil_permissoes` → `usuario_perfis`. Ações padrão: `ver`, `criar`, `editar`, `excluir`, `aprovar`, `exportar`, e algumas especiais (`ver_sensivel`, `ver_salario`, `gerenciar_usuarios`).

A função SQL `tem_permissao(modulo, acao)` é usada tanto nas políticas RLS quanto no servidor. Além da permissão, há **escopo de linha**:

| Perfil | Escopo dos dados |
|---|---|
| Administrador geral | Tudo, inclusive usuários e perfis |
| Diretoria | Tudo (leitura), aprovações |
| Gerente financeiro / Analista financeiro | Financeiro completo / financeiro sem aprovação de pagamentos |
| Gerente de RH / Recrutador | RH completo, dados sensíveis / vagas, candidatos, sem dados médicos |
| Gerente comercial / Vendedor | CRM de todos / só as próprias oportunidades |
| Marketing | Marketing, leads gerados, sem financeiro |
| Gerente operacional | Todos os contratos, escalas e frequência |
| Supervisor de contrato | Só os contratos em que é supervisor |
| Cliente | Só os próprios contratos, via portal, sem dados pessoais |
| Colaborador | Só os próprios dados |

As permissões de cada perfil ficam numa tabela editável pela tela de administração (Etapa 2 entrega a estrutura e os perfis padrão; a tela de edição de matriz vem junto).

**Dados especialmente restritos:** atestados, CID, documentos pessoais e dados bancários ficam em tabelas separadas (`colaborador_dados_sensiveis`, `documentos` com classificação) e só são acessíveis com a permissão `ver_sensivel`. Todo acesso a esses dados é registrado no log.

## 5. Mapa de módulos e dependências

```
                ┌───────────── Administração (usuários, perfis, auditoria, parâmetros)
                │
Cadastros base: Clientes · Unidades · Funções/Cargos · Escalas-modelo · Fornecedores
                │
   ┌────────────┼──────────────┬───────────────┬──────────────┐
Comercial    Operacional       RH            Financeiro     Marketing
(CRM,        (contratos,      (vagas,        (receber,      (Instagram,
 propostas)   postos,          candidatos,    pagar, fluxo,  agentes IA,
   │          escalas,         admissão,      faturamento,   calendário)
   │          frequência,      colaboradores) rentabilidade)    │
   │          substituições)      │               ▲             │
   └──► Contrato ◄──── Alocação ──┘               │             │
            └──────── Frequência/custos ──────────┘   Leads/candidatos
                                                      ──► CRM / RH
        Portal do Cliente (lê Operacional + documentos autorizados)
        Inteligência gerencial (lê tudo, respeitando permissões)
```

Dependências que definem a ordem de construção:
1. **Cadastros base + permissões** são pré-requisito de tudo.
2. **Contrato e postos** são o centro: RH aloca em postos, Financeiro fatura contratos, Comercial gera contratos, Portal mostra contratos.
3. **Colaborador** é necessário para escalas e frequência. Na Etapa 3 haverá cadastro simples de colaborador; a Etapa 4 completa com recrutamento e admissão, reaproveitando a mesma tabela.
4. **Frequência e substituições** alimentam indicadores, portal e custo do contrato.
5. **Financeiro** precisa de contratos e, para rentabilidade, de custos de pessoal e frequência.

## 6. Modelo de dados

Convenções: chaves `uuid`, `organizacao_id` em toda tabela de negócio, `created_at/updated_at/created_by`, exclusão lógica (`ativo` / `status`) em vez de apagar registros com histórico, valores em `numeric(14,2)`, datas em `date`, horários em `time` e instantes em `timestamptz` (fuso America/Sao_Paulo na apresentação).

### 6.1 Núcleo e segurança (Etapa 2)
- `organizacoes` (razão social, CNPJ, parâmetros)
- `usuarios` (1:1 com `auth.users`; nome, e-mail, tipo: interno/cliente/colaborador; `cliente_id` quando externo)
- `perfis`, `permissoes`, `perfil_permissoes`, `usuario_perfis`
- `auditoria_log` (tabela, registro, ação, antes/depois em JSON, usuário, data, IP)
- `notificacoes` (usuário, tipo, título, link, lida)
- `parametros` (chave/valor por organização: metas de margem, tolerâncias etc.)

### 6.2 Cadastros e contratos (Etapa 2)
- `clientes` (razão social, nome fantasia, CNPJ/CPF, contatos, endereço, status)
- `cliente_unidades` (cliente, nome, endereço completo, cidade/UF, CEP, geolocalização, responsável local)
- `funcoes` (cargo: nome, CBO, salário-base de referência, convenção coletiva)
- `escalas_modelo` (5x2, 6x1, 12x36, personalizada: dias de trabalho/folga, horas por jornada, noturno)
- `contratos` (número, cliente, data início/fim, valor mensal, índice e data-base de reajuste, supervisor responsável, regras de substituição, obrigações, SLA de cobertura, status: rascunho/ativo/suspenso/encerrado)
- `contrato_unidades` (contrato atende uma ou mais unidades)
- `contrato_postos` (o "posto": contrato, unidade, função, escala, horário de entrada/saída, quantidade, valor por posto, ativo)
- `contrato_aditivos` (tipo: reajuste/acréscimo/supressão/prazo, vigência, valor novo)
- `contrato_indicadores` (KPIs contratuais e metas, ex.: cobertura mínima 98%)

### 6.3 Operacional (Etapa 3)
- `colaboradores` (matrícula, nome, CPF criptografado/mascarado, função, admissão, status, endereço/bairro e geolocalização para sugestão de substitutos, `candidato_id` de origem)
- `colaborador_dados_sensiveis` (documentos, dados bancários, saúde — acesso restrito)
- `alocacoes` (colaborador ↔ posto, início/fim, titular/volante)
- `escalas` (colaborador, posto, data, turno previsto, tipo: trabalho/folga/férias/afastamento) — geradas a partir do modelo
- `frequencias` (colaborador, posto, data, status: presente, falta justificada, falta injustificada, atestado, férias, afastamento, folga, substituído, aguardando confirmação; registrado por, origem: manual/importação/relógio)
- `ausencias` (férias, afastamentos, atestados com período)
- `postos_descobertos` (posto, data/turno, motivo, detectado em, coberto em, status)
- `substituicoes` (descoberta, substituto, sugerido por IA?, aprovado por, horário de cobertura, custo extra)
- `marcacoes_ponto` e `importacoes_ponto` (arquivos AFD/AEJ da Portaria MTP 671/2021)
- `ocorrencias` (registros de supervisão)

### 6.4 RH (Etapa 4)
- `vagas`, `candidatos`, `candidaturas` (etapa do funil), `candidatura_eventos`, `curriculos` (arquivo + texto extraído), `triagens_ia` (pontuação, critérios, justificativa, modelo usado, revisado por), `entrevistas`, `admissoes` (checklist de documentos), `documentos` (dono genérico, tipo, vencimento, classificação), `treinamentos`, `colaborador_treinamentos`, `beneficios`, `colaborador_beneficios`, `consentimentos` (LGPD: titular, finalidade, base legal, data, revogação)

### 6.5 Comercial (Etapa 5)
- `leads` (origem, responsável, empresa, contatos, serviços de interesse), `lead_interacoes`
- `funil_etapas` (configuráveis), `oportunidades` (lead, etapa, valor estimado, probabilidade, vendedor)
- `metas_vendedores`
- `modelos_preco` (convenção coletiva, regime tributário, encargos, premissas), `propostas`, `proposta_itens` (função, quantidade, salário, benefícios, encargos, tributos, uniformes/EPI, taxa adm., margem, preço)
- Conversão: `propostas.contrato_id` registra o contrato gerado.

### 6.6 Financeiro (Etapa 6)
- `fornecedores`, `plano_contas` / `categorias_financeiras`, `centros_custo` (contrato como centro de custo)
- `contas_bancarias`, `titulos_receber`, `titulos_pagar`, `parcelas`, `baixas` (pagamentos/recebimentos)
- `faturamentos` (contrato, competência, valor previsto, glosas, descontos por posto descoberto, valor faturado, NFS-e)
- `glosas`, `aprovacoes_pagamento`
- `custos_contrato` (mão de obra, encargos, benefícios, HE, substituições, uniformes, rateio de indiretos) e view `vw_rentabilidade_contrato`

### 6.7 Marketing (Etapa 7)
- `canais_sociais` (conta conectada, tokens no Vault), `publicacoes` (rascunho → aprovação → agendada → publicada), `calendario_editorial`, `interacoes_sociais` (comentário/DM, intenção classificada, ação tomada, humano responsável), `regras_resposta_automatica`, `metricas_sociais`, `campanhas`

### 6.8 Portal e IA (Etapas 8–9)
- `chamados` (cliente, contrato, tipo: substituição/ocorrência/solicitação, status, SLA), `chamado_mensagens`
- `relatorios_agendados` (cliente, frequência, destinatários)
- `ia_conversas`, `ia_mensagens`, `ia_ferramentas_log` (qual consulta foi executada, com quais filtros e período)

## 7. Indicadores operacionais — fórmulas

As definições ficam documentadas e implementadas como *views* SQL, para que dashboards, portal e assistente de IA usem exatamente o mesmo número.

| Indicador | Fórmula |
|---|---|
| Postos-dia previstos | soma de postos com escala de trabalho no período |
| **Presença do titular** | dias com status `presente` do titular ÷ dias de trabalho escalados do titular |
| **Cobertura efetiva do posto** | (postos-dia cobertos pelo titular + postos-dia cobertos por substituto) ÷ postos-dia previstos |
| Absenteísmo | (faltas justificadas + injustificadas + atestados) ÷ dias de trabalho escalados |
| Postos descobertos | postos-dia previstos − postos-dia cobertos |
| Cobertura contratual | postos efetivamente ativos e alocados ÷ postos contratados |
| Tempo médio de substituição | média de (hora da cobertura − hora da detecção da ausência) |
| Cumprimento de escala | dias trabalhados conforme escala ÷ dias escalados |

A distinção entre **presença do titular** e **cobertura do posto** é o que o cliente enxerga no portal: um posto pode ter 100% de cobertura mesmo com faltas, se todas forem substituídas.

## 8. Fluxos de integração

**Comercial:** Lead → Oportunidade → Proposta (formação de preço) → *Converter em contrato* (cria cliente/unidades se não existirem, contrato, postos com funções/quantidades/valores) → Operação (postos aparecem como descobertos até alocar) → Faturamento mensal (gerado do valor contratado − glosas) → Título a receber → Baixa.

**Recrutamento:** Vaga (pode nascer de postos sem titular) → Candidatura (página de carreiras) → Triagem IA (pontuação explicável, sem decisão automática) → Entrevista → Aprovação → Admissão (checklist de documentos) → *Converter em colaborador* (sem redigitar) → Alocação no posto (valida vaga, função, escala, localização e documentos) → Escalas geradas → Frequência.

**Operacional:** Frequência marca falta (ou não confirma presença até o horário de tolerância) → Posto descoberto criado → Alerta ao supervisor → Sugestão de substitutos (função compatível, sem escala conflitante, distância, horas trabalhadas na semana) → Gestor aprova → Substituição registrada → Indicadores e portal atualizados → custo extra entra na rentabilidade.

**Marketing:** Publicação (IA rascunha, humano aprova) → Interação (webhook Meta) → Classificação de intenção pela IA → Lead no CRM ou convite ao candidato para a página de carreiras → resposta automática só dentro das regras aprovadas; reclamações e negociações vão para humano.

Todas as passagens guardam a origem (`origem_tipo`, `origem_id`) para rastreabilidade, e as mudanças passam pelo log de auditoria.

## 9. Segurança e LGPD

- RLS habilitado em todas as tabelas; nenhuma tabela é acessível sem política.
- Chave `service_role` e chaves de IA/Meta só no servidor (variáveis de ambiente ou Vault).
- Auditoria por trigger em tabelas de negócio (quem, quando, antes/depois).
- Dados sensíveis segregados, mascarados por padrão na interface, com acesso registrado.
- Consentimento do candidato na página de carreiras (finalidade: recrutamento; retenção configurável, sugerido 12 meses).
- Política de retenção e anonimização por job agendado.
- Backups diários do Supabase (no plano Pro há point-in-time recovery).
- Validação Zod em toda entrada; uploads com checagem de tipo e tamanho.
- Monitoramento: logs do Supabase + Sentry (opcional, requer conta).

## 10. Integrações que dependem de credenciais, custos ou aprovação

| Integração | Depende de | Observação |
|---|---|---|
| Supabase produção (São Paulo) | Plano Pro ~US$ 25/mês | Dev usa o projeto gratuito atual. |
| Vercel | Gratuito no início; Pro US$ 20/mês por usuário para uso comercial | Uso comercial exige Pro pelos termos da Vercel. |
| API do Claude (IA) | Chave da Anthropic, cobrança por uso | Triagem, marketing, assistente. |
| Instagram (Meta Graph API) | Conta Business/Creator ligada a Página do Facebook, App Meta, **App Review** para permissões de publicação, comentários e mensagens | Aprovação pode levar semanas; começar cedo. |
| WhatsApp Cloud API | Conta Meta Business verificada, número dedicado, custo por conversa | Opcional. |
| E-mail transacional (Resend) | Conta e domínio verificado | Relatórios e notificações. |
| NFS-e | Certificado digital A1, cadastro na prefeitura ou no padrão nacional (ADN) | Etapa 6+, depende do município. |
| Relógio de ponto | Fabricante/modelo e acesso aos arquivos AFD/AEJ ou API | Primeiro via importação de arquivo. |

## 11. Roadmap

| Etapa | Entrega utilizável | Depende de |
|---|---|---|
| 1 | Este documento | — |
| 2 | Login, perfis/permissões, layout, dashboard inicial, cadastro de clientes, unidades, funções, escalas-modelo, contratos e postos | Supabase |
| 3 | Colaboradores (cadastro básico), alocação, geração de escalas, frequência diária, faltas, substituições, indicadores operacionais | 2 |
| 4 | Vagas, página de carreiras, candidaturas, triagem IA, Kanban de recrutamento, admissão → colaborador → alocação | 3, chave de IA |
| 5 | CRM, funil Kanban, metas, formação de preço, propostas em PDF, conversão em contrato | 2 |
| 6 | Contas a pagar/receber, faturamento, fluxo de caixa, rentabilidade por contrato | 2, 3 |
| 7 | Integração Instagram, agente de marketing, calendário, atendimento inteligente | Aprovação Meta, chave de IA |
| 8 | Portal do cliente, chamados, relatórios PDF/Excel e envio agendado | 3, e-mail |
| 9 | Dashboard executivo completo, assistente gerencial de IA | 3–6 |
| 10 | Testes E2E, revisão de permissões, documentação, produção | todas |

Etapas 5 e 6 podem andar em paralelo à 4, porque dependem principalmente do núcleo de contratos.

## 12. Dúvidas que preciso que você responda (não bloqueiam a Etapa 2)

1. **Uso futuro como SaaS:** o sistema será usado só pela NFF ou pretende vendê-lo a outras empresas? (Já deixei pronto para multiempresa; a resposta muda prioridades de cobrança e onboarding.)
2. **Folha de pagamento:** a folha continuará num sistema externo (Domínio, Senior, etc.)? Recomendo integrar por importação em vez de recalcular folha no ERP.
3. **Convenções coletivas e regime tributário** usados hoje (ex.: Lucro Real/Presumido, sindicato de asseio e conservação do seu estado), para os modelos de preço.
4. **Ponto eletrônico:** usam relógio/app de ponto hoje? Qual?
5. **Município** de emissão de NFS-e.
6. **Identidade visual:** logo e cores da NFF, se já existirem.
